<?php
/*
Template Name: Manage My Events
*/

if (isset($_SESSION['userdata'])) {
    $userdata = $_SESSION['userdata'];
} else {
    wp_redirect(site_url() . '?page_id=187');
    exit;
}

global $wpdb;
$token = $_SESSION['Api_token'];
$event_state = '';
$success = '';
$err = '';

if (isset($_GET['action']) && $_GET['action'] == 'invalid') {

    $err = 'Invalid Event Id.';
}

if (isset($_GET['cancelevent']) && $_GET['cancelevent'] != '') {

    $event_id = $_GET['cancelevent'];

    $pdata = array(
        'canceled' => 1
    );

    $payload = json_encode($pdata);
    $ch = curl_init(API_URL . 'events/' . $event_id);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLINFO_HEADER_OUT, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_FAILONERROR, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Content-Length:' . strlen($payload),
        'Authorization: ' . $token
    ));

    $result = curl_exec($ch);
    $response = json_decode($result);
    header("Location: " . site_url() . '?page_id=485');
}

if (isset($_GET['success']) && $_GET['success'] != '') {

    $event_id = base64_decode($_GET['success']);

    $ch = curl_init(API_URL . 'events/' . $event_id);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: ' . $token
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $event = json_decode($response);
    $success = $event->event->name . ' ' . 'successfully updated !';
}
if (isset($_GET['cancelsave']) && $_GET['cancelsave'] != '') {

    $event_id = base64_decode($_GET['cancelsave']);

    $ch = curl_init(API_URL . 'events/' . $event_id);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: ' . $token
    ));
    $response = curl_exec($ch);
    curl_close($ch);
    $event = json_decode($response);
    $cancelsave = "No changes made to " . $event->event->name;
}

if (isset($_POST['btnSearch']) && $_POST['btnSearch'] != '') {
    $event_state = $_POST['hidden_event_state'];
    $searchKeyword = $_POST['searchKeyword'];

    $ch = curl_init(API_URL . '/events?user=' . $userdata->id . '&state=' . $event_state . '&sort=ASC&sortType=startDate&search=' . $searchKeyword);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: ' . $token
    ));
    $result = curl_exec($ch);
    curl_close($ch);
    $apirespons = json_decode($result);

} else {

    if (isset($_GET['state']) && $_GET['state'] != '') {
       // echo API_URL . '/events?user=' . $userdata->id . '&state=' . $_GET['state'] . '&sort=ASC&sortType=startDate'; exit;
    //echo $token; exit;
        $ch = curl_init(API_URL . '/events?user=' . $userdata->id . '&state=' . $_GET['state'] . '&sort=ASC&sortType=startDate');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: ' . $token
        ));
        $result = curl_exec($ch);
        curl_close($ch);
        $apirespons = json_decode($result);
        $event_state = $_GET['state'];
    } else {
        $ch = curl_init(API_URL . '/events?user=' . $userdata->id . '&state=upcoming&sort=ASC&sortType=startDate');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: ' . $token
        ));
        $result = curl_exec($ch);
        curl_close($ch);
        $apirespons = json_decode($result);
        // echo"<pre>"; print_r($apirespons); die();
        $event_state = 'upcoming';

    }

}

if (isset($_SESSION['event_edit_data'])) {

    unset($_SESSION['event_edit_data']);
}

if (isset($_SESSION["ticket_data"])) {

    unset ($_SESSION["ticket_data"]);
}

get_header(); ?>
<style>

    .alert-success {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
    }

    .alert {
        position: relative;
        padding: .75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem;
    }

    .edit-event .event-detail {
        margin-top: 0;
        margin-bottom: 30px;
        border-bottom: 1px solid grey;
        padding-bottom: 20px;
    }
    .copied {
    border: 1px solid #a2fe93;
    border-radius: 3px;
    background: #e7ffe3;
    color: #257914;
    font-size: 13px;
    top: 87px;
    padding: 0px 6px;
    display: none;
    position: absolute;
    right: -120px;
    }
</style>
<div id="main-content">
    <div class="outer-wrapper">
        <div class="container container-home">
            <div class="edit-event">
                <h3 class="h3-title">Select Event to Edit </h3>

                <div class="alert alert-success" style="display: none;" id="success_msg">
                    <p style="text-align: center;"><?php echo $success; ?></p>
                </div>

                <div class="alert alert-success" style="display: none;" id="cancelsave_msg">
                    <p style="text-align: center;"><?php echo $cancelsave ? $cancelsave : ''; ?></p>
                </div>

                <div class="alert alert-danger" style="display: none; background-color: #FF9494;" id="err">
                    <p style="text-align: center;"><?php echo $err; ?></p>
                </div>

                <?php if ($success != '') { ?>

                    <script>
                        jQuery('#success_msg').show();
                        setTimeout(function () {
                            jQuery('#success_msg').hide();
                        }, 5000);
                    </script>
                <?php } ?>
                <?php if ($cancelsave) {
                    if ($cancelsave != '') { ?>
                        <script>
                            jQuery('#cancelsave_msg').show();
                            setTimeout(function () {
                                jQuery('#cancelsave_msg').hide();
                            }, 5000);
                        </script>
                    <?php }
                } ?>
                <?php if ($err != '') { ?>
                    <script>
                        jQuery('#err').show();
                        setTimeout(function () {
                            jQuery('#err').hide();
                        }, 5000);
                    </script>
                <?php } ?>
                <div class="event-type">
                    <form method="get" class="event-btn">
                        <span class="radio-chk"> <input type="radio"
                                                        name="edit-event" <?php echo (!isset($_GET['state']) || $_GET['state'] == 'upcoming') ? 'checked' : ''; ?> value="upcoming"
                                                        onclick="eventState('upcoming')"> <span
                                    class="checkmark1"> </span> Upcoming</span>
                        <span class="radio-chk"> <input type="radio"
                                                        name="edit-event" <?php echo (isset($_GET['state']) && $_GET['state'] == 'past') ? 'checked' : ''; ?> value="past"
                                                        onclick="eventState('past')"><span class="checkmark1"></span> Past</span>
                        <span class="radio-chk"> <input type="radio"
                                                        name="edit-event" <?php echo (isset($_GET['state']) && $_GET['state'] == 'cancelled') ? 'checked' : ''; ?> value="cancelled"
                                                        onclick="eventState('cancelled')"><span
                                    class="checkmark1"></span> Cancelled</span>
                    </form>
                    <form role="search" method="POST" class="edit-search" action="" id="searchForm">
                            <span class="e-search">
                              <input type="hidden" name="hidden_event_state" value="<?php echo $event_state; ?>">
                              <input type="text" name="searchKeyword" placeholder="Search..."
                                     value="<?php echo isset($searchKeyword) ? $searchKeyword : ''; ?>" id="s">
                              <input type="submit" id="searchsubmit" name="btnSearch" value="Search"> 
                              <i class="fa fa-search"></i>
                            </span>
                    </form>
                    <?php if (count($apirespons->events) > 0) { ?>

                    <div id="myEvents">
                        <?php $i = 0;
                        foreach ($apirespons->events as $row) { ?>

                            <?php if (($event_state == 'cancelled' && $row->canceled == 1) || ($event_state == 'past' && $row->canceled != 1) || ($event_state == 'upcoming' && $row->canceled != 1)) {
                                $i++; ?>
                                <?php
                                $ch = curl_init(API_URL . 'events/' . $row->id);
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                    'Content-Type: application/json',
                                    'Authorization: ' . $token
                                ));
                                $response = curl_exec($ch);
                                curl_close($ch);
                                $event = json_decode($response);

                                if ($event->event->files[0]->type == 'image') {
                                    $cat_im = 'https://storage.googleapis.com/' . $event->event->files[0]->bucket . '/' . $event->event->files[0]->filename;
                                } else {
                                    $cat_im = '';
                                }

                                if ($cat_im && $cat_im != '') {
                                    $event_image = $cat_im;
                                } else {
                                    $ch = curl_init(API_URL . '/files/' . $row->categorys[0]->image_id);
                                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                        'Content-Type: application/json',
                                        'Authorization: ' . $token
                                    ));
                                    $result167 = curl_exec($ch);
                                    curl_close($ch);
                                    $image_resp = json_decode($result167);

                                    $event_image = site_url() . '/wp-content/uploads/2019/06/f1.jpg';
                                }
                                ?>
                                <div class="event-detail">
                                    <div class="upload-image">
                                        <img src="<?php echo $event_image; ?>" >

                                    </div>
                                    <div class="event-details">

                                        <div class="row">
                                            <h3><?php echo $row->name; ?> </h3>
                                            <?php foreach ($row->event_dates as $edate) {

                                                if ($edate->start_date == $edate->end_date) { ?>

                                                    <b class="p-date"><?php echo date('M d, Y h:i a', strtotime($edate->start_date)); ?>
                                                        to <?php echo date('h:i a', strtotime($edate->end_date)); ?></b>
                                                <?php } else { ?>

                                                    <b class="p-date"><?php echo date('M d, Y h:i a', strtotime($edate->start_date)); ?>
                                                        to <?php echo date('M d, Y h:i a', strtotime($edate->end_date)); ?></b>
                                                <?php } ?>

                                            <?php } ?>

                                            <?php

                                            $country = $wpdb->get_row("Select * from wp_countries where  id = $row->country_id");
                                            $state = $wpdb->get_row("select * from wp_states where id = $row->province_id");
                                            ?>
                                            <p><b><?php echo $row->location . '<br/>'; ?></b>
                                                <?php echo ($row->address2) ? $row->address2 . ',' . '<br/>' : ''; ?>
                                                <?php echo $row->city; ?>, <?php echo $state->name; ?>
                                                , <?php echo $country->name; ?> <br/>
                                                <?php echo ($row->postalcode) ? $row->postalcode : ''; ?>
											</p>
											
											<div style="clear: both;"><?php echo $row->lat.' ,  '.$row->long; ?> just for testing </div>
                                            
											<div class="three-btn">

                                                <?php if (!isset($_GET['state']) || $_GET['state'] == 'upcoming' || $_GET['state'] == 'past') { ?>

                                                    <form action="<?php echo site_url(); ?>/edit-event?eventstate=<?php echo $event_state; ?>&event_id=<?php echo $row->id; ?>"
                                                          method="post" style="width:auto !important;">

                                                        <input type="hidden" name="edit"
                                                               value="<?php echo $row->id; ?>">
                                                        <input type="hidden" name="eventstate"
                                                               value="<?php echo $event_state; ?>">
                                                        <button type="submit" name="btnToEditPage">Edit</button>
                                                        <!-- <button><a href="<?php // echo site_url(); ?>?page_id=917&edit=<?php //echo $row->id;?>&eventstate=<?php e//cho $event_state;?>">EDIT</a></button> -->
                                                    </form>

                                                <?php } ?>

                                                <button>
                                                    <a href="<?php echo site_url(); ?>/attendees-report/">ATTENDEES</a>
                                                </button>
                                                <button><a href="<?php echo site_url(); ?>/sales-report/">REPORT</a>
                                                </button>
                                            </div>

                                        </div>
                                        <div class="event-detail-right">
                                            <h3>Event ID: <?php echo $row->id; ?></h3>
                                            <div class="clone-event"><a href="<?php echo site_url() ?>?page_id=304&copy=<?php echo base64_encode($row->id); ?>">
                                                    <span class="copy-event"><i class="fa fa-copy"></i></span>Clone Event</a>
                                            </div>

                                            <div class="copy-url"><p id="eveUrl<?php echo $row->id; ?>" style="display:none"><?php echo site_url(); ?>?page_id=354&event_id=<?php echo $row->id; ?></p>
                                                <a href="javascript:void(0)" onclick="copyEventurl('#eveUrl<?php echo $row->id; ?>','#copied_<?php echo $row->id; ?>')">
                                                    <span class="copy-event"><i class="fa fa-link"></i></span>Copy event URL</a></div>
                                            <div class="copied" id="copied_<?php echo $row->id; ?>">Url copied to clipboard</div>
                                            <div class="event_preview" id="<?php echo $row->id; ?>"><a
                                                        href="javascript:void(0)"><span class="copy-event"><i
                                                                class="fa fa-search"></i></span>Preview</div>
                                            </a>
                                        </div>
                                        
                                    </div>
                                    <div class="events_links">
                                        <a href="<?php echo site_url(); ?>/view-event/<?php echo $row->id; ?>"
                                           class="view_event" target="_blank">View Event </a>
                                        <?php if (!isset($_GET['state']) || $_GET['state'] == 'upcoming') { ?>

                                            <a href="#" class="cancel_event" id="cancel_event"
                                               data-eventid=<?php echo $row->id; ?>>Cancel Event </a>
                                        <?php } ?>
                                    </div>
                                </div>
                                
                            <?php } ?>

                        <?php } ?>


                        <?php if ($i > 2) { ?>
<!--                            <p class="load-more">-->
<!--                                <button class="load-event" id="load_more" data-total="--><?php //echo $i - 1; ?><!--">Load More-->
<!--                                </button>-->
<!--                            </p>-->
                        <?php } else if ($i == 0) { ?>

                            <p class="no-cevent" style="text-align: center; font-size: 20px;">No Current Events</p>
                        <?php } ?>

                        <?php } else { ?>

                            <p class="no-cevent" style="text-align: center; font-size: 20px;">No Current Events</p>
                        <?php } ?>

                    </div>
                </div>
                <!-- # outer-wrapper-->
            </div>
            <!-- #main content -->
        </div>
        <div class="modal" id="loadingModal" role="dialog">
            <div class="modal-dialog modal-lg" style="max-width: 220px !important;">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="email-confomation">
                            <p class="mail-img" style="padding: 0px;"><img
                                        src="<?php echo site_url(); ?>/wp-content/uploads/loading.gif"></p>
                            <p id="modal_loader_text">Loading...</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div class="modal" id="previewModal" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Preview</h4>
                        <button type="button" class="btn btn-default" onClick="jQuery('#previewModal').hide();">X
                        </button>
                    </div>
                    <div class="modal-body" id="modal_body_preview">


                    </div>
                </div>
            </div>
        </div>

        <style>
            .modal-open {
                overflow: hidden;
            }

            .modal {
                background: #00000054;
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 999;
                display: none;
                overflow: hidden;
                outline: 0;
            }

            .modal-open .modal {
                overflow-x: hidden;
                overflow-y: auto;
            }

            .modal-dialog {
                position: relative;
                width: auto;
                margin: 0.5rem;
                pointer-events: none;
            }

            .email-confomation {
                margin: 0px auto !important;
                width: 100% !important;
                background: #ede9e7 !important;
                padding: 10px !important;
            }

            .modal.fade .modal-dialog {
                transition: -webkit-transform 0.3s ease-out;
                transition: transform 0.3s ease-out;
                transition: transform 0.3s ease-out, -webkit-transform 0.3s ease-out;
                -webkit-transform: translate(0, -25%);
                transform: translate(0, -25%);
            }

            .btn-default {
                color: #fefefe;
                background-color: #333;
                border-color: #000;
                padding: 4px 11px;
                font-size: 18px;
                border-radius: 30px;
                border: 0;
            }

            @media screen and (prefers-reduced-motion: reduce) {
                .modal.fade .modal-dialog {
                    transition: none;
                }
            }

            .modal.show .modal-dialog {
                -webkit-transform: translate(0, 0);
                transform: translate(0, 0);
            }

            .modal-dialog-centered {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-align: center;
                align-items: center;
                min-height: calc(100% - (0.5rem * 2));
            }

            .modal-content {
                position: relative;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                width: 100%;
                pointer-events: auto;
                background-color: #fff;
                background-clip: padding-box;
                border: 1px solid rgba(0, 0, 0, 0.2);
                border-radius: 0.3rem;
                outline: 0;
            }

            .modal-backdrop {
                position: fixed;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                z-index: 1040;
                background-color: #000;
            }

            .modal-backdrop.fade {
                opacity: 0;
            }

            .modal-backdrop.show {
                opacity: 0.5;
            }

            .modal-header {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-align: start;
                align-items: flex-start;
                -ms-flex-pack: justify;
                justify-content: space-between;
                padding: 1rem;
                border-bottom: 1px solid #e9ecef;
                border-top-left-radius: 0.3rem;
                border-top-right-radius: 0.3rem;
                background: #333333;
            }

            .modal-header .close {
                padding: 1rem;
                margin: -1rem -1rem -1rem auto;
            }

            .modal-title {
                margin-bottom: 0;
                line-height: 1.5;
                padding-bottom: 0;
                font-size: 26px;
                font-weight: bold;
                color: #fff;
            }

            .modal-dialog.modal-lg {
                margin-top: 13%;
            }

            h4.modal-title {
                width: 100%;
            }

            .modal-body {
                position: relative;
                -ms-flex: 1 1 auto;
                flex: 1 1 auto;
                padding: 0.6rem;
                max-height: 600px;
                overflow-x: hidden;;
            }

            .modal-footer {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-align: center;
                align-items: center;
                -ms-flex-pack: end;
                justify-content: flex-end;
                padding: 1rem;
                border-top: 1px solid #e9ecef;
            }

            .modal-footer > :not(:first-child) {
                margin-left: .25rem;
            }

            .modal-footer > :not(:last-child) {
                margin-right: .25rem;
            }

            .modal-scrollbar-measure {
                position: absolute;
                top: -9999px;
                width: 50px;
                height: 50px;
                overflow: scroll;
            }

            @media (min-width: 576px) {
                .modal-dialog {
                    max-width: 500px;
                    margin: 1.75rem auto;
                }

                .modal-dialog-centered {
                    min-height: calc(100% - (1.75rem * 2));
                }

                .modal-sm {
                    max-width: 300px;
                }
            }

            @media (min-width: 992px) {
                .modal-lg {
                    max-width: 800px;
                }
            }

        </style>
        <?php get_footer(); ?>

        <script>

            jQuery(document).ready(function () {

                var limit = 2;

                jQuery('#myEvents div.event-detail:lt(' + limit + ')').show();

                jQuery(document).on('click', '#load_more', function () {

                    var total = jQuery(this).data('total');
                    limit = parseInt(limit) + parseInt(2);

                    jQuery('#myEvents div.event-detail:lt(' + limit + ')').show();

                    if (parseInt(limit) > parseInt(total)) {

                        jQuery('#load_more').hide();
                    }

                });
            });

            function eventState(state = '') {

                jQuery('#modal_loader_text').text('In progress….');
                jQuery('#loadingModal').show();
                setTimeout(function () {
                    jQuery('#loadingModal').hide();
                }, 3000);
                window.location.href = '<?php echo site_url()?>?page_id=485&state=' + state;
            }

            jQuery('#searchForm').submit(function () {

                jQuery('#modal_loader_text').text('Searching.....');
                jQuery('#loadingModal').show();
                setTimeout(function () {
                    jQuery('#loadingModal').hide();
                }, 3000);
            });

            jQuery(document).on('click', '#cancel_event', function (e) {

                e.preventDefault();
                conf = confirm("Do you really want to cancel this event ?");
                if (conf == true) {
                    var event_id = jQuery(this).data('eventid');
                    jQuery('#modal_loader_text').text('Event cancellation in progress….');
                    jQuery('#loadingModal').show();
                    setTimeout(function () {
                        jQuery('#loadingModal').hide();
                    }, 5000);
                    window.location.href = '<?php echo site_url()?>?page_id=485&cancelevent=' + event_id;
                }
            });
            jQuery(document).on('click', '.event_preview', function () {
                var site_url = jQuery('#Site_Url').val();
                var event_id = jQuery(this).attr('id');
                //alert(event_id +" is id picked ");
                jQuery.ajax({
                    type: 'POST',
                    url: site_url + '/wp-content/themes/Divi Child/single_event_preview_ajax.php',
                    data: 'event_id=' + event_id,
                    success: function (html) {
                        //alert(html);
                        jQuery('#modal_body_preview').html(html);
                        jQuery('#previewModal').show();
                    }
                });
            });

            function copyEventurl(e,c) {
                var $temp = jQuery("<input>");
                jQuery("body").append($temp);
                $temp.val(jQuery(e).text()).select();
                document.execCommand("copy");
                $temp.remove();
                console.log(jQuery(e).text());
                jQuery(c).show().delay(3000).fadeOut(2000);
                
            }

        </script>
