<?php 
/*
Template Name: Sales Report
*/
get_header(); ?>

    <div id="main-content">


       <div class="outer-wrapper">
           <div class="container container-home">
              <div class="edit-event sale-rep">
        <h3 class="h3-title sales-rep">Sales Report </h3>
		<div class="event-detail">
			<div class="upload-image-sale">
			<img src="<?php echo site_url(); ?>/wp-content/uploads/2019/08/r1.jpg">
            	<h3>The Market Jazz Festival</h3> 
				<b class="p-date">May 22,9019 8:am to 5:00pm</b><br>
				<p class="sale-venue"><b>ABC Venue</b><br>
				123 SomewhereSl,<br>
				New Market, Canada	<br>	
				Ontaria<br>
				A1a 1A1</p>
			</div>	
		</div>
		
		<div id="demo-pie-1" class="pie-title-center" data-percent="25"> 
		<div class="c100 p50 big">
                    <span><span class="sp">50% </span><br/> Total Sold</span>
                    <div class="slice">
                     <div class="bar bgbg"></div>
                      <div class="fill"></div>
                    </div>
                </div>
	</div>
		
		</div>
	     <div class="breakdown">
	         <h4 class="sale-tkt">Ticket Type Breakdown</h4>
            <table class="tkt-summary" style="width:100%">
               <tr>
                  <th>Ticket Type </th>
                  <th class="right-align">Price</th>
                  <th class="right-align">Sold</th>
                  <th class="right-align">Available</th>
                  <th class="right-align">Total</th>
                  <th class="right-align">%</th>
               </tr>
                <tr>
                  <td>Lower Bowl Section A</td>
                  <td class="right-align">$100.00</td>
                  <td class="right-align">20</td>
                   <td class="right-align">480</td>
                   <td class="right-align">500</td>
                   <td class="right-align">4.00</td>
                  </tr>
               <tr>
                  <td>Lower Bowl Section B</td>
                  <td class="right-align">$75.00</td>
                  <td class="right-align">28</td>
                   <td class="right-align">322</td>
                   <td class="right-align">350</td>
                   <td class="right-align">8.00</td>
                  </tr>
                  <tr>
                  <td>Upper Bowl</td>
                  <td class="right-align">$50.00</td>
                  <td class="right-align">10</td>
                   <td class="right-align">240</td>
                   <td class="right-align">250</td>
                   <td class="right-align">4.00</td>
                  </tr>
            </table>
            <p class="att-load-more"><button class="load-event">Load More</button></p>
            <p class="view-all"><a href="" class="load-event">View All</a></p>
            <div class="download-csv"><a href="#"><img width="80px" src="http://webdev.snapd.com/wp-content/uploads/2019/11/csv.jpg"></a></div>
</div>
	     <div class="breakdown">
	       <div class="sale-outer"> <h4 class="sale-tkt">Ticket Purchase Breakdown</h4> 
	       <form role="search" method="get" class="edit-search" action="<?php echo site_url(); ?>">
				     	  <span class="e-search">  
				     	<input type="text" value="" placeholder="Search..." name="s" id="s">
				    	<input type="submit" id="searchsubmit" value="Search"> <i class="fa fa-search"></i></span>
			
			        </form>	</div>
            <table class="tkt-summary" style="width:100%">
               <tr>
                  <th>Date Purchased</th>
                  <th class="right-align">Order No.</th>
                  <th class="right-align">Purchaser</th>
                  <th class="right-align">Ticket Type</th>
                  <th class="right-align">Tickets Total</th>
                  <th class="right-align">Your Payout</th>
               </tr>
                <tr>
                  <td><span class="p-date">18 Auguest, 2019 </span><span class="p-time">3:04pm</span></td>
                  <td class="right-align">5d5c8gh11</td>
                  <td class="right-align">R. Dilda</td>
                   <td class="right-align">General Admission</td>
                   <td class="right-align">$25.85</td>
                   <td class="right-align">$22.85</td>
                  </tr>
               <tr>
                  <td><span class="p-date">18 Auguest, 2019 </span><span class="p-time">3:04pm</span></td>
                  <td class="right-align">5d5c8gh11</td>
                  <td class="right-align">R. Dilda</td>
                   <td class="right-align">General Admission</td>
                   <td class="right-align">$25.85</td>
                   <td class="right-align">$22.85</td>
                  </tr>
                  <tr>
                  <td><span class="p-date">18 Auguest, 2019 </span><span class="p-time">3:04pm</span></td>
                  <td class="right-align">5d5c8gh11</td>
                  <td class="right-align">R. Dilda</td>
                   <td class="right-align">General Admission</td>
                   <td class="right-align">$25.85</td>
                   <td class="right-align">$22.85</td>
                  </tr>
                  
            </table>
                        <div class="overall-total"><table class="total">
               <tr>
                  <td>Overall Totals</td>
                  <td class="right-align">$225.25</td>
                  <td class="right-align">$140.60</td>
               </tr></table></div>
              <div class="load-sales"> <p class="att-load-more"><button class="load-event">Load More</button></p>
               <p class="view-all"><a href="#" class="load-event">View All</a></p></div>
            <div class="download-csv"><a href="#"><img width="80px" src="http://webdev.snapd.com/wp-content/uploads/2019/11/csv.jpg"></a>
            </div>
      </div>
      	     <div class="breakdown">   
         <h4 class="sale-tkt">Ticket Purchaser Detailed Summary</h4>
         <div class="download-csv"><a href="#"><img width="80px" src="http://webdev.snapd.com/wp-content/uploads/2019/11/csv.jpg"></a></div>
         </div>
      </div>   <!-- # outer-wrapper-->
    </div> <!-- #main content --> 
<style>
.c100 {
  position: relative;
  font-size: 120px;
  width: 1em;
  height: 1em;
  border-radius: 50%;
  float: left;
  margin: 0 0.1em 0.1em 0;
  background-color: #cccccc;
}
.c100.big {
  font-size: 240px;
}
.c100 > span {
  position: absolute;
  width: 100%;
  z-index: 1;
  left: 38px;
  top: 73px;
  width: 5em;
  line-height: 43px;
  font-size: 34px;
  color: #cccccc;
  display: block;
  text-align: center;
  white-space: nowrap;
  -webkit-transition-property: all;
  -moz-transition-property: all;
  -o-transition-property: all;
  transition-property: all;
  -webkit-transition-duration: 0.2s;
  -moz-transition-duration: 0.2s;
  -o-transition-duration: 0.2s;
  transition-duration: 0.2s;
  -webkit-transition-timing-function: ease-out;
  -moz-transition-timing-function: ease-out;
  -o-transition-timing-function: ease-out;
  transition-timing-function: ease-out;
}
.c100:after {
  position: absolute;
  top: 0.08em;
  left: 0.08em;
  display: block;
  content: " ";
  border-radius: 50%;
  background-color: #f5f5f5;
  width: 0.84em;
  height: 0.84em;
  -webkit-transition-property: all;
  -moz-transition-property: all;
  -o-transition-property: all;
  transition-property: all;
  -webkit-transition-duration: 0.2s;
  -moz-transition-duration: 0.2s;
  -o-transition-duration: 0.2s;
  transition-duration: 0.2s;
  -webkit-transition-timing-function: ease-in;
  -moz-transition-timing-function: ease-in;
  -o-transition-timing-function: ease-in;
  transition-timing-function: ease-in;
}
.c100 .slice {
  position: absolute;
  width: 1em;
  height: 1em;
  clip: rect(0em, 1em, 1em, 0.5em);
}
.c100.p50 .bar {
  -webkit-transform: rotate(180deg);
  -moz-transform: rotate(180deg);
  -ms-transform: rotate(180deg);
  -o-transform: rotate(180deg);
  transform: rotate(180deg);
}
.c100 .bar {
 position: absolute;
  border: 0.08em solid #5fa9da;
  width: 0.84em;
  height: 0.84em;
 /* clip: rect(0.2em, 0.5em, 1em, 0em); */
  border-radius: 50%;
  -webkit-transform: rotate(0deg);
  -moz-transform: rotate(0deg);
  -ms-transform: rotate(0deg);
  -o-transform: rotate(0deg);
  transform: rotate(0deg);
}
.c100 *,
.c100 *:before,
.c100 *:after {
  -webkit-box-sizing: content-box;
  -moz-box-sizing: content-box;
  box-sizing: content-box;
}
span.sp {
  color: black;
  font-size: 45px;
}

</style>
    <?php get_footer(); ?>