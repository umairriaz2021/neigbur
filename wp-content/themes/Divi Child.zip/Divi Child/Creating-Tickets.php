<?php

   /* Template Name: Create Tickets */
   
   if(!isset($_SESSION['Api_token'])){
       wp_redirect( site_url().'?page_id=187' );
       exit;
   }  
   if(!isset($_GET['edit']) && $_GET['edit'] == ''){
   unset($_SESSION['eventstate']);
   }
   
   global $wpdb;  
   /* echo "<pre>"; print_r($_POST); print_r($_FILES); echo "</pre>"; die;  */
   
   if(isset($_POST['btnSubmit'])) {  
   
        
   if ($_FILES['fileToUpload']['name'] != '') {
   $type = pathinfo($_FILES['fileToUpload']['name'], PATHINFO_EXTENSION);  
   $base64 = explode('base64,',$_POST['event_image_base64']);
   $_POST['filetouploadname'][] = array('name' => date('Ymd') . time() . rand(0, 9999) . '.' . $type, 'base64' => $base64[1],'type'=>$_FILES['fileToUpload']['type']);
   }
   
   if ($_FILES['logo_image']['name'] != '') {
   $type = pathinfo($_FILES['logo_image']['name'], PATHINFO_EXTENSION);
   $_POST['logo_image'] = date('Ymd') . time() . rand(0, 9999) . '.' . $type;
   $_POST['logo_image_type'] = $_FILES['logo_image']['type'];     
   /* $base64 = explode('base64,',$_POST['logo_image_base64']); 
   $_POST['logo_image_base64'] =  $base64[1]; */
   $data = file_get_contents($_FILES['logo_image']['tmp_name']);
   $_POST['logo_image_base64'] =  base64_encode($data);
   
   }
   if ($_FILES['attach_image']['name'] != '') {
   $type = pathinfo($_FILES['attach_image']['name'], PATHINFO_EXTENSION);
   $data = file_get_contents($_FILES['attach_image']['tmp_name']);
   //$attach_image = date('Ymd') . time() . rand(0, 9999) . '.' . $type;
   $_POST['attach_image'] = $_FILES['attach_image']['name'];
   $_POST['attach_image_base64'] = base64_encode($data);
   }
   $_SESSION['event_data'] = $_POST;
     //echo '<pre>'; print_r($_SESSION['event_data']); die();
   
   }
   
   /*  
   if(isset($_POST['btnAddTicket'])){
       $_SESSION['event_data'] = $_POST;
   }
   */
   if(isset($_POST['btnTicketSubmit'])) {
         $_SESSION['ticket_data'] = $_POST;
      if(isset($_GET['edit']) && $_GET['edit']){
         header("Location: ".site_url().'?page_id=440&edit='.$_GET['edit']);  /* review and submit page */
      }else {
         header("Location: ".site_url().'?page_id=440');  /* review and submit page */
      }
   }
   if(isset($_GET['edit']) && $_GET['edit'] != '') {
       
       
       
       $token = $_SESSION['Api_token'];
       $event_id = $_GET['edit'];
       
       $ch      = curl_init(API_URL.'ticketTypes?eventId='.$event_id);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, array(
           'Content-Type: application/json',
           'Authorization: ' . $token
       ));
       $tkt_response = curl_exec($ch);
       curl_close($ch);
       $tkt = json_decode($tkt_response);
       if($tkt->success && !empty($tkt->ticketType)) {
          $tickets = $tkt->ticketType;                 
       }  
       
      
   }
   if(isset($_GET['clone']) && $_GET['clone'] != '') {
       
       
       
       $token = $_SESSION['Api_token'];
       $event_id = $_GET['clone'];
       
       $ch      = curl_init(API_URL.'ticketTypes?eventId='.$event_id);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($ch, CURLOPT_HTTPHEADER, array(
           'Content-Type: application/json',
           'Authorization: ' . $token
       ));
       $tkt_response = curl_exec($ch);
       curl_close($ch);
       $tkt = json_decode($tkt_response);
       if($tkt->success && !empty($tkt->ticketType)) {
          $tickets = $tkt->ticketType;                 
       }  
       
      
   }
   
     
   $event_state = $_SESSION['eventstate'];
   
   
   $countries = $wpdb->get_results("Select * from wp_countries");
   
   $fee = getConvenienceFees();  
   get_header(); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/1.1.1/jquery.datetimepicker.min.css">
<link rel="stylesheet" href="<?php echo site_url()?>/wp-content/themes/Divi Child/css/createevent.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/1.1.1/jquery.datetimepicker.min.js"></script>
 <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
   fees = "<?php echo json_encode($fee);?>";
</script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
<style>
   .error {
   color: red !important;
   }
   .tbtkt{
   border: none !important;
   background: no-repeat !important; 
   }
   .s_h-arrow{
    height: 52px;
    width: 52px;
    float: right;
    right: -230px;
    position: relative;
    /* cursor: pointer; */
    z-index: 999;
   }
   .mvright{
    right: -257px !important;   
   }
</style>
<div id="main-content">
   <div class="outer-wrapper">
      <div id="setup_div" class="container container-home">
         <form id="tkt_form" method="post" action="">
            <input type="hidden" id="cfee" value='<?php echo json_encode($fee); ?>' name="cfee">
            <input type="hidden" id="start" value="0">  
            <h3 class="h3-title">Configuring Your Tickets</h3>
            <button type="button" class="btn-return"><a href="<?php echo site_url(); ?>/create-event/"><i class="fa fa-toggle-left"></i> <span>Return to Event Setup</span></a></button>
            <?php
         if(isset($_GET['edit'])){
         ?>
         <ul class="progressbar">
            <li class="active">Page Design</li>
            <li class="active">Ticket Options</li>
            <li>Options & Update</li>
         </ul>
         <?php }else{ ?>
         <ul class="progressbar">
            <li class="active chk-mark">Page Design</li>
            <li class="active chk-mark">Ticket Options</li>
            <li class="active">Options & Submit</li>
         </ul><?php } ?>
            <p style="float:left;width:100%;text-align:center;margin-bottom:10px;font-size: 15px;">Complete each required section; section NEXT to proceed.</p>
            <hr/>
            <div class="new-ticket-setup">
               <p>Do you wish to include free or paid tickets with your event?</p>
               <span class="radio-chk"><input type="radio" class="ticket_setup" name="tkt_setup" id="no" value="No" <?php echo isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'NO' ? 'checked' :  !empty($tickets[0]->name) ? '' : 'checked';?> <?php echo (isset($event_state) && $event_state == 'past') ? 'disabled' : '';?>> <span class="checkmark1"> </span>No</span>
               <span class="radio-chk"><input type="radio" class="ticket_setup" name="tkt_setup" id="tix" value="Yes Tix" <?php echo isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'Yes Tix' ? 'checked' :  !empty($tickets[0]->name) ? 'checked' : '';?> <?php echo (isset($event_state) && $event_state == 'past') ? 'disabled' : '';?>> <span class="checkmark1"> </span>Yes, setup with neighbur TIX </span>
               <span class="radio-chk"><input type="radio" class="ticket_setup" name="tkt_setup" id="3rd" value="Yes 3rd party" <?php echo isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'Yes 3rd party' ? 'checked' : '' ?><?php echo (isset($event_state) && $event_state == 'past') ? 'disabled' : '';?>> <span class="checkmark1"> </span>Yes, setup with 3rd party ticketing </span>
            </div>
            <div class="ticket-setup-options" style="display: <?php echo  (isset($_GET['edit']) || isset($_GET['clone'])) ? !empty($tickets[0]->name) ? 'block' : 'none' : (isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'Yes Tix' ? 'block' : 'none') ;?>;">
               <div class="ticket-setup">
                  <h3>Setup Tickets Using neighbur TIX
                     <label class="switch">
                     <input type="checkbox" checked class="setup_switch">
                     <span class="slider1 round"></span>
                     </label>
                  </h3>
                  <p>Please setup your ticket types for different ticket requirements such as Gerneral Admission, Early Birds or VIP.</p>
                  <p>Ticket type further help distinguish seating arrangements for different sections in a venue or different price points on different types of tickets.</p>
                  <p>Use tickets types to help organize your ticket batches and provide clarity for your customer.</p>
                  <p>Add details ton instruct your customer to understand what is included with their ticket , any special bonuses or specifics on what may be limited per entry.</p>
               </div>
               <div class="paid-event">
                  <h5>About Paid Events</h5>
                  <p>Event organizers may absorb (pay) a percentage of the convenience fee applied to tickets.</p>
                  <p>If you select to absorb part, or the full amount of convenience fee, the percentage will be removed from your payout after the event is over.</p>
                  <p>If you wish tickets purchasers to absorb all fee, keep the % Convenience Fee Paid by you at 0%</p>
               </div>
               <?php if(isset($tickets)) { ?>
               <input type="hidden" value="<?php echo count($tickets)?>" id="count" name="count">
               <div class="tkt_avail">
                  <div class="h-left">
                     <h3> Enter total tickets available for all ticket types </h3>
                     <?php $max_val = 0;
                     foreach($tickets as $tkt_max){ $max_val += $tkt_max->max;  } ?>
                     <input min="0" type="number" required="required" value="<?php echo $max_val;?>" id="total_ticket_available" name="total_ticket_available" <?php echo (isset($event_state) && $event_state == 'past') ? 'disabled' : '';?>>
                  </div>
                  <p class="help-text">Why do we ask this? <br/> To prevent over selling of required tickets via multiple ticket types.</p>
               </div>
               <div class="tkt_avail">
                  <div class="h-left">
                     <h3> Current ticket allocation </h3>
                     <span id="current_ticket_allocation"><?php echo $max_val;?></span>
                     <input type="hidden" name="current_ticket_allocation" id="hidden_current_ticket_allocation" value="<?php echo $max_val;?>">
                  </div>
                  <p class="help-text">Why do we display this?<br/>To monitor your total ticket distribution against your total tickets availabe as shown above
                     <span class="current-tkt"><i class="fa fa-search"></i> Current Ticket Report</span>
                  </p>
               </div>
               <div class="tkt_avail">
                  <h3 style="width:44%;text-align: right;">Do you need to charge tax for this event?</h3>
                  <div class="tax-outer">
                     <select class="charge-tax" name="tkt_tax">
                        <option value="no" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile != '') ? '' : 'selected';?>>No</option>
                        <option value="yes" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile != '') ? 'selected' : '';?>>Yes</option>
                     </select>
                     <div class="tooltip2"><i class="fa fa-info"></i>
                        <span class="tooltiptext2"><b>Tax Information</b><br>
                        The application of taxes on this event is subject to the nature of your event, your tax status, location of event and other factors that may determine the inclusion of a tax rate. Please consult with a tax specialist regarding your taxation requirements for collection and remittance
                        purposes.
                        <br>
                        Any information provided will be displayed on all ticket invoices and reports.
                        </span>
                     </div>
                  </div>
                  <div class="tax-yes" style="display: <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile != '') ? '' : 'none';?>;">
                     <label>Country</label>
                     <select name="country">
                        <option value="2" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile->country_id == 2) ? 'selected' : '';?>>Canada</option>
                        <option value="3" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile->country_id == 3) ? 'selected' : '';?>>United States</option>
                        <?php /* foreach($countries as $row) { ?>
                        <option value="<?php echo $row->id?>" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile->country_id == $row->id) ? 'selected' : '';?>><?php echo $row->name;?></option>
                        <?php } */ ?>
                     </select>
                     <label> Tax ID <input type="text" required="required" placeholder="Id" name="tax_id" id="tax_id" required title="Please enter Tax ID" value="<?php echo isset($tickets[0]->tax_profile) ? $tickets[0]->tax_profile->tax_id : '';?>"> </label>
                     <label> Tax Name <input type="text" required="required" placeholder="Name" name="tax_name" id="tax_name" required title="Please enter Tax Name" value="<?php echo isset($tickets[0]->tax_profile) ? $tickets[0]->tax_profile->name : '';?>"> </label>
                     <label> Tax Rate <input type="number" required="required" placeholder="Rate" min="0" name="tax_rate" id="tax_rate" required title="Please enter Tax Rate" value="<?php echo isset($tickets[0]->tax_profile) ? $tickets[0]->tax_profile->tax_rate_aggregate : '';?>"> % </label><span class="tax-rate">Select taxation option for each ticket type setup below.</span>
                  </div>
               </div>
               <hr/>
               <p><b>All required fields marked with (*).</b></p>
               <br/>
               <div id="div_ticket">
                  <?php if(isset($tickets)){ 
                     $j=1;
                     foreach($tickets as $key=>$val) { ?>
                  <div class="tkt-details"  id="tkt_<?php echo $j; ?>">
                     <!-- ticket detail start -->
                     <div class="accordion">
                        <div class="acc-head">
                           <div class="tkt-name">
                              <i class="fa fa-bars"></i> 
                              <div class="tkt-no"><?php echo $j;?></div>
                              <p  class="tkt_name_div"><input type="text" class="t-name" name="ticket_name[]" value="<?php echo $val->name;?>"  placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                           </div>
                           <span class="t-edit"><i class="fa fa-pencil"></i></span>
                           <span class="t-clone"><i class="fa fa-clone"></i></span>
                           <div class="tickets-total-sidebar">
                              <div class="tkt-total-sold">0</div>
                              <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_<?php echo $j;?>"><?php echo $val->order_limit;?></span></div>
                           </div>
                           <div class="s_h-arrow"></div>
                        </div>
                        <div class="form-left">
                           <div class="form-right">
                              <label>% Convernience Fee Paid By You.</label>
                              <select class="convenience_fee" name="select_per[]">
                                 <option value="0">0%</option>
                                 <option value="25">25%</option>
                                 <option value="50">50%</option>
                                 <option value="75">75%</option>
                                 <option value="100">100%</option>
                              </select>
                              <div class="row tx_incl">
                                 <label>Tax Inclusion</label>
                                 <div class="tooltip2"><i class="fa fa-info"></i>
                                    <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                    ADDED will display ticket price as stated.<br>
                                    INCLUDED will display ticket price before taxes.
                                    </span>
                                 </div>
                                 <select name="tax_inclusion" style="width: 100%;" name="tax_inclusion[]">
                                    <option value="0">No</option>
                                    <option value="1">Yes, tax ADDED to ticket price</option>
                                    <option value="2">Yes, tax INCLUDED in ticket price</option>
                                 </select>
                              </div>
                           </div>
                           <div class="d-optional">
                              <label>Details (optional)</label>
                              <p><textarea  name="ticket_details[]"><?php echo $val->note;?></textarea> </p>
                           </div>
                           <div class="row-out">
                              <div class="row-1">
                                 <label>Ticket type</label>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Single Tickets" <?php echo ($val->bundled_yn) ? '' : 'checked' ;?>> <span class="checkmark1"> </span> Single Tickets
                                 </span>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Bundled Tickets" <?php echo ($val->bundled_yn) ? 'checked' : '';?>> <span class="checkmark1"> </span>Bundled Tickets
                                 </span>
                                 <p class="tkt-type">Use Bundled tickets when you want to sell group tickets package (i.e. table of 10, golf foursome, family package) </p>
                              </div>
                              <div class="row-2">
                                 <label>Price type</label>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_<?php echo $j;?>').attr('readonly',false);" type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Paid" <?php echo ($val->paid_yn) ? 'checked' : '';?>>  <span class="checkmark1"> </span> Paid</span>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_<?php echo $j;?>').val(0);jQuery('#price_per_tkt_<?php echo $j;?>').attr('readonly',true);" type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Free" <?php echo ($val->paid_yn) ? '' : 'checked';?>>  <span class="checkmark1"> </span> Free</span>
                              </div>
                           </div>
                           <div class="row-out">
                              <div class="row ppt" id="div_price_per_tkt_<?php echo $j;?>" style="display: <?php echo ($val->paid_yn) ? '' : 'none';?>">
                                 <label>Price Per Ticket ($CAD)*</label>
                                 <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_<?php echo $j;?>" placeholder="100.00" required class="price_class" title="Please enter Price per ticket" value="<?php echo $val->price;?>" <?php echo (isset($event_state) && $event_state == 'past') ? 'disabled' : '';?>> </p>
                              </div>
                              <div class="row qty-avi" id="div_no_of_tkt_available_<?php echo $j;?>" style="display: <?php echo ($val->bundled_yn) ? 'none' : ''?>">
                                 <label>Quantity Available*</label>
                                 <p> <input min="0" type="number" class="nota" data-count="<?php echo $j;?>" name="no_of_tkt_available[]" id="nota_<?php echo $j;?>" placeholder="100" required value="<?php echo ($val->bundled_yn) ? 0 : $val->max;?>" title="" <?php echo (isset($event_state) && $event_state == 'past') ? 'disabled' : '';?>> </p>
                              </div>
                              <div class="row brk-down">
                                 <span class="tkt-breakdown">
                                    <div class="tooltip2">
                                       Breakdown <i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                          <b>Ticket Breakdown</b>
                                          <table>
                                             <tr>
                                                <th></th>
                                                <th>Customer<br/> Pays</th>
                                                <th>You <br/>  Receive</th>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket</td>
                                                <td class="cus_tkt_price">$100.00</td>
                                                <td class="org_tkt_price">$100.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket tax </td>
                                                <td class="cus_tkt_tax">$0.00</td>
                                                <td class="org_tkt_tax">$0.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee</td>
                                                <td class="cus_fee">$0.00</td>
                                                <td class="org_fee">-$6.88</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee tax</td>
                                                <td class="cus_fee_tax">$0.00</td>
                                                <td class="org_fee_tax">-$0.89</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Total</td>
                                                <td class="cus_total bold1" >$100.00</td>
                                                <td class="org_total bold1">$92.23</td>
                                             </tr>
                                          </table>
                                       </span>
                                    </div>
                                 </span>
                                 Buyer Pays: $100; Fees: $6.88; You Receive: $92.23
                              </div>
                           </div>
                           <div class="row-out div_bundled" style="display: <?php echo ($val->bundled_yn) ? '' : 'none';?>;" id="div_bundle_<?php echo $j;?>">
                              <div class="row">
                                 <label>Tickets Per Bundle</label>
                                 <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="<?php echo $j;?>" id="tkb_<?php echo $j;?>" value="<?php echo ($val->bundled_yn) ?  $val->order_limit/$val->bundle_size : 0;?>" placeholder="0" required > x
                              </div>
                              <div class="row">
                                 <label>Bundles Available</label>
                                 <input min="0" type="number" class="tba" name="bundles_available[]" value="<?php echo ($val->bundled_yn) ? $val->bundle_size : 0;?>" data-count="<?php echo $j;?>" id="tba_<?php echo $j;?>" placeholder="100" required> =
                              </div>
                              <div class="row">
                                 <label>Total Tickets</label>
                                 <input min="0" readonly type="text" class="tbtkt" id="tbtkt_<?php echo $j;?>" name="total_tickets[]" value="<?php echo ($val->bundled_yn) ? $val->max : 0;?>" placeholder="200" required>
                              </div>
                           </div>
                           <?php if(isset($_GET['edit'])){ ?>
                           <div class="row-out">
                              <div style="width:38%;" class="row">
                                 <label>Ticket Start Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="Match Event" <?php echo $val->start == $val->event->start ? 'checked' : '';?>> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="New Start Time" <?php echo $val->start == $val->event->start ? '' : 'checked';?>> <span class="checkmark1"> </span>New Start Time </span>
                                 <div style="width: 50%; display: <?php echo $val->start == $val->event->start ? 'none' : 'block';?>;" class="row" id="div_tkt_start_date_<?php echo $j;?>">
                                    <label class="start-date" for="tkt_start_date">Start 
                                    <input type="text" id="tkt_start_date_<?php echo $j;?>" data-counter="<?php echo $j;?>" class="start_datepicker tkt_start_date" name="tkt_start_date[]" required="required"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo $val->start ? date('M d, Y h:i a', strtotime($val->start)) :  'NOT SET';?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width:38%;" class="row">
                                 <label>Ticket End Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="Match Event" <?php echo $val->end == $val->event->end ? 'checked' : '';?>> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="New End Time" <?php echo $val->end == $val->event->end ? '' : 'checked';?>> <span class="checkmark1"> </span>New End Time </span>
                                 <div style="width: 50%; display: <?php echo $val->end == $val->event->end ? 'none' : 'block';?>;" class="row" id="div_tkt_end_date_<?php echo $j;?>">
                                    <label class="start-date" for="tkt_end_date">End 
                                    <input type="text" id="tkt_end_date_<?php echo $j;?>" data-counter="<?php echo $j;?>" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo $val->end ? date('M d, Y h:i a', strtotime($val->end)) :  'NOT SET';?>" required="required">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width:24%;" class="row tlpo">
                                 <label>Ticket Limit per Order</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="no" <?php echo $val->order_limit == $val->max ? 'checked' : '' ; ?>><span class="checkmark1"> </span>No</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="yes" <?php echo $val->order_limit == $val->max ? '' : 'checked' ; ?>> <span class="checkmark1"> </span>Yes</span>
                                 <div class="row">
                                    <p><input type="number" min="0" name="tkt_order_limit[]" value="<?php echo ($val->order_limit) ? $val->order_limit : ''; ?>" id="tkt_order_limit_<?php echo $j;?>" value="0" style="display: <?php echo $val->order_limit == $val->max  ? 'none' : 'block' ; ?>; width:120px;" required="required"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width: 38%;" class="row">
                                 <label> Release Start Date & Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Immediately" <?php echo ($val->release) ? '' : 'checked';?>> <span class="checkmark1"> </span>Immediately</span>
                                 <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Scheduled" <?php echo ($val->release) ? 'checked' : '';?>> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: <?php echo ($val->release) ? '' : 'none';?>;" class="row" id="div_release_start_date_<?php echo $j;?>">
                                    <label class="start-date" for="release_start_date_<?php echo $j;?>">Start 
                                    <input type="text" id="release_start_date_<?php echo $j;?>" class="start_datepicker release_start_date" required="required" data-counter="<?php echo $j;?>" name="release_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo date('M d, Y h:i a');?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width: 38%;" class="row">
                                 <label>Expiration Start Date & Time </label>
                                 <span class="radio-chk none"> <input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="None" <?php echo $val->event->end == $val->expiration_date ? 'checked' : '';?>> <span class="checkmark1"> </span>None</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="Scheduled" <?php echo $val->event->end == $val->expiration_date ? '' : 'checked';?>> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: <?php echo $val->event->end == $val->expiration_date ? 'none' : 'block';?>;" class="row" id="div_release_end_date_<?php echo $j;?>">
                                    <label class="start-date" for="release_end_date_<?php echo $j;?>">End 
                                    <input required="required" type="text" id="release_end_date_<?php echo $j;?>" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo $val->event->end == $val->expiration_date ? 'NOT SET' :  date('M d, Y h:i a', strtotime($val->expiration_date));?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                           </div>
                           <?php }
                           if(isset($_GET['clone'])){ ?>
                           <div class="row-out">
                              <div style="width:38%;" class="row">
                                 <label>Ticket Start Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_1">
                                    <label class="start-date" for="tkt_start_date">Start <input required="required" type="text" id="tkt_start_date_1" data-counter="1" class="start_datepicker tkt_start_date" name="tkt_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                 </div>
                              </div>
                              <div style="width:38%;" class="row">
                                 <label>Ticket End Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_1">
                                    <label class="start-date" for="tkt_end_date">End <input required="required" type="text" id="tkt_end_date_1" data-counter="1" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                 </div>
                              </div>
                              <div style="width:24%;" class="row tlpo">
                                 <label>Ticket Limit per Order</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="no" <?php echo $val->order_limit == $val->max ? 'checked' : '' ; ?>><span class="checkmark1"> </span>No</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="yes" <?php echo $val->order_limit == $val->max ? '' : 'checked' ; ?>> <span class="checkmark1"> </span>Yes</span>
                                 <div class="row">
                                    <p><input type="number" min="0" name="tkt_order_limit[]" value="<?php echo ($val->order_limit) ? $val->order_limit : ''; ?>" id="tkt_order_limit_<?php echo $j;?>" value="0" style="display: <?php echo $val->order_limit == $val->max ? 'none' : 'block' ; ?>; width:120px;" required="required"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width: 38%;" class="row">
                                 <label> Release Start Date & Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_release_start_date_1">
                                    <label class="start-date" for="release_start_date">Start 
                                    <input required="required" type="text" id="release_start_date_1" class="start_datepicker release_start_date" data-counter="1" name="release_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width: 50%;" class="row">
                                 <label>Expiration Start Date & Time </label>
                                 <span class="radio-chk none"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="None" checked> <span class="checkmark1"> </span>None</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_release_end_date_1">
                                    <label class="start-date" for="release_end_date">End 
                                    <input required="required" type="text" id="release_end_date_1" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                           </div>
                            <?php $start_date = $_SESSION['event_data']['event_start_date'][0]; ?>
                         <?php $end_date = $_SESSION['event_data']['event_end_date'][count($_SESSION['event_data']['event_start_date'])-1]; ?>
                        <input type="hidden" id="EVENTSTRATDATE" value="<?php echo date('Y/m/d h:i a', strtotime($start_date)) ?>"/>
                        <input type="hidden" id="EVENTENDDATE" value="<?php echo date('Y/m/d h:i a', strtotime($end_date)) ?>"/>
                           <?php } ?>
                           
                           <div class="row-out">
                              <div class="promo_div">
                                 <label> Promo Code</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                 <span style="margin-left: 24px; margin-right: 84px;" class="radio-chk"><input class="promo_code" data-count="<?php echo $j;?>" type="radio" name="radio_promo_code_<?php echo $j;?>" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                              </div>
                           </div>
                           <div class="row-out" id="div_promo_code_1" style="display: none;">
                              <div class="row">
                                 <label>Code Name (min. 6 characters)</label>
                                 <p><input type="text" minlength="6" required="required" name="code_name[]" placeholder="SAVE10">
                              </div>
                              <div class="row">
                                 <label>Code value</label>
                                 <p><input  required="required" type="number" name="code_value[]" placeholder="10.00"> </p>
                              </div>
                           </div>
                     <!-- Creating confusion so i commented this section
                           <div class="row-out">
                              <div class="date-tkt-typ">
                                 <label> Select Date(s) for this Ticket Type</label>                               
                              </div>
                           </div>
                     -->
                        </div>
                     </div>
                     <?php if($j > 1){ ?>
                     <p style="cursor:pointer;" class="del-tkt"><span>-</span> Remove Ticket Type </p>
                     <p style="cursor:pointer;" class="clone_tkt">Clone Ticket Type</p>
                     <?php }?>                               
                  </div>
                  <?php $j++;}
                     } else { ?>
                  <div class="tkt-details"  id="tkt_1">
                     <!-- ticket detail start -->
                     <div class="accordion">
                        <div class="acc-head">
                           <div class="tkt-name">
                              <i class="fa fa-bars"></i> 
                              <div class="tkt-no">1</div>
                              <label>Ticket Name*</label>
                              <p class="tkt_name_div"><input type="text" name="ticket_name[]" value="" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                           </div>
                           <span class="t-edit"><i class="fa fa-pencil"></i></span>
                           <span class="t-clone"><i class="fa fa-clone"></i></span>
                           <div class="tickets-total-sidebar">
                              <div class="tkt-total-sold">0</div>
                              <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_1">0</span></div>
                           </div>
                        </div>
                        <div class="form-left">
                           <div class="form-right">
                              <label>% Convernience Fee Paid By You.</label>
                              <select name="select_per[]">
                                 <option value="0">0%</option>
                                 <option value="25">25%</option>
                                 <option value="50">50%</option>
                                 <option value="75">75%</option>
                                 <option value="100">100%</option>
                              </select>
                              <div class="row tx_incl">
                                 <label>Tax Inclusion</label>
                                 <div class="tooltip2"><i class="fa fa-info"></i>
                                    <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                    ADDED will display ticket price as stated.<br>
                                    INCLUDED will display ticket price before taxes.
                                    </span>
                                 </div>
                                 <select style="width: 100%;" name="tax_inclusion[]">
                                    <option value="0">No</option>
                                    <option value="1">Yes, tax ADDED to ticket price</option>
                                    <option value="2">Yes, tax INCLUDED in ticket price</option>
                                 </select>
                              </div>
                           </div>
                           <div class="d-optional">
                              <label>Details (optional)</label>
                              <p><textarea  name="ticket_details[]" value="" placeholder=" Ticket details"></textarea> </p>
                           </div>
                           <div class="row-out">
                              <div class="row-1">
                                 <label>Ticket type</label>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Single Tickets" checked="checked"> 
                                 <span class="checkmark1"> </span> Single Tickets
                                 </span>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Bundled Tickets"> 
                                 <span class="checkmark1"> </span>Bundled Tickets
                                 </span>
                                 <div class="tkt-type">
                                    Use Bundled tickets when you want to sell group tickets packages 
                                    <div class="tooltip2"><i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                       (i.e. table of 10, golf foursome, family package)
                                       </span>
                                    </div>
                                 </div>
                              </div>
                              <div class="row-2">
                                 <label>Price type</label>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_1').attr('readonly',false);" type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Paid" checked="checked">  <span class="checkmark1"> </span> Paid</span>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_1').val(0);jQuery('#price_per_tkt_1').attr('readonly',true);" type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Free" >  <span class="checkmark1"> </span> Free</span>
                              </div>
                           </div>
                           <div class="row-out">
                              <div class="row ppt" id="div_price_per_tkt_1">
                                 <label>Price Per Ticket ($CAD)*</label>
                                 <p><input required="required" min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_1" placeholder="100.00" value="0" required class="price_class" title="Please enter Price per ticket"> </p>
                              </div>
                              <div class="row qty-avi" id="div_no_of_tkt_available_1">
                                 <label>Quantity Available*</label>
                                 <p> <input required="required" min="0" type="number" class="nota" data-count="1" name="no_of_tkt_available[]" id="nota_1" placeholder="100" required value="0" title=""> </p>
                              </div>
                              <div class="row brk-down">
                                 <span class="tkt-breakdown">
                                    <div class="tooltip2">
                                       Breakdown <i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                          <b>Ticket Breakdown</b>
                                          <table>
                                             <tr>
                                                <th></th>
                                                <th>Customer<br/> Pays</th>
                                                <th>You <br/>  Receive</th>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket</td>
                                                <td>$100.00</td>
                                                <td>$100.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket tax </td>
                                                <td>$0.00</td>
                                                <td>$0.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee</td>
                                                <td>$0.00</td>
                                                <td>-$6.88</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee tax</td>
                                                <td>$0.00</td>
                                                <td>-$0.89</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Total</td>
                                                <td class="bold1" >$100.00</td>
                                                <td class="bold1">$92.23</td>
                                             </tr>
                                          </table>
                                       </span>
                                    </div>
                                 </span>
                                 Buyer Pays: $100; Fees: $6.88; You Receive: $92.23
                              </div>
                           </div>
                           <div class="row-out div_bundled" style="display: none;" id="div_bundle_1">
                              <div class="row">
                                 <label>Tickets Per Bundle</label>
                                 <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="1" id="tkb_1" value="0" placeholder="0" required> x
                              </div>
                              <div class="row">
                                 <label>Bundles Available</label>
                                 <input min="0" type="number" class="tba" name="bundles_available[]" value="0" data-count="1" id="tba_1" placeholder="100" required> =
                              </div>
                              <div class="row">
                                 <label>Total Tickets</label>
                                 <input min="0" readonly type="text" class="tbtkt" id="tbtkt_1" name="total_tickets[]" value="0" placeholder="200" required>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width:38%;" class="row">
                                 <label>Ticket Start Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_1">
                                    <label class="start-date" for="tkt_start_date">Start <input required="required" type="text" id="tkt_start_date_1" data-counter="1" class="start_datepicker tkt_start_date" name="tkt_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                 </div>
                              </div>
                              <div style="width:38%;" class="row">
                                 <label>Ticket End Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_1">
                                    <label class="start-date" for="tkt_end_date">End <input required="required" type="text" id="tkt_end_date_1" data-counter="1" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                 </div>
                              </div>
                              <div style="width:24%;" class="row tlpo">
                                 <label>Ticket Limit per Order</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="no" checked> <span class="checkmark1"> </span>No</span>
                                 <span class="radio-chk"><input type="radio" onClick="jQuery('#tkt_order_limit_1').val(jQuery('#nota_1').val());" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="yes"> <span class="checkmark1"> </span>Yes</span>
                                 <div class="row">
                                    <p><input required="required" type="number" min="0" name="tkt_order_limit[]" id="tkt_order_limit_1" value="0" style="display: none;width:120px;"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width: 38%;" class="row">
                                 <label> Release Start Date & Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_release_start_date_1">
                                    <label class="start-date" for="release_start_date">Start 
                                    <input required="required" type="text" id="release_start_date_1" class="start_datepicker release_start_date" data-counter="1" name="release_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width: 50%;" class="row">
                                 <label>Expiration Start Date & Time </label>
                                 <span class="radio-chk none"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="None" checked> <span class="checkmark1"> </span>None</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_release_end_date_1">
                                    <label class="start-date" for="release_end_date">End 
                                    <input required="required" type="text" id="release_end_date_1" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                           </div>
                           
                           <div class="row-out">
                              <div class="promo_div">
                                 <label> Promo Code</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                 <span style="margin-left: 24px; margin-right: 84px;" class="radio-chk"><input class="promo_code" data-count="1" type="radio" name="radio_promo_code_1" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                              </div>
                           </div>
                           <div class="row-out" id="div_promo_code_1" style="display: none;">
                              <div class="row">
                                 <label>Code Name (min. 6 characters)</label>
                                 <p><input required="required" minlength="6" type="text" name="code_name[]" placeholder="SAVE10">
                              </div>
                              <div class="row">
                                 <label>Code value</label>
                                 <p><input required="required" type="number" name="code_value[]" placeholder="10.00"> </p>
                              </div>
                           </div>
                     <!-- Creating confusion so i commented this section
                           <div class="row-out">
                              <div class="date-tkt-typ">
                                 <label> Select Date(s) for this Ticket Type</label>                                        
                              </div>
                           </div>
                     -->
                        </div>
                     </div>
                  </div>
                  <?php }?>                 
                  <!-- Right form End -->
                  <!-- ticket detail end -->
                  <p class="add-new" style="cursor:pointer;" id="add_more_tkt"><span>+</span> Add New Ticket Type</p>
               </div>
               <!-- <div class="help-btn"><i class="fa fa-question"></i> Need Help! <a href="#">Visit our support site for answers</a></div>
               <button class="next-btn" type="submit" name="btnTicketSubmit">NEXT</button>
               <a href="<?php //echo site_url()?>/event-dashboard?page_id=304"><button class="next-btn cancel-btn" type="button" style="margin: 6px; padding-bottom: 8px;">CANCEL</button></a> -->
               <?php } else { ?>
               <input type="hidden" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['count'] : 1;?>" id="count" name="count">
               <div class="tkt_avail">
                  <div class="h-left">
                     <h3> Enter total tickets available for all ticket types </h3>
                     <input min="0" required="required" type="number" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['total_ticket_available'] : 0;?>" id="total_ticket_available" name="total_ticket_available">
                  </div>
                  <p class="help-text">Why do we ask this? <br/> To prevent over selling of required tickets via multiple ticket types.</p>
               </div>
               <div class="tkt_avail">
                  <div class="h-left">
                     <h3> Current ticket allocation </h3>
                     <span id="current_ticket_allocation"><?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['current_ticket_allocation'] : 0;?></span>
                     <input type="hidden" name="current_ticket_allocation" id="hidden_current_ticket_allocation" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['current_ticket_allocation'] : 0;?>">
                  </div>
                  <p class="help-text">Why do we display this?<br/>To monitor your total ticket distribution against your total tickets availabe as shown above
                     <span class="current-tkt"><i class="fa fa-search"></i> Current Ticket Report</span>
                  </p>
               </div>
               <div class="tkt_avail">
                  <h3 style="width:44%;text-align: right;">Do you need to charge tax for this event?</h3>
                  <div class="tax-outer">
                     <select class="charge-tax" name="tkt_tax">
                        <option value="no" <?php echo isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['tkt_tax'] == "no") ? 'selected' : '';?>>No</option>
                        <option value="yes" <?php echo isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['tkt_tax'] == "yes") ? 'selected' : '';?>>Yes</option>
                     </select>
                     <div class="tooltip2"><i class="fa fa-info"></i>
                        <span class="tooltiptext2"><b>Tax Information</b><br>
                        The application of taxes on this event is subject to the nature of your event, your tax status, location of event and other factors that may determine the inclusion of a tax rate. Please consult with a tax specialist regarding your taxation requirements for collection and remittance
                        purposes.
                        <br>
                        Any information provided will be displayed on all ticket invoices and reports.
                        </span>
                     </div>
                  </div>
                  <div class="tax-yes" style="display: <?php echo isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['tkt_tax'] == "yes") ? '' : 'none';?>;">
                     <label>Country</label>
                     <select name="country">
                        <option value="2" <?php echo  isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['country'] == 2) ? 'selected' : '';?>>Canada</option>
                        <option value="3" <?php echo  isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['country'] == 3) ? 'selected' : '';?>>United States</option>
                        <?php /* foreach($countries as $row) { ?>
                        <option value="<?php echo $row->id?>" <?php echo  isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['country'] == $row->id) ? 'selected' : '';?>><?php echo $row->name;?></option>
                        <?php } */ ?>
                     </select>
                     <label> Tax ID <input required="required" type="text" placeholder="Id" name="tax_id" id="tax_id" required title="Please enter Tax ID" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['tax_id'] : '';?>"> </label>
                     <label> Tax Name <input required="required" type="text" placeholder="Name" name="tax_name" id="tax_name" required title="Please enter Tax Name" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['tax_name'] : '';?>"> </label>
                     <label> Tax Rate <input required="required" type="number" placeholder="Rate" min="0" name="tax_rate" id="tax_rate" required title="Please enter Tax Rate" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['tax_rate'] : '';?>"> % </label><span class="tax-rate">Select taxation option for each ticket type setup below.</span>
                  </div>
               </div>
               <div class="tkt_avail">
                  <h3 style="width:44%;text-align: right;">Do you need to offer a Charitable Tax Receipt?</h3>
                  <div class="tax-outer charitable">
                     <select name="charitablereceipt" class="charge-tax2 Charitable">
                        <option value="no">No</option>
                        <option value="yes">Yes</option>
                     </select>
                     <div style="display:none;" class="one-full"><label>Charitable Registration # <input required="required" type="text" placeholder="Charitable Registration" name="charitableregistration" id="" required="" title="Please enter your Charitable Registration # " value=""> </label></div>
                     <div class="tooltip2"><i class="fa fa-info"></i>
                        <span class="tooltiptext2">
                        Checking this box will add an additional step to the ticket purchasing process for this event. A ticket buyer, requesting a Charitable Tax Receipt, will be able to enter their full name and address, as required by their local Tax Agency. 
                        <br>
                        This information will be retrievable by you via the Sales Report for this specific event from Manage My Events.
                        </span>
                     </div>
                  </div>
               </div>
               <hr/>
               <p><b>All required fields marked with (*).</b></p>
               <br/>
               <div id="div_ticket">
                  <?php if(isset($_SESSION['ticket_data'])){
                     $j=1;
                     foreach($_SESSION['ticket_data']['ticket_name'] as $key=>$val) { ?>
                  <div class="tkt-details"  id="tkt_<?php echo $j; ?>">
                     <!-- ticket detail start -->
                     <div class="accordion">
                        <div class="acc-head">
                           <div class="tkt-name">
                              <i class="fa fa-bars"></i> 
                              <div class="tkt-no"><?php echo $j;?></div>
                              <label>Ticket Name*</label>
                              <p  class="tkt_name_div"><input type="text" name="ticket_name[]" value="<?php echo $_SESSION['ticket_data']['ticket_name'][$key]?>" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                           </div>
                           <span class="t-edit"><i class="fa fa-pencil"></i></span>
                           <span class="t-clone"><i class="fa fa-clone"></i></span>
                           <div class="tickets-total-sidebar">
                              <div class="tkt-total-sold">0</div>
                              <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_<?php echo $j;?>"><?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? $_SESSION['ticket_data']['no_of_tkt_available'][$key] : $_SESSION['ticket_data']['total_tickets'][$key];?></span></div>
                           </div>
                           <div class="s_h-arrow mvright"></div>
                        </div>
                        <div class="form-left">
                           <div class="form-right">
                              <label>% Convernience Fee Paid By You.</label>
                              <select name="select_per[]">
                                 <option value="0">0%</option>
                                 <option value="25">25%</option>
                                 <option value="50">50%</option>
                                 <option value="75">75%</option>
                                 <option value="100">100%</option>
                              </select>
                              <div class="row tx_incl">
                                 <label>Tax Inclusion</label>
                                 <div class="tooltip2"><i class="fa fa-info"></i>
                                    <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                    ADDED will display ticket price as stated.<br>
                                    INCLUDED will display ticket price before taxes.
                                    </span>
                                 </div>
                                 <select style="width: 100%;" name="tax_inclusion[]">
                                    <option value="0" <?php echo ($_SESSION['ticket_data']['tax_inclusion'][$key] == 'No') ? 'selected' : '';?>>No</option>
                                    <option value="1" <?php echo ($_SESSION['ticket_data']['tax_inclusion'][$key] == 'Yes, tax ADDED to ticket price') ? 'selected' : '';?>>Yes, tax ADDED to ticket price</option>
                                    <option value="2" <?php echo ($_SESSION['ticket_data']['tax_inclusion'][$key] == 'Yes, tax INCLUDED in ticket price') ? 'selected' : '';?>>Yes, tax INCLUDED in ticket price</option>
                                 </select>
                              </div>
                           </div>
                           <div class="d-optional">
                              <label>Details (optional)</label>
                              <p><textarea name="ticket_details[]" value="<?php echo $_SESSION['ticket_data']['ticket_details'][$key]?>" placeholder=" Ticket details"> </textarea></p>
                           </div>
                           <div class="row-out">
                              <div class="row-1">
                                 <label>Ticket type</label>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Single Tickets" <?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 'checked' : '';?>> <span class="checkmark1"> </span> Single Tickets
                                 </span>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Bundled Tickets" <?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? '' : 'checked';?>> <span class="checkmark1"> </span>Bundled Tickets
                                 </span>
                                 <div class="tkt-type">
                                    Use Bundled tickets when you want to sell group tickets packages 
                                    <div class="tooltip2"><i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                       (i.e. table of 10, golf foursome, family package)
                                       </span>
                                    </div>
                                 </div>
                              </div>
                              <div class="row-2">
                                 <label>Price type</label>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_<?php echo $j;?>').attr('readonly',false);" type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Paid" <?php echo ($_SESSION['ticket_data']['price_radio_'.$j] == 'Paid') ? 'checked' : '';?>>  <span class="checkmark1"> </span> Paid</span>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_<?php echo $j;?>').val(0);jQuery('#price_per_tkt_<?php echo $j;?>').attr('readonly',true);" type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Free" <?php echo ($_SESSION['ticket_data']['price_radio_'.$j] == 'Paid') ? '' : 'checked';?>>  <span class="checkmark1"> </span> Free</span>
                              </div>
                           </div>
                           <div class="row-out">
                              <div class="row ppt" id="div_price_per_tkt_<?php echo $j;?>">
                                 <label>Price Per Ticket ($CAD)*</label>
                                 <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_<?php echo $j;?>" placeholder="100.00" required class="price_class" title="Please enter Price per ticket" value="<?php echo ($_SESSION['ticket_data']['price_radio_'.$j] == 'Paid') ?  $_SESSION['ticket_data']['price_per_tkt'][$key] : 0;?>"> </p>
                              </div>
                              <div class="row qty-avi" id="div_no_of_tkt_available_<?php echo $j;?>">
                                 <label>Quantity Available*</label>
                                 <p> <input min="0" type="number" class="nota" data-count="<?php echo $j;?>" name="no_of_tkt_available[]" id="nota_<?php echo $j;?>" placeholder="100" required value="<?php echo $_SESSION['ticket_data']['no_of_tkt_available'][$key];?>" title=""> </p>
                              </div>
                              <div class="row brk-down">
                                 <span class="tkt-breakdown">
                                    <div class="tooltip2">
                                       Breakdown <i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                          <b>Ticket Breakdown</b>
                                          <table>
                                             <tr>
                                                <th></th>
                                                <th>Customer<br/> Pays</th>
                                                <th>You <br/>  Receive</th>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket</td>
                                                <td>$100.00</td>
                                                <td>$100.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket tax </td>
                                                <td>$0.00</td>
                                                <td>$0.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee</td>
                                                <td>$0.00</td>
                                                <td>-$6.88</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee tax</td>
                                                <td>$0.00</td>
                                                <td>-$0.89</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Total</td>
                                                <td class="bold1" >$100.00</td>
                                                <td class="bold1">$92.23</td>
                                             </tr>
                                          </table>
                                       </span>
                                    </div>
                                 </span>
                                 Buyer Pays: $100; Fees: $6.88; You Receive: $92.23
                              </div>
                           </div>
                           <div class="row-out div_bundled" style="display: <?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 'none' : '';?>;" id="div_bundle_<?php echo $j;?>">
                              <div class="row">
                                 <label>Tickets Per Bundle</label>
                                 <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="<?php echo $j;?>" id="tkb_<?php echo $j;?>" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 0 : $_SESSION['ticket_data']['ticket_per_bundle'][$key];?>" placeholder="0" required> x
                              </div>
                              <div class="row">
                                 <label>Bundles Available</label>
                                 <input min="0" type="number" class="tba" name="bundles_available[]" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 0 : $_SESSION['ticket_data']['bundles_available'][$key];?>" data-count="<?php echo $j;?>" id="tba_<?php echo $j;?>" placeholder="100" required> =
                              </div>
                              <div class="row">
                                 <label>Total Tickets</label>
                                 <input min="0" type="text" class="tbtkt" id="tbtkt_<?php echo $j;?>" name="total_tickets[]" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 0 : $_SESSION['ticket_data']['total_tickets'][$key];?>" placeholder="200" required>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width:38%;" class="row">
                                 <label>Ticket Start Time</label>
                                 <span class="radio-chk"><input  type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="Match Event" <?php echo ($_SESSION['ticket_data']['radio_tkt_start_time_'.$j] == 'Match Event') ? 'checked' : '';?>> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="New Start Time" <?php echo ($_SESSION['ticket_data']['radio_tkt_start_time_'.$j] == 'New Start Time') ? 'checked' : '';?>> <span class="checkmark1"> </span>New Start Time </span>
                                 <div style="width: 50%; display: <?php echo ($_SESSION['ticket_data']['radio_tkt_start_time_'.$j] == 'New Start Time') ? '' : 'none';?>;" class="row" id="div_tkt_start_date_<?php echo $j;?>">
                                    <label class="start-date" for="tkt_start_date">Start 
                                    <input required="required" type="text" id="tkt_start_date_<?php echo $j;?>" class="start_datepicker tkt_start_date" data-counter="<?php echo $j;?>" name="tkt_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['tkt_start_date'][$key] == 'NOT SET') ? 'NOT SET' :  $_SESSION['ticket_data']['tkt_start_date'][$key];?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width:38%;" class="row">
                                 <label>Ticket End Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="Match Event" <?php echo ($_SESSION['ticket_data']['radio_tkt_end_time_'.$j] == 'Match Event') ? 'checked' : '';?>> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="New End Time" <?php echo ($_SESSION['ticket_data']['radio_tkt_end_time_'.$j] == 'New End Time') ? 'checked' : '';?>> <span class="checkmark1"> </span>New End Time </span>
                                 <div style="width: 50%; display: <?php echo ($_SESSION['ticket_data']['radio_tkt_end_time_'.$j] == 'New End Time') ? '' : 'none';?>;" class="row" id="div_tkt_end_date_<?php echo $j;?>">
                                    <label class="start-date" for="tkt_end_date">End 
                                    <input required="required" type="text" id="tkt_end_date_<?php echo $j;?>" class="start_datepicker tkt_end_date" name="tkt_end_date[]" data-counter="<?php echo $j;?>" style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['tkt_end_date'][$key] == 'NOT SET') ? 'NOT SET' :  $_SESSION['ticket_data']['tkt_end_date'][$key];?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width:24%;" class="row tlpo">
                                 <label>Ticket Limit per Order</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="no" <?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'no') ? 'checked' : '';?>> <span class="checkmark1"> </span>No</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="yes" <?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'yes') ? 'checked' : '';?>> <span class="checkmark1"> </span>Yes</span>
                                 <div class="row">
                                    <p><input required="required" type="number" min="0" name="tkt_order_limit[]" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'yes') ? $_SESSION['ticket_data']['tkt_order_limit'][$key] : '';?>" id="tkt_order_limit_<?php echo $j;?>" value="0" style="width:120px;display: <?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'yes') ? '' : 'none';?>;"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width: 38%;" class="row">
                                 <label> Release Start Date & Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Immediately" <?php echo ($_SESSION['ticket_data']['radio_release_time_'.$j] == 'Immediately') ? 'checked' : '';?>> <span class="checkmark1"> </span>Immediately</span>
                                 <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Scheduled" <?php echo ($_SESSION['ticket_data']['radio_release_time_'.$j] == 'Scheduled') ? 'checked' : '';?>> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: <?php echo ($_SESSION['ticket_data']['radio_release_time_'.$j] == 'Scheduled') ? '' : 'none';?>;" class="row" id="div_release_start_date_<?php echo $j;?>">
                                    <label class="start-date" for="release_start_date">Start 
                                    <input required="required" type="text" id="release_start_date_<?php echo $j;?>" data-counter="<?php echo $j;?>" class="start_datepicker release_start_date" name="release_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['release_start_date'][$key] == 'NOT SET') ? 'NOT SET' : $_SESSION['ticket_data']['release_start_date'][$key];?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width: 38%;" class="row">
                                 <label>Expiration Start Date & Time </label>
                                 <span class="radio-chk none"> <input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="None" <?php echo ($_SESSION['ticket_data']['radio_expiration_time_'.$j] == 'None') ? 'checked' : '';?>> <span class="checkmark1"> </span>None</span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="Scheduled" <?php echo ($_SESSION['ticket_data']['radio_expiration_time_'.$j] == 'Scheduled') ? 'checked' : '';?>> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: <?php echo ($_SESSION['ticket_data']['radio_expiration_time_'.$j] == 'Scheduled') ? '' : 'none';?>;" class="row" id="div_release_end_date_1">
                                    <label class="start-date" for="release_end_date">End 
                                    <input required="required" type="text" id="release_end_date_<?php echo $j;?>" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['release_end_date'][$key] == 'NOT SET') ? 'NOT SET' : $_SESSION['ticket_data']['release_end_date'][$key];?>">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                           </div>
                           
                           <div class="row-out">
                              <div class="promo_div">
                                 <label> Promo Code</label>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                 <span style="margin-left: 24px; margin-right: 84px;" class="radio-chk"><input class="promo_code" data-count="<?php echo $j;?>" type="radio" name="radio_promo_code_<?php echo $j;?>" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                 <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                              </div>
                           </div>
                           <div class="row-out" id="div_promo_code_1" style="display: none;">
                              <div class="row">
                                 <label>Code Name (min. 6 characters)</label>
                                 <p><input required="required" minlength="6" type="text" name="code_name[]" placeholder="SAVE10">
                              </div>
                              <div class="row">
                                 <label>Code value</label>
                                 <p><input required="required" type="number" name="code_value[]" placeholder="10.00"> </p>
                              </div>
                           </div>
                    
                           <div class="row-out">
                              <div class="date-tkt-typ">
                                 <label> Select Date(s) for this Ticket Type</label>
                                 <?php  
                         $i=1; 
                         foreach($_SESSION['event_data']['event_start_date'] as $key=>$val) { 
                           $start_date = $_SESSION['event_data']['event_start_date'][$key];    
                           $end_date = $_SESSION['event_data']['event_end_date'][$key];
                           if(date('Y-m-d', strtotime($start_date)) == date('Y-m-d', strtotime($end_date))) {
                              $selctdatae = $start_date.' '.'to'.' '.date('h:i a', strtotime($end_date));
                           }else{
                              $selctdatae = $start_date.' '.'to'.' '.$end_date;
                           }
                         ?>
                                 <span class="chkbox">
                                 <input type="checkbox" value="<?php echo $selctdatae; ?>" <?php if($i==1) echo 'checked' ?> name="ticket_type_dates[<?php echo $j;?>][]">
                                 <span class="checkmark"></span> 
                           <?php echo $selctdatae; ?>
                                 </span>
                                 <?php $i++;
                         }  ?>                                
                              </div>
                           </div>
                     
                        </div>
                     </div>
                  </div>
                  <?php $j++;
                     }
                     
                     } else { ?>
                  <div class="tkt-details"  id="tkt_1">
                     <!-- ticket detail start -->
                     <div class="accordion">
                        <div class="acc-head acc-head1">
                           <div class="tkt-name">
                              <i class="fa fa-bars"></i> 
                              <div class="tkt-no">1</div>
                              <label>Ticket Name*</label>
                              <p  class="tkt_name_div"><input type="text" class="t-name" name="ticket_name[]" value="" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                           </div>
                           <span class="t-edit"><i class="fa fa-pencil"></i></span>
                           <span class="t-clone"><i class="fa fa-clone"></i></span>
                           <div class="tickets-total-sidebar">
                              <div class="tkt-total-sold">0</div>
                              <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_1">0</span></div>
                           </div>
                           <div class="s_h-arrow"></div>
                        </div>
                        <div class="form-left">
                           <div class="form-right">
                              <label>% Convernience Fee Paid By You.</label>
                              <select name="select_per[]">
                                 <option value="0">0%</option>
                                 <option value="25">25%</option>
                                 <option value="50">50%</option>
                                 <option value="75">75%</option>
                                 <option value="100">100%</option>
                              </select>
                              <div class="row tx_incl">
                                 <label>Tax Inclusion</label>
                                 <div class="tooltip2"><i class="fa fa-info"></i>
                                    <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                    ADDED will display ticket price as stated.<br>
                                    INCLUDED will display ticket price before taxes.
                                    </span>
                                 </div>
                                 <select style="width: 100%;" name="tax_inclusion[]">
                                    <option value="0">No</option>
                                    <option value="1">Yes, tax ADDED to ticket price</option>
                                    <option value="2">Yes, tax INCLUDED in ticket price</option>
                                 </select>
                              </div>
                           </div>
                           <div class="d-optional">
                              <label>Details (optional)</label>
                              <p><textarea  name="ticket_details[]" value="" placeholder=" Ticket details"></textarea> </p>
                           </div>
                           <div class="row-out">
                              <div class="row-1">
                                 <label>Ticket type</label>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Single Tickets" checked="checked"> 
                                 <span class="checkmark1"> </span> Single Tickets
                                 </span>
                                 <span class="radio-chk">
                                 <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Bundled Tickets"> 
                                 <span class="checkmark1"> </span>Bundled Tickets
                                 </span>
                                 <div class="tkt-type">
                                    Use Bundled tickets when you want to sell group tickets packages  
                                    <div class="tooltip2"><i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                       (i.e. table of 10, golf foursome, family package)
                                       </span>
                                    </div>
                                 </div>
                              </div>
                              <div class="row-2">
                                 <label>Price type</label>
                                 <span class="radio-chk"><input onClick="jQuery('#price_per_tkt_1').attr('readonly',false);" type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Paid" checked="checked">  <span class="checkmark1"> </span> Paid</span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Free" >  <span class="checkmark1"> </span> Free</span>
                              </div>
                           </div>
                           <div class="row-out">
                              <div class="row ppt" id="div_price_per_tkt_1">
                                 <label>Price Per Ticket ($CAD)*</label>
                                 <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_1" placeholder="100.00" required class="price_class" title="Please enter Price per ticket" value="0"> </p>
                              </div>
                              <div class="row qty-avi" id="div_no_of_tkt_available_1">
                                 <label>Quantity Available*</label>
                                 <p> <input min="0" type="number" class="nota" data-count="1" name="no_of_tkt_available[]" id="nota_1" placeholder="100" required value="0" title=""> </p>
                              </div>
                              <div class="row brk-down">
                                 <span class="tkt-breakdown">
                                    <div class="tooltip2">
                                       Breakdown <i class="fa fa-info"></i>
                                       <span class="tooltiptext2">
                                          <b>Ticket Breakdown</b>
                                          <table>
                                             <tr>
                                                <th></th>
                                                <th>Customer<br/> Pays</th>
                                                <th>You <br/>  Receive</th>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket</td>
                                                <td>$100.00</td>
                                                <td>$100.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Ticket tax </td>
                                                <td>$0.00</td>
                                                <td>$0.00</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee</td>
                                                <td>$0.00</td>
                                                <td>-$6.88</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Fee tax</td>
                                                <td>$0.00</td>
                                                <td>-$0.89</td>
                                             </tr>
                                             <tr>
                                                <td class="bold">Total</td>
                                                <td class="bold1" >$100.00</td>
                                                <td class="bold1">$92.23</td>
                                             </tr>
                                          </table>
                                       </span>
                                    </div>
                                 </span>
                                 Buyer Pays: $100; Fees: $6.88; You Receive: $92.23
                              </div>
                           </div>
                           <div class="row-out div_bundled" style="display: none;" id="div_bundle_1">
                              <div class="row">
                                 <label>Tickets Per Bundle</label>
                                 <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="1" id="tkb_1" value="0" placeholder="0" required> x
                              </div>
                              <div class="row">
                                 <label>Bundles Available</label>
                                 <input min="0" type="number" class="tba" name="bundles_available[]" value="0" data-count="1" id="tba_1" placeholder="100" required> =
                              </div>
                              <div class="row">
                                 <label>Total Tickets</label>
                                 <input min="0" readonly type="text" class="tbtkt" id="tbtkt_1" name="total_tickets[]" value="0" placeholder="200" required>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width:38%;" class="row">
                                 <label>Ticket Start Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_1">
                                    <label class="start-date" for="tkt_start_date">Start <input required type="text" id="tkt_start_date_1" class="start_datepicker tkt_start_date" name="tkt_start_date[]" data-counter="1"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                 </div>
                              </div>
                              <div style="width:38%;" class="row">
                                 <label>Ticket End Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_1">
                                    <label class="start-date" for="tkt_end_date">End <input required type="text" id="tkt_end_date_1" class="start_datepicker tkt_end_date" data-counter="1" name="tkt_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                 </div>
                              </div>
                              <div style="width:24%;" class="row tlpo">
                                 <label>Ticket Limit per Order</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="no" checked> <span class="checkmark1"> </span>No</span>
                                 <span class="radio-chk"><input type="radio" data-count="1" onClick="jQuery('#tkt_order_limit_1').val(jQuery('#nota_1').val());" class="radio_tkt_limit" name="radio_tkt_limit_1" value="yes"> <span class="checkmark1"> </span>Yes</span>
                                 <div class="row">
                                    <p><input required type="number" min="0" name="tkt_order_limit[]" id="tkt_order_limit_1" value="0" style="display: none;width:120px;"></p>
                                 </div>
                              </div>
                           </div>
                           <div class="row-out">
                              <div style="width: 38%;" class="row">
                                 <label> Release Start Date & Time</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>
                                 <span class="radio-chk"> <input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_release_start_date_1">
                                    <label class="start-date" for="release_start_date">Start 
                                    <input required type="text" id="release_start_date_1" data-counter="1" class="start_datepicker release_start_date" name="release_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                              <div style="width: 50%;" class="row">
                                 <label>Expiration Start Date & Time </label>
                                 <span class="radio-chk none"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="None" checked> <span class="checkmark1"> </span>None</span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                 <div style="width: 50%; display: none;" class="row" id="div_release_end_date_1">
                                    <label class="start-date" for="release_end_date">End 
                                    <input required type="text" id="release_end_date_1" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET">
                                    <small style="font-size: 12px;">Select to change</small>
                                    </label>
                                 </div>
                              </div>
                           </div>
                     
                           <div class="row-out">
                              <div class="promo_div">
                                 <label> Promo Code</label>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                 <span style="margin-left: 24px; margin-right: 84px;" class="radio-chk"><input class="promo_code" data-count="1" type="radio" name="radio_promo_code_1" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                 <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                              </div>
                           </div>
                           <div class="row-out" id="div_promo_code_1" style="display: none;">
                              <div class="row">
                                 <label>Code Name (min. 6 characters)</label>
                                 <p><input required type="text" minlength="6" name="code_name[]" placeholder="SAVE10">
                              </div>
                              <div class="row">
                                 <label>Code value</label>
                                 <p><input required type="number" name="code_value[]" placeholder="10.00"> </p>
                              </div>
                           </div>
                    
                    <div class="row-out">
                              <div class="date-tkt-typ">
                                 <label> Select Date(s) for this Ticket Type</label>
                                 <?php  
                         $i=1; 
                         foreach($_SESSION['event_data']['event_start_date'] as $key=>$val) { 
                           $start_date = $_SESSION['event_data']['event_start_date'][$key];    
                           $end_date = $_SESSION['event_data']['event_end_date'][$key];
                           if(date('Y-m-d', strtotime($start_date)) == date('Y-m-d', strtotime($end_date))) {
                              $selctdatae = $start_date.' '.'to'.' '.date('h:i a', strtotime($end_date));
                           }else{
                              $selctdatae = $start_date.' '.'to'.' '.$end_date;
                           }
                         ?>
                                 <span class="chkbox">
                                 <input type="checkbox" value="<?php echo $selctdatae; ?>" <?php if($i==1) echo 'checked' ?> name="ticket_type_dates[1][]">
                                 <span class="checkmark"></span> 
                           <?php echo $selctdatae; ?>
                                 </span>
                                 <?php $i++;
                         }  ?> 
                         <?php $start_date = $_SESSION['event_data']['event_start_date'][0]; ?>
                         <?php $end_date = $_SESSION['event_data']['event_end_date'][count($_SESSION['event_data']['event_start_date'])-1]; ?>
                        <input type="hidden" id="EVENTSTRATDATE" value="<?php echo date('Y/m/d h:i a', strtotime($start_date)) ?>"/>
                        <input type="hidden" id="EVENTENDDATE" value="<?php echo date('Y/m/d h:i a', strtotime($end_date)) ?>"/>
                              </div>
                           </div>
                     
                        </div>
                  <p style="cursor:pointer;" class="del-tkt" data-cnt="1"><span>-</span> Remove Ticket Type </p>
                        <p style="cursor:pointer;" class="clone_tkt">Clone Ticket Type</p>
                     </div>
                  </div>
                  <?php }?>                 
                  <!-- Right form End -->
                  <!-- ticket detail end -->
                  <p class="add-new" style="cursor:pointer; <?php echo (isset($event_state) && $event_state == 'past') ? 'display:none;' : '';?>" id="add_more_tkt" ><span>+</span> Add New Ticket Type</p>
               </div>
               <?php }?>
            </div>
            <div class="third-party" style="display: <?php echo isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'Yes 3rd party' ? 'block' : 'none' ;?>;">
               <div class="form-left party_setup" style="padding: 0px;">
                  <div class="ticket-setup">
                     <h3><?php echo get_post_meta(364, 'tix_left_title', TRUE);?>
                        <label class="switch">
                        <input type="checkbox" class="setup_switch">
                        <span class="slider1 round"></span>
                        </label>
                     </h3>
                     <p><?php echo get_post_meta(364, 'tix_left_content', TRUE);?>
                     </p>
                  </div>
                  <div class="web-url">
                     <h3><?php echo get_post_meta(364, 'tix_third_party_title', TRUE);?></h3>
                     <select name="thirdpartyurl" id="thirdpartyurl">
                        <?php echo isset($_SESSION['ticket_data']['thirdpartyurl']) ? "<option value='".$_SESSION['ticket_data']['thirdpartyurl']."'>".$_SESSION['ticket_data']['thirdpartyurl']."</option>" : '' ; ?>
                        <option value="http://">http://</option>
                        <option value="https://">https://</option>
                     </select>
                     <input style="width:85%;" type="text" name="turl" id="turl" placeholder="URL" value="<?php echo isset($_SESSION['ticket_data']['turl']) ? $_SESSION['ticket_data']['turl'] : ''; ?>">
                  </div>
                  <label id="turlerrorr" class="error" for="turl"></label>
               </div>
               <div class="form-right get-tix">
                  <!-- <p><img width="100px" src="<?php //echo site_url(); ?>/wp-content/uploads/2019/09/tix.png"></p> -->
                  <p><img width="100px" src="<?php echo wp_get_attachment_url(get_post_meta(364, 'tix_image', TRUE)) ;?>"></p>
                  <p><?php echo get_post_meta(364, 'tix_right_content1', TRUE) ;?></p>
                  <p><?php echo get_post_meta(364, 'tix_right_content2', TRUE) ;?></p>
                  <b><a href="tel:555-555-5555"><?php echo get_post_meta(364, 'tix_phone_no', TRUE) ;?></a></b>
               </div>
            </div>
            <!--#third-party end -->
            <div class="help-btn"><i class="fa fa-question"></i> Need Help! <a href="#">Visit our support site for answers</a></div>
            <!-- <button onClick="history.go(-1);" class="back-btn" name="btnTicketback">BACK</button> -->
            <?php if(isset($_GET['edit']) && isset($_SESSION['eventstate'])){ ?>
            <a href="<?php echo site_url().'/edit-event?eventstate='.$_SESSION['eventstate'].'&event_id='.$_GET['edit']; ?>" id="back_page" class="back-btn">BACK</a>
            <?php }else{ ?>
            <a href="<?php echo site_url().'/create-event/'; ?>" id="back_page" class="back-btn">BACK</a>
            <?php } ?>
            <button class="next-btn" type="submit" name="btnTicketSubmit">NEXT</button>
            <a href="<?php echo site_url()?>?page_id=307">
            <button class="next-btn cancel-btn" type="button" style="margin: 6px; padding-bottom: 8px;">CANCEL</button>
            </a>
         </form>
      </div>
      <!-- #container end -->
   </div>
   <!-- # outer-wrapper end-->
</div>
<!-- #main content end -->
<div class="modal" id="loadingModal" role="dialog">
   <div class="modal-dialog modal-lg" style="width: 220px !important;">
      <div class="modal-content">
         <div class="modal-body">
            <div class="email-confomation">
               <p class="mail-img" style="padding: 0px;"><img src="<?php echo site_url(); ?>/wp-content/uploads/loading.gif"></p>
               <p id="modal_loader_text"></p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- #main content end -->
<div class="modal" id="DeleteTicketModal" role="dialog">
   <div class="modal-dialog modal-lg" style="max-width: 320px !important;">
      <div class="modal-content">
         <div class="modal-body">
            <div class="email-confomation">
               <p id="modal_loader_text">Are you sure you would like to remove this ticket type?</p>
            <button class="next-btn cancel-btn" type="button" style="margin: 6px; padding-bottom: 8px;" onClick="$('#DeleteTicketModal').hide();">CANCEL</button>
            <button class="next-btn" type="button" id="yesDELETTICk">Yes</button>
            </div>
         </div>
      </div>
   </div>
</div>
<?php if(isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'No'){ ?>
                <script>
                 //   $('.ticket-setup-options').find('input').val('');
                 //   $('.third-party').find('input').val('');
                </script>
            <?php }else if(isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'Yes Tix'){ ?>
                <script>
                   // $('.third-party').find('input').val('');
                </script>
            <?php }else if(isset($_SESSION['ticket_data']) && $_SESSION['ticket_data']['tkt_setup'] == 'Yes 3rd party'){ ?>
                <script>
                    //$('.ticket-setup-options').find('input').val('');
                </script>
            <?php }
            ?>
<?php echo (isset($event_state) && $event_state == 'past') ? '<script>$("input:radio").attr("disabled",true);
$("input:text").attr("disabled",true);
$("select").attr("disabled",true);
</script>' : '';?>
<script src="<?php echo site_url()?>/wp-content/themes/Divi Child/js/ticketpagescript.js"></script>
<?php get_footer(); ?>
<script>
$(document).on('click', '#add_more_tkt', function () {
   var count = $('#count').val();
   count = parseInt(count)+parseInt(1);
   $('#count').val(count);       var current_ticket_allocation = $('#current_ticket_allocation').text();
       var html = '<div class="tkt-details"    id="tkt_'+count+'">\n '+
           '             <div class="accordion">   \n'+
           '                <div class="acc-head"> \n'+
       
           '              <div class="tkt-name"> <i class="fa fa-bars"></i> <div class="tkt-no">'+count+'</div> \n' +
           '               <p class="tkt_name_div"><input required type="text" name="ticket_name[]" class="t-name" value="" placeholder="Ticket Name" title="Please enter Ticket Name"> </p> \n'+
                           
           '                </div> \n'+
           '                <span class="t-edit"><i class="fa fa-pencil"></i></span> \n'+
   
           '                <span class="t-clone"><i class="fa fa-clone"></i></span> \n'+
   
           '             <div class="tickets-total-sidebar">\n' +
   
         
   
           '                    <div class="tkt-total-sold">0</div>\n' +
   
           '                    <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_'+count+'">0</span></div>\n' +
   
           '                </div>\n' +
           '<div class="s_h-arrow acc-head'+count+'"></div>\n'+
           '                </div>\n' +
   
           '               <div class="form-left">\n'+
   
   '               <div class="form-right">\n'+
   
       '                  <label>% Convernience Fee Paid By You.</label>\n'+
   
       '                  <select name="select_per[]">\n'+
   
       '                     <option value="0">0%</option>\n'+
   
       '                     <option value="25">25%</option>\n'+
   
       '                     <option value="50">50%</option>\n'+
   
       '                     <option value="75">75%</option>\n'+
   
       '                     <option value="100">100%</option>\n'+
   
       '                  </select>\n'+
       
       '                     <div class="row tx_incl">\n'+
   
       '                           <label>Tax Inclusion</label>\n'+
        '                           <div class="tooltip2"><i class="fa fa-info"></i>\n'+  
   
       '                               <span class="tooltiptext2"><b>Tax Inclusion</b><br>\n'+ 
   
       '                                    ADDED will display ticket price as stated.<br>\n'+
   
       '                                     INCLUDED will display ticket price before taxes.\n'+
   
       '                               </span>\n'+
   
       '                           </div>\n'+ 
   
       '                           <select style="width: 100%;" name="tax_inclusion[]">\n'+
   
       '                               <option value="0">No</option>\n'+
   
       '                               <option value="1">Yes, tax ADDED to ticket price</option>\n'+
   
       '                               <option value="2">Yes, tax INCLUDED in ticket price</option>\n'+
   
       '                           </select>\n'+
   
           
   
       '                     </div>\n'+
   
      
       '               </div>\n'+
   
   '              <div class="d-optional"> <label>Details (optional)</label>\n'+
   
       '                  <p><textarea name="ticket_details[]" value="" placeholder=" Ticket details"></textarea> </p></div>\n'+                         
   
       '                  <div class="row-out">\n'+
   
       '                     <div class="row-1">\n'+
   
       '                        <label>Ticket type</label>\n'+
   
       '                        <span class="radio-chk">\n'+
   
       '                            <input type="radio" class="tkt_type" data-count="'+count+'" name="radio_tkt_type_'+count+'" value="Single Tickets" checked="checked"> <span class="checkmark1"> </span> Single Tickets\n'+
   
       '                        </span>\n'+
   
       '                        <span class="radio-chk">\n'+
   
       '                            <input type="radio" class="tkt_type" data-count="'+count+'" name="radio_tkt_type_'+count+'" value="Bundled Tickets"> <span class="checkmark1"> </span>Bundled Tickets\n'+
   
       '                        </span>\n'+
   
       '                        <div class="tkt-type">Use Bundled tickets when you want to sell group tickets packages\n'+
       '                           <div class="tooltip2"><i class="fa fa-info"></i> \n'+
       '                                    <span class="tooltiptext2"> \n'+
       '                                          (i.e. table of 10, golf foursome, family package) \n'+
          '                                 </span> \n'+
         '                              </div> \n'+
       '                        </div>\n'+
   
       '                     </div>\n'+
   
       '                     <div class="row-2">\n'+
   
       '                        <label>Price type</label>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="price_radio" name="price_radio_'+count+'" value="Paid" checked="checked">  <span class="checkmark1"> </span> Paid</span>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="price_radio" name="price_radio_'+count+'" value="Free" >  <span class="checkmark1"> </span> Free</span>\n'+
   
       '                     </div>\n'+
   
       '                  </div>\n'+
   
       '                  <div class="row-out">\n'+
   
       '                     <div class="row ppt" id="div_price_per_tkt_'+count+'">\n'+
   
       '                        <label>Price Per Ticket ($CAD)</label>\n'+
   
       '                        <p><input required type="number" min="0" class="price_class" name="price_per_tkt[]" id="price_per_tkt_'+count+'" placeholder="100.00" value="0"> </p>\n'+
   
       '                     </div>\n'+
   
       '                     <div class="row qty-avi" id="div_no_of_tkt_available_'+count+'">\n'+
   
       '                        <label>Quantity Available*</label>\n'+
   
       '                        <p> <input required type="number" min="0" data-count="'+count+'" class="nota" name="no_of_tkt_available[]" id="nota_'+count+'" placeholder="100" required value="0"> </p>\n'+
   
       '                     </div>\n'+
       '                    <div class="row brk-down"> \n'+
                            
       '                     <span class="tkt-breakdown"><div class="tooltip2">Breakdown <i class="fa fa-info"></i> \n'+
        '                     <span class="tooltiptext2"><b>Ticket Breakdown</b> \n'+
         '                       <table>\n'+ 
          '                          <tr> \n'+
          '                              <th></th> \n'+
           '                             <th>Customer<br/> Pays</th> \n'+
           '                             <th>You <br/>  Receive</th> \n'+
          '                          </tr> \n'+ 
          '                          <tr> \n'+
          '                              <td class="bold">Ticket</td> \n'+
           '                             <td>$100.00</td> \n'+
           '                             <td>$100.00</td> \n'+
           '                         </tr> \n'+
            '                        <tr> \n'+
           '                            <td class="bold">Ticket tax </td> \n'+
           '                             <td>$0.00</td> \n'+
           '                             <td>$0.00</td> \n'+
            '                        </tr> \n'+
            '                        <tr> \n'+
            '                            <td class="bold">Fee</td> \n'+
             '                           <td>$0.00</td> \n'+
             '                           <td>-$6.88</td> \n'+
              '                      </tr> \n'+
               '                     <tr> \n'+
              '                          <td class="bold">Fee tax</td> \n'+
              '                          <td>$0.00</td> \n'+
              '                          <td>-$0.89</td> \n'+
               '                     </tr> \n'+
               '                     <tr> \n'+
              '                         <td class="bold">Total</td> \n'+
                '                        <td class="bold1" >$100.00</td> \n'+
                '                        <td class="bold1">$92.23</td> \n'+
                '                    </tr> \n'+
               '                 </table> \n'+
   
          '          </span> \n'+
       '       </div></span> Buyer Pays: $100; Fees: $6.88; You Receive: $92.23 \n'+
                            
       '                        </div>     \n'+
   
   
       '                  </div>\n'+
   
       '                  <div class="row-out div_bundled" style="display: none;" id="div_bundle_'+count+'">\n'+
   
       '                     <div class="row">\n'+
   
       '                        <label>Tickets Per Bundle</label>\n'+
   
       '                        <input type="number" min="0" class="tkb" name="ticket_per_bundle[]"data-count="'+count+'" id="tkb_'+count+'" value="0" placeholder="0" required> x\n'+
   
       '                     </div>\n'+
   
       '                     <div class="row">\n'+
   
       '                        <label>Bundles Available</label>\n'+
   
       '                        <input type="number" min="0" class="tba" name="bundles_available[]" value="0" data-count="'+count+'" id="tba_'+count+'" placeholder="100" required> =\n'+
   
       '                     </div>\n'+
   
       '                     <div class="row">\n'+
   
       '                        <label>Total Tickets</label>\n'+
   
       '                        <input type="text" min="0" class="tbtkt" id="tbtkt_'+count+'" name="total_tickets[]" value="0" placeholder="200" required>\n'+
   
       '                     </div>\n'+
   
                                       
   
       '                  </div>\n'+
   
       '                  <div class="row-out">\n'+
   
       '                     <div style="width:38%;" class="row">\n'+
   
       '                        <label>Ticket Start Time</label>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_start_time" name="radio_tkt_start_time_'+count+'" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_start_time" name="radio_tkt_start_time_'+count+'" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>\n'+
   
       '                       <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_'+count+'">\n'+
   
       '                           <label class="start-date" for="tkt_start_date_'+count+'">Start <input required type="text" id="tkt_start_date_'+count+'" class="start_datepicker tkt_start_date" data-counter="'+count+'" name="tkt_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important;  padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
   
       '                       </div>\n'+
   
       '                     </div>\n'+
   
       '                     <div style="width:38%;"  class="row">\n'+
   
       '                        <label>Ticket End Time</label>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_end_time" name="radio_tkt_end_time_'+count+'" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>\n'+
   
       '                        <span class="radio-chk"> <input type="radio" data-count="'+count+'" class="radio_tkt_end_time" name="radio_tkt_end_time_'+count+'" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>\n'+
   
       '                       <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_'+count+'">\n'+
   
       '                           <label class="start-date" for="tkt_end_date_'+count+'">End <input required type="text" id="tkt_end_date_'+count+'" class="start_datepicker tkt_end_date" data-counter="'+count+'" name="tkt_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
   
       '                       </div>\n'+
   
       '                     </div>\n '+
   
       '                     <div style="width:24%;" class="row tlpo">\n'+
   
       '                        <label>Ticket Limit per Order</label>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_limit" name="radio_tkt_limit_'+count+'" value="no" checked> <span class="checkmark1"> </span>No</span>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_limit" name="radio_tkt_limit_'+count+'" value="yes"> <span class="checkmark1"> </span>Yes</span>\n'+
       '                        <div class="row">\n'+
       '                           <p><input required type="number" min="0" name="tkt_order_limit[]" style="display: none; width:120px;" value="0" id="tkt_order_limit_'+count+'"></p>\n'+
       '                         </div>\n'+
       '                     </div>\n '+
   
       '                  </div>\n'+
   
       '                  <div class="row-out">\n'+
   
       '                     <div style="width: 38%;" class="row">\n'+
   
       '                        <label> Release Start Date & Time</label>\n'+
   
       '                        <span class="radio-chk"><input required type="radio" data-count="'+count+'" class="radio_release_time" name="radio_release_time_'+count+'" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>\n'+
   
       '                        <span class="radio-chk"> <input required type="radio" data-count="'+count+'" class="radio_release_time" name="radio_release_time_'+count+'" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>\n'+
       '                       <div style="width: 50%; display: none;" class="row" id="div_release_start_date_'+count+'">\n'+
   
       '                           <label class="start-date" for="release_start_date_'+count+'">Start <input required type="text" id="release_start_date_'+count+'" data-counter="'+count+'" class="start_datepicker release_start_date" name="release_start_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
   
       '                       </div>\n'+
       '                     </div>\n'+
   
       '                     <div style="width: 50%;" class="row">\n'+
   
       '                        <label>Expiration Start Date & Time </label>\n'+
   
       '                       <span class="radio-chk none"> <input type="radio" data-count="'+count+'" class="radio_expiration_time" name="radio_expiration_time_'+count+'" value="None" checked> <span class="checkmark1"> </span>None</span>\n'+
   
       '                       <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_expiration_time" name="radio_expiration_time_'+count+'" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>\n'+
       '                       <div style="width: 50%; display: none;" class="row" id="div_release_end_date_'+count+'">\n'+
   
       '                           <label class="start-date" for="release_end_date_'+count+'">End <input required type="text" id="release_end_date_'+count+'" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #f56d3a !important; width: 100% !important; padding: 0px; !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
   
       '                       </div>\n'+
   
       '                     </div>\n'+
   
       '                  </div>\n'+
   
   
       '                  <div class="row-out">\n'+
   
       '                     <div class="">\n'+
   
       '                        <label> Promo Code</label>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="promo_code" name="radio_promo_code_'+count+'" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>\n'+
   
       '                        <span style="margin-left: 24px; margin-right: 84px;" class="radio-chk"><input class="promo_code" data-count="'+count+'" type="radio" name="radio_promo_code_'+count+'" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>\n'+
   
       '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="promo_code" name="radio_promo_code_'+count+'" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>\n'+
   
       '                     </div>\n'+
   
       '                  </div>\n'+
   
       '                  <div class="row-out" id="div_promo_code_'+count+'" style="display: none;">\n'+
   
       '                     <div class="row">\n'+
   
       '                        <label>Code Name (min. 6 characters)</label>\n'+
   
       '                        <p><input required minlength="6" type="text" name="code_name[]" placeholder="SAVE10">\n'+
   
       '                     </div>\n'+
   
       '                     <div class="row">\n'+
   
       '                        <label>Code value</label>\n'+
   
       '                        <p><input required type="number" name="code_value[]" placeholder="10.00"> </p>\n'+
   
       '                     </div>\n'+
   
       '                  </div>\n'+
  
        '                  <div class="row-out">\n' +                  
   
       '                       <div class="date-tkt-typ">\n'+                       
   
       '                       <label> Select Date(s) for this Ticket Type</label>\n'+                            
   
       '   <?php  $i=1; foreach($_SESSION['event_data']['event_start_date'] as $key=>$val) { ?>'    +   
      '    <?php   $start_date = $_SESSION["event_data"]["event_start_date"][$key]; $end_date = $_SESSION["event_data"]["event_end_date"][$key];   if(date("Y-m-d", strtotime($start_date)) == date("Y-m-d", strtotime($end_date))) {  $selctdatae = $start_date." to ".date("h:i a", strtotime($end_date));   }else{   $selctdatae = $start_date." to ".$end_date;     }   ?>' + 
   
       '                       <span class="chkbox">\n'+                           
   
       '                       <input type="checkbox" value="<?php echo $selctdatae; ?>" <?php if($i==1) echo "checked" ?> name="ticket_type_dates['+count+'][]">\n'+
   
       '                       <span class="checkmark"></span>\n'+
   '<?php echo $selctdatae; ?>'   +  
       
            '</span>\n'+           
            '<?php $i++; } ?>'   +           
   
                               '</div>\n'+
   
                           '</div>\n'+
 
                      '</div>\n'+
   
      
   
       '            <p style="cursor:pointer;" class="del-tkt"  data-cnt="'+count+'"><span>-</span> Remove Ticket Type </p>\n'+
       '           <p style="cursor:pointer;" class="clone_tkt">Clone Ticket Type</p> \n'+
                    
        '            </div>\n' +
   
       '        </div>';
   
   
   
   $(this).before(html);
   
   var i, acc = document.getElementsByClassName("acc-head"+count);
   for (i = 0; i < acc.length; i++) acc[i].addEventListener("click", function() {
   //this.classList.toggle("active");
    this.parentElement.classList.toggle("active");
    var e = this.parentElement.nextElementSibling;
   "block" === e.style.display ? e.style.display = "none" : e.style.display = "block"
   });   
   
    $("#tkt_form").validate({
           rules: {
            "tkt_start_date[]": {
                required: !0,
                notset: !0
            },
            "tkt_end_date[]": {
                required: !0,
                notset: !0
            }
        }
    });
   
   var stdte = new Date($('#EVENTSTRATDATE').val());
   var enddte = new Date($('#EVENTENDDATE').val());
   console.log(stdte.dateFormat('Y/m/d'));
   console.log(enddte.dateFormat('Y/m/d'));
   $(".tkt_start_date").datetimepicker({
        // startDate: stdte.dateFormat('M d, Y'),
      minDate: stdte.dateFormat('Y/m/d'),
      maxDate: enddte.dateFormat('Y/m/d'),
      
      minTime: stdte.dateFormat('h:i a'),
      maxTime: enddte.dateFormat('h:i a'),
      step: 15,
        format: "M d, Y h:i a",
      formatTime: 'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
      validateOnBlur: false,
        onClose: function(e) {
         
            var t = $("#start").val();
            $("#tkt_start_date_" + t + "-error").hide(), $("#tkt_start_date_" + t).removeClass("error"),
                function(e) {
                    var e = e,
                        t = $("#tkt_start_date_" + e).val().replace("pm", "").replace("am", ""),
                        a = new Date(t),
                        r = a.getFullYear() + "/" + (a.getMonth() + 1) + "/" + a.getDate();
               
               var stdteenddt = new Date($("#tkt_start_date_" + e).val());

                    $("#tkt_end_date_" + e).datetimepicker({
                        minDate: "" + r,
                  maxDate: enddte.dateFormat('Y/m/d'),
                  minTime: stdteenddt.dateFormat('h:i a'),
                  maxTime: enddte.dateFormat('h:i a'),
                        step: 15,
                        format: "M d, Y h:i a",
                  formatTime: 'h:i a',
                        closeOnDateSelect: !1,
                        closeOnTimeSelect: !0,
                  validateOnBlur: false,
                        onClose: function(t) {
                            $("#tkt_end_date_" + e + "-error").hide(), $("#tkt_end_date_" + e).removeClass("error")
                        }
                    })
                }(t)
        }
    });
   
   $(".tkt_end_date").datetimepicker({
        step: 15,
        format: "M d, Y h:i a",
      formatTime: 'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
      maxDate: enddte.dateFormat('Y/m/d'),
      maxTime: enddte.dateFormat('h:i a'),
      validateOnBlur: false,
        /* onClose: function(e) {
            var t = $("#start").val();
            $("#tkt_end_date_" + t + "-error").hide(), $("#tkt_end_date_" + t).removeClass("error"),
                function(e) {
                    var e = e,
                        t = $("#tkt_end_date_" + e).val().replace("pm", "").replace("am", ""),
                        a = new Date(t),
                        r = a.getFullYear() + "/" + (a.getMonth() + 1) + "/" + a.getDate();
                    $("#tkt_start_date_" + e).datetimepicker({
                        maxDate: "" + r,
                        step: 15,
                        format: "M d, Y h:i a",
                        closeOnDateSelect: !1,
                        closeOnTimeSelect: !0,
                        onClose: function(t) {
                            $("#tkt_start_date_" + e + "-error").hide(), $("#tkt_start_date_" + e).removeClass("error")
                        }
                    })
                }(t)
        } */
    });
   
   $(".release_start_date").datetimepicker({
        step: 15,
        format: "M d, Y h:i a",
      formatTime: 'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
      validateOnBlur: false,
      minTime: 0,
      minDate: 0,
      maxDate: enddte.dateFormat('Y/m/d'),
        onClose: function(e) {
            var t = $("#start").val();
            $("#release_start_date_" + t + "-error").hide(), $("#release_start_date_" + t).removeClass("error"), setReleaseEndMinDate(t)
        }
    });
   
   $(".release_end_date").datetimepicker({
        step: 15,
        format: "M d, Y h:i a",
      formatTime: 'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
      validateOnBlur: false,
      maxDate: enddte.dateFormat('Y/m/d'),
    });

   
});
jQuery("#back_page").on('click',function(){
   jQuery('#modal_loader_text').text('Back to previous page...');
   jQuery('#loadingModal').show();
});
    $("#div_ticket").sortable({
        update: function (event, ui) {
            var order = $(this).sortable('serialize');
        }
    }).disableSelection();
  
</script>
<?php
// if(isset($_SESSION['ticket_data'])){ echo "<pre>"; print_r($_SESSION['ticket_data']); } ?>
<?php// if(isset($tickets)){ echo "<pre>"; print_r($tickets); }
//echo date_default_timezone_get()."<br>";
//date_default_timezone_set("America/Chicago");
//echo date_default_timezone_get();
?>