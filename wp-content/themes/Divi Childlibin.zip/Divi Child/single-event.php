<?php
/*
   Template Name: Single Event
   */

/* if(isset($_SESSION['userdata'])){
	$userdata = $_SESSION['userdata'];
}else{
	wp_redirect( site_url().'?page_id=187' );
	exit;
} */

global $wpdb;
$token   =  $_SESSION['Api_token'];
$url = $_SERVER['REQUEST_URI'];      
$event = explode('/', $url);
$event_id = $event[2];

if (isset($event_id) && $event_id != '') {

   //$event_id = $_GET['event_id'];

   $ch   = curl_init(API_URL . '/events/' . $event_id);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($ch, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'Authorization: ' . $token
   ));
   $result = curl_exec($ch);
   curl_close($ch);
   $apirespons = json_decode($result);

   if ($apirespons->success) {

      $event_detail = $apirespons->event;
      $metadata = unserialize($event_detail->metadata);

      if (isset($metadata['file_id'])) {

         //echo API_URL.'files/'.$metadata['file_id'];die;

         $ch   = curl_init(API_URL . 'files/' . $metadata['file_id']);
         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
         curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/pdf',
            'Authorization: ' . $token
         ));
         $result1 = curl_exec($ch);
         curl_close($ch);
         $fileresponse = json_decode($result1);

         if ($fileresponse->success) {

            $file = $fileresponse->file;
         }
      }
   }
}
 //  echo "<pre>"; print_r($metadata); die();
get_header(); ?>
<link href='<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/simpleLightbox.css' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/simpleLightbox.js"></script>
<div id="main-content">
<link rel="stylesheet" href="<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/fancy-file-uploader/fancy_fileupload.css" type="text/css" media="all" />
<script type="text/javascript" src="<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/fancy-file-uploader/jquery.ui.widget.js"></script>
<script type="text/javascript" src="<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/fancy-file-uploader/jquery.fileupload.js"></script>
<script type="text/javascript" src="<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/fancy-file-uploader/jquery.iframe-transport.js"></script>
<script type="text/javascript" src="<?php echo site_url(); ?>/wp-content/themes/Divi Child/js/fancy-file-uploader/jquery.fancy-fileupload.js"></script>
<style>
.ff_fileupload_wrap .ff_fileupload_dropzone {
    padding: 0 26px 40px 0px !important;
    height: 125px;
    background-size: 80px;
    font-size: 20px;
    text-align: right;
    background-position: left 25px top 10px;
}
.ff_fileupload_wrap table.ff_fileupload_uploads td.ff_fileupload_summary .ff_fileupload_filename {
    max-width: 340px !important;
    font-weight: bold;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.map-inter {
    float: left;
    width: 60%;
    margin-left: 0%;
}
.topbtns{
    width: 40px;
    float: right;
    padding: 10px 10px 0px 10px;
    cursor: pointer;
}
.ticket-range {
    top: 110px !important;     
    display: none;
}
.closeh4 {
    float: right;
    padding-top: 7px;
}
.upper a{
    color:black;
    float: right;
    margin-left: 20px;
}
.up-logo img{
    margin-top:10px;
    max-width: 80%;
}
.image-gallery a img {
    width: 144px;
    margin: 10px 2px 0 2px !important;
}
button#button_upload_image {
    padding: 6px 12px;
    margin-top: 10px;
    background: #ffffff;
    border: 2px solid #3b93fc;
    color: #55a1fc;
    border-radius: 4px;
    font-size: 16px;
    margin-bottom: 12px;
    position: absolute;
    top: 322px;
    left: 156px;
}
.shareit{
    display:none;
    float: right;
    position: relative;
    top: -17px;
}
.gallery_title{
        margin-top: 10px;
}
.single-evnt-detail p b {
    width: 100px !important;
    float: left;
}
.gallery_t{
    font-size: 17px;
    font-weight: bold;
    color: #333333;
}
.detali_t{
        float: right;
}

</style>
<?php 
 if(count($event_detail->ticketTypes)>0){
?>
<style>
.topbtns {
    width: 40px;
    float: right;
    padding: 10px 10px 0px 10px;
    cursor: pointer;
    position: relative;
    right: 144px;
}
</style>
<?php } ?>
  <div id="main-content"> 
   <div class="outer-wrapper ">
      <div class="container container-home">
          <?php// echo site_url().parse_url($_SERVER['HTTP_REFERER'],PHP_URL_PATH); ?>
          <div class="upper">
                
          </div>
          
         <div class="event-detail">
           <div class="upload-image">
              <?php if (isset($event_detail) && count($event_detail->files) > 0 && $event_detail->files[0]->type == 'image') { ?>
                  <img src="https://storage.googleapis.com/<?php echo $event_detail->files[0]->bucket ?>/<?php echo $event_detail->files[0]->filename; ?>" style="max-height: 250px;">
              <?php }else{  ?>
                  <img src="<?php echo site_url(); ?>/wp-content/uploads/2019/08/r1.jpg">
               <?php } ?>
			   <div class="image-gallery">					
				<div>
					<?php if (!empty($token)) : ?>
					<!--input type="file" name="gallery1" onChange="newuploadmethod(this);"--> 
					<form action="<?php echo site_url(); ?>/wp-content/themes/Divi Child/ajax/addupload.php?event_id=<?php echo $event_id; ?>" method="post" id="frm_image_upload" enctype="multipart/form-data">
					   <div class="">
						<!--
						  <input type="file" name="gallery_images[]" id="event_gallery_images" accept=".jpg, .png, image/jpeg, image/png" style="display: none" multiple>
						  <button type="button" onclick="$('.ff_fileupload_dropzone').click()" id="button_upload_image">Browse Photos</button>
						  -->
						  <div class="ff_fileupload_wrap"><div class="ff_fileupload_dropzone_wrap"><button class="ff_fileupload_dropzone" type="button" aria-label="Browse, drag-and-drop, or paste files to upload">Drag &amp; drop photos to gallery....</button><div class="ff_fileupload_dropzone_tools"></div></div><table class="ff_fileupload_uploads"></table></div>
						  <input type="file" id="newmethodfile" onChange="newuploadmethod(this);" accept=".jpg, .png, image/jpeg, image/png" style="border: none; position: absolute;top: 258px;left: 0;z-index: 2;opacity: 0;cursor: pointer;height: 127px;width: 100%;">
						  <button type="button" onclick="$('.ff_fileupload_dropzone').click();$('#newmethodfile').click();" id="button_upload_image">Browse Photos</button>
						 </div>
					</form>
					 <?php endif; ?>
					 <?php echo @$uploadmessage; ?>
				</div>
				<div class="gallery_title"><span class="gallery_t">Gallery</span><span class="detali_t">Click for details</span></div>
				 <?php if(isset($event_detail) && count($event_detail->photos) > 0) { ?>
                     
                     <?php foreach ($event_detail->photos as $row) { ?>
                           <a title="<?php echo $row->caption; ?>" href="https://storage.googleapis.com/<?php echo $row->file->bucket ?>/<?php echo $row->file->filename; ?>">
                              <img src="https://storage.googleapis.com/<?php echo $row->file->bucket ?>/<?php echo $row->file->filename; ?>">
                           </a>
                     <?php }
                     }else{
                     echo "Currently no photos at this time."; 
                    }?>                  
			  </div>
            </div>
            
            <form class="event-details">
                 <?php if(count($event_detail->ticketTypes)>0){ /* echo "<pre>"; print_r($event_detail->ticketTypes); die; */ ?>
					<?php if($event_detail->ticketTypes[0]->name ==''){ ?>
						<h2 class="f-tkt">FREE</h2>
					 <?php }else{ 
					 
						if(count($event_detail->ticketTypes)==1){
							if((strtotime($event_detail->ticketTypes[0]->start) >= strtotime(date('Y-m-d'))) && (strtotime($event_detail->ticketTypes[0]->end) <= strtotime(date('Y-m-d')))){
					?>
							<a href="<?php echo site_url()?>/get-tickets/<?php echo $event_id;?>"><button class="buy-ticket" type="button" name="btnSubmit">BUY TICKETS</button></a>
					<?php
							}else if(strtotime(date('Y-m-d')) < strtotime($event_detail->ticketTypes[0]->start)){
					?>
							<a href="#"><button class="buy-ticket-available" type="button" name="btnSubmit">AVAILABLE SOON</button></a>
							<p>TICKETS GO ON SALE 
							<br/><?php echo date('M d, Y',strtotime($event_detail->ticketTypes[0]->start)); ?>  
							<br>@<?php echo date('h:i',strtotime($event_detail->ticketTypes[0]->start)); ?>
							</p>
					<?php			
							}
						} 
					?>  
						<a href="<?php echo site_url()?>/get-tickets/<?php echo $event_id;?>"><button class="buy-ticket" type="button" name="btnSubmit">BUY TICKETS</button></a>
						<div class="ticket-range">
						<?php foreach ($event_detail->ticketTypes as $ticket) { ?>
								<p><?php echo $ticket->name ?> <?php echo '$'.$ticket->price ?></p>
						<?php } ?>
						</div>
					 <?php } ?>
				<?php } ?>
               <h3><?php echo isset($event_detail) ? $event_detail->name : ''; ?><img class="topbtns  a2a_dd" href="https://www.addtoany.com/share" src="<?php echo site_url(); ?>/wp-content/themes/Divi Child/img/sharepng.png" alt="uplaod images">
                <script async src="https://static.addtoany.com/menu/page.js"></script>
                <script>a2a_config.onclick = 1;</script></h3>
               <?php foreach ($event_detail->event_dates as $edate) {
                  if ($edate->start_date == $edate->end_date) { ?>
                     <b class="p-date"><?php echo date('M d, Y h:i a', strtotime($edate->start_date)); ?> to <?php echo date('h:i a', strtotime($edate->end_date)); ?></b>
                  <?php } else { ?>
                     <b class="p-date"><?php echo date('M d, Y h:i a', strtotime($edate->start_date)); ?> to <?php echo date('M d, Y h:i a', strtotime($edate->end_date)); ?></b>
                  <?php } 
				  } 
				  
               if (isset($event_detail)) {

                  $country = $wpdb->get_row("Select * from wp_countries where  id = $event_detail->country_id");
                  $state = $wpdb->get_row("select * from wp_states where id = $event_detail->province_id");
               }
               ?>
               <p>
			   <?php echo isset($event_detail) ? !empty($event_detail->location) ? $event_detail->location.'<br>': ' ' : ' '; ?>
                     <?php echo isset($event_detail) ? !empty($event_detail->address2) ? $event_detail->address2.'<br>': ' ' : ' '; ?>
                     <?php echo isset($event_detail) ? $event_detail->city : '';?>, <?php echo isset($event_detail) ? $state->name : '';?>, <?php echo isset($event_detail) ? $country->name : '';?><br/>
                     <?php echo isset($event_detail) ? $event_detail->postalcode : '';?>
               </p>
               <div class="p-description">
                  <h3>Description</h3>
                  <p><?php echo isset($event_detail) ? $event_detail->description : ''; ?></p>
               </div>
               <div class="row">
                  <?php foreach ($event_detail->categorys as $category) { ?>
                     <div class="p-catg" style="margin-right:5px;"><?php echo $category->name; ?></div>
                  <?php } ?></div>

			   <div class="single-evnt-detail contant">
                     <h3>Contact Details</h3>
                    <?php //echo "<pre>"; print_r($metadata);
                    if(isset($event_detail)){
                     echo isset($metadata['org']) && $metadata['org'] != '' ? "<p><b>Organization:</b>".$metadata['org']."</p>" : ""; 
                     echo $event_detail->contact_name != '' && isset($metadata) && $metadata['exclude_name'] == 'off' ? "<p><b>Name:</b>".$event_detail->contact_name."</p>" : ""; 
                     echo $event_detail->contact_phone != '' && isset($metadata) && $metadata['exclude_phone'] == 'off' ? "<p><b>Phone:</b>".$event_detail->contact_phone."</p>" : ""; 
                     echo isset($metadata) && $metadata['extension'] != '' && $metadata['exclude_phone'] == 'off' ? "<p><b>Extension:</b>".$metadata['extension']."</p>" : ""; 
                     echo $event_detail->contact_url != '' ? "<p><b>Website:</b>".$event_detail->contact_url."</p>" : ""; 
                     echo $event_detail->contact_email != '' && isset($metadata) && $metadata['exclude_email'] == 'off' ? "<p><b>Email:</b>".$event_detail->contact_email."</p>" : ""; 
                    }
                     ?>
                  </div>

               <div class="attachemnts">
                 <?php if(isset($metadata['file_id']) || isset($metadata['logo_id'])){ ?>
                  <div class="logo-details">
                   <!-- <h3>Logo</h3> -->
                     <p class="up-logo">
                        <?php 
                           foreach ($event_detail->files as $row) {
                              if ($row->type == 'logo') { ?>
                                 <img src="https://storage.googleapis.com/<?php echo $row->bucket ?>/<?php echo $row->filename; ?>">
                        <?php 
                              }
                           }
                        ?>
                     </p>
                     <?php if(isset($file)) { ?>
                        <p class="up-attach">
                           <h3>Attachment</h3>
                          <p>Important imformation about this event:</p>
                           <a class="btn-downlaod" href="<?php echo isset($file) ? 'https://storage.cloud.google.com/' . $file->bucket . '/' . $file->filename : '#' ?>" target="_blank" style="background: #529cfb; color: #fff; padding: 1px 13px;">Download <i class="fa fa-download"></i> </a>
                           <p><span>Don’t have Adobe Reader –</span><a href="https://get.adobe.com/reader/" target="_blank">click here</a> to download.</p>
                           <!-- </button> -->
                        </p>
                     <?php } ?>
                  </div>
				  <?php } ?>
               
               <div class="<?php echo isset($file) && (isset($metadata['file_id']) || isset($metadata['logo_id'])) ? 'map-details' : 'map-inter' ; ?>">
                  <h3>Map Details</h3>
                  <iframe class="mapIframe" src="https://webdev.snapd.com/map.php?lat=<?php echo $event_detail->lat ?>&lng=<?php echo $event_detail->long ?>" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
               </div>
				</div>
            </form>
         </div>
      </div>
      <!-- #container -->
   </div>
   <!-- #outer-wrapper -->
</div>
<!-- #main content --> 
<div class="modal" id="loadingModal" role="dialog">
    <div class="modal-dialog modal-lg" style="max-width: 220px !important;">
        <div class="modal-content">
            <div class="modal-body">
                <div class="email-confomation">                    
                    <p class="mail-img" style="padding: 0px;"><img src="<?php echo site_url(); ?>/wp-content/uploads/loading.gif"></p>
					<p id="modal_loader_text">Loading...</p>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- #main content -->
<?php get_footer(); ?>

<script type='text/javascript'>
   $(document).ready(function() {
      var gallery = $('.image-gallery a').simpleLightbox();
	
		/* $('#event_gallery_images').FancyFileUpload({
			retries : 0,
			params : {
				action : 'fileuploader'
			},
			fileupload : {
				maxChunkSize : 1000000000
			},
			added : function(e, data) {
				
			},
			uploadcompleted : function(e, data) {
				data.ff_info.inforow.remove();
				if($('.ff_fileupload_uploads').find('tr').hasClass('ff_fileupload_queued')){
					
				}else{
					window.location.href=window.location.href;
				}
			},
		}); 
		jQuery('button.ff_fileupload_dropzone').html('Drag & drop photos to gallery....');
		*/
		<!-- -->
		<!-- -->
	
  });
  function newuploadmethod(input){
		
		/* alert(input.files[0]); return; */
		jQuery('#modal_loader_text').text('In progress...');
		jQuery('#loadingModal').show();
	
		var form = new FormData();
		form.append("caption", "Please enter caption.");
		form.append("type", "logo");
		form.append("eventId", "<?php echo $event_id; ?>");
		form.append("file", input.files[0], "file");

		var settings = {
		  "url": "https://35.203.116.207/uploads/form",
		  "method": "POST",
		  "timeout": 0,
		  "headers": {
			"Authorization": "<?php echo $_SESSION['Api_token']; ?>",
			"Accept": "application/vnd.pagerduty+json"
		  },
		  "datatype": 'jsonp',
		  "processData": false,
		  "mimeType": "multipart/form-data",
		  "contentType": false,
		  "data": form
		};

		$.ajax(settings).done(function (response) {
		  /* console.log(response); */
		  window.location.href=window.location.href;
		});
  }
</script>
