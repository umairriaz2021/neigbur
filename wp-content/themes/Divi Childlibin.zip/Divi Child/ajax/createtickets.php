<?php 
session_start();
require('../../../../wp-config.php');

$token   =  $_SESSION['Api_token'];

echo "<pre>"; print_r($_POST['tktholder']); 

if(isset($_POST['promocode']) && $_POST['promocode']!=''){
	/* promocode handle code goes here */
}

if(isset($_POST['charity']) && $_POST['charity']==1){
	/* charity handle code goes here */
}

/*
if(isset($_POST['remembercard']) && $_POST['remembercard']==1){
	
	$exp = explode('/',$_POST['cardExpiry']);
	$pdata = array(
				'card'=>array('number'=> $_POST['cardNumber'], 'expiry_month'=> $exp[0], 'expiry_year'=> $exp[1], 'cvd'=> $_POST['cardCVC']),
				'billing'=>array('email_address'=>$_POST['cardEmail'])
				);
	echo "<pre>"; print_r($pdata); 
	echo $payload = json_encode($pdata);	     

	$ch   = curl_init(API_URL . '/users/addCard');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$payload);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	'Content-Type: application/json',
	'Authorization: ' . $token
	));
	$result = curl_exec($ch);
	curl_close($ch);

	$response=json_decode($result);

	echo "<pre>"; print_r($response); 
} */

/* creating ticket order order start */
if(isset($_POST['tickets']) && count($_POST['tickets'])>0){
	foreach($_POST['tickets'] as $tkt){
		if($tkt['tqty']>0){
			/*User id need to change after testing*/
			$fields = array(
					"base_cost" => number_format(($tkt['tprice']*$tkt['tqty']),2),
					"fees"      => number_format(($tkt['tfee']*$tkt['tqty']),2),
					"subtotal"  => number_format(($tkt['tprice']*$tkt['tqty']),2),
					"taxes"     => number_format(($tkt['ttax']*$tkt['tqty']),2),
					"total" 	=> number_format((($tkt['tprice']+$tkt['ttax']+$tkt['tfee'])*$tkt['tqty']),2),
					"quantity" 	=> $tkt['tqty'],
					"ticket_type_id" 	=> $tkt['id'],
					"drupal_user_id" 	=> 39    
					);          

			echo "<pre>"; print_r($fields); 
			echo $payload = json_encode($fields);	     

			$ch   = curl_init(API_URL . '/orders/');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$payload);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json',
			'Authorization: ' . $token
			));
			$result = curl_exec($ch);
			curl_close($ch);

			$response=json_decode($result);

			echo "<pre>"; print_r($response); 

			/* if ($response->success) {
				$result = array("success" => true);
				echo json_encode($result, JSON_UNESCAPED_SLASHES);
				exit();
			} else { 
				$result = array("success" => false,"error" =>"Please try later!","errorcode" => "invalid_file_ext");
				echo json_encode($result, JSON_UNESCAPED_SLASHES);
				exit();
			} */

		}
	}
}
/* creating ticket order order ends */

/* creating ticket order start */
if(isset($_POST['tktholder']) && count($_POST['tktholder'])>0){
	foreach($_POST['tktholder'] as $tkid=>$tholder){		
		foreach($tholder as $cust){		
				$firstname=($cust['firstname']!='')?$cust['firstname']:$_SESSION['userdata']->first;
				$lastname=($cust['lastname']!='')?$cust['lastname']:$_SESSION['userdata']->last;
				$customeremail=($cust['customeremail']!='')?$cust['customeremail']:$_SESSION['userdata']->email;
				$fields = array(
							"firstname"=> $firstname,
							"lastname"=> $lastname,
							"email"=> $customeremail,
							"event_id"=> $_POST['event_id'],
							"ticket_type_id"=> $tkid
						);          

				echo "<pre>"; print_r($fields); 
				echo $payload = json_encode($fields);	     

				$ch   = curl_init(API_URL . '/tickets/');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch,CURLOPT_POSTFIELDS,$payload);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/json',
				'Authorization: ' . $token
				));
				$result = curl_exec($ch);
				curl_close($ch);

				$response=json_decode($result);

				echo "<pre>"; print_r($response); 

				/* if ($response->success) {
					$result = array("success" => true);
					echo json_encode($result, JSON_UNESCAPED_SLASHES);
					exit();
				} else { 
					$result = array("success" => false,"error" =>"Please try later!","errorcode" => "invalid_file_ext");
					echo json_encode($result, JSON_UNESCAPED_SLASHES);
					exit();
				} */

			
		}
	}
}
/* creating ticket order ends */
/* 
Array
(
    [Api_token] => Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjozNTQsImlhdCI6MTU5MzYxMDcxM30.zJg7rYuQWSDIwLmbNFpZCwJjNPeZ3MUWELJR0h6tcM4
    [userdata] => stdClass Object
        (
            [first] => Aman
            [last] => Jsl
            [id] => 354
            [email] => amanjeet.hatch@gmail.com
            [facebook_id] => 
            [google_id] => 
            [bambora_profile] => 
            [address] => 
            [city] => 
            [postalcode] => 
            [user_domain] => 
            [reset_password_token] => 
            [reset_password_expires] => 
            [number] => 8728841113
            [age_range_id] => 2
            [organization_id] => 
            [email_confirmed] => 1
            [username] => Aman Jsl
            [password] => $2b$10$EuBqRGkV4e53G6PzGsIAbumfkZORSHg/L5IBr4VN3MO4JJEQL9kB.
            [franchise_id] => 
            [country_id] => 2
            [province_id] => 10
        )

) */

?>