<?php 
/*
Template Name: Thank You 

*/
get_header(); ?>

    <div id="main-content">


       <div class="outer-wrapper">
           <div class="container container-home">
      <?php
           while ( have_posts() ) : the_post(); ?> 
           <div class="entry-content-page">
            <?php the_content(); ?>
           </div>

    <?php
    endwhile;
    wp_reset_query(); 
    ?>
                  
      <div class="download-link">
        <p class="return-home2"><a href="<?php echo site_url(); ?>/my-tickets/">View My Tickets</a></p>
      </div>
	  </div>
      </div>   <!-- # outer-wrapper-->
    </div> <!-- #main content --> 

    <?php get_footer(); ?>