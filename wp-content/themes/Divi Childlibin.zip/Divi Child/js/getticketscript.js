$(function () {
	$('#cardNumber').mask('9999 9999 9999 9999');
	$('#cardExpiry').mask('99/99');
	$('#cardCVC').mask('999');
	
	$("#donation_receipt").click(function () {
		if ($(this).is(":checked")){ $("#charitable-yes").show(); }else{ $("#charitable-yes").hide(); }
	});
});

jQuery(document).on('click', '#buytickets', function () {
	var site_url = jQuery('#Site_Url').val();
	var datastring = $("form").serialize();
	jQuery('#loadingModal').show();
	jQuery.ajax({
			/* url: site_url + '/wp-content/themes/Divi Child/ajax/createtickets.php', */
			url: site_url + '/bambora/src/Beanstream/pay.php',
			type: "post",
			data : datastring,
			dataType : 'json',
			success: function (result){
				
				if(result.success){
					jQuery.ajax({
							url: site_url + '/wp-content/themes/Divi Child/ajax/createtickets.php',
							type: "post",
							data : datastring,
							success: function (result){
								jQuery('#loadingModal').hide();
								window.location.href= site_url+"/thank-you/";
							}
					});
				}else{
					jQuery('#loadingModal').hide();
					jQuery('#PayMentError').html('<p>'+result.message +'</p>');
					
				}
			}
	});
});

function holdTicket(){
	var site_url = jQuery('#Site_Url').val();
	var datastring = $("form").serialize();
	jQuery('#loadingModal').show();
	jQuery.ajax({
			url: site_url + '/wp-content/themes/Divi Child/ajax/holdtickets.php',
			type: "post",
			data : datastring,
			success: function (result){
				jQuery('#loadingModal').hide();
				ticketpaymentNext(1,2);
			}
	});
}
function startTimer(dd){
	var timer2 = "4:59";
	var interval = setInterval(function() {
	  var timer = timer2.split(':');
	  var minutes = parseInt(timer[0], 10);
	  var seconds = parseInt(timer[1], 10);
	  --seconds;
	  minutes = (seconds < 0) ? --minutes : minutes;
	  if (minutes < 0){
			alert('Your session has timed out and your tickets have been returned. Please try again.');	
			interval='';		  
			window.location.href=window.location.href;
	  }
	  seconds = (seconds < 0) ? 59 : seconds;
	  seconds = (seconds < 10) ? '0' + seconds : seconds;
	  //minutes = (minutes < 10) ?  minutes : minutes;
	  console.log(minutes + ':' + seconds);
	  $('.countdown'+dd).html(minutes + ':' + seconds);
	  timer2 = minutes + ':' + seconds;
	}, 1000);
}

function ticketpaymentNext(id1,id2){
	startTimer(id1);
	jQuery('#step'+id1).hide();
	jQuery('#step'+id2).show();
}
function ticketpaymentBack(id1,id2){
	jQuery('#step'+id1).show();
	jQuery('#step'+id2).hide();
}

jQuery(document).on('change, keyup', '.tqty', function () {

	var qty = jQuery(this).val();
	var price = jQuery(this).parent().parent().find('.tprice').val();
	var tax = jQuery(this).parent().parent().find('.ttax').val();
	var fee = jQuery(this).parent().parent().find('.tfee').val();
	console.log(qty);
	console.log(price);
	console.log(tax);
	console.log(fee);
	var ttot = (parseFloat(price) + parseFloat((tax!=undefined)?tax:0) + parseFloat((fee!=undefined)?fee:0)) * parseFloat(qty);
	console.log(ttot);
	jQuery(this).parent().parent().find('.ttotal').val(parseFloat(ttot).toFixed(2));
	jQuery(this).parent().parent().find('.ttoltxt').text(parseFloat(ttot).toFixed(2));
	
	getfulltot();
});

function getfulltot(){
	var tottax=0;
	var totfee=0;
	var tottkt=0;
	jQuery('.tqty').each(function( index ) {
		var qty = jQuery(this).val();
		var tax = jQuery(this).parent().parent().find('.ttax').val();
		var price = jQuery(this).parent().parent().find('.tprice').val();
		var fee = jQuery(this).parent().parent().find('.tfee').val();
		tottkt +=  (parseFloat(price).toFixed(2)) * parseFloat(qty).toFixed(2);
		tottax +=  (parseFloat((tax!=undefined)?tax:0).toFixed(2)) * parseFloat(qty).toFixed(2);
		totfee +=  (parseFloat((fee!=undefined)?fee:0).toFixed(2)) * parseFloat(qty).toFixed(2);
	});
	jQuery('.tkttotal').text('$'+parseFloat(tottkt).toFixed(2));
	jQuery('.tktTax').text('$'+parseFloat(tottax).toFixed(2));
	jQuery('.tktFee').text('$'+parseFloat(totfee).toFixed(2));
	var tt=parseFloat(tottkt) + parseFloat(tottax) + parseFloat(totfee);
	jQuery('#TotalAmount').val(parseFloat(tt).toFixed(2));
	jQuery('.Total').text('$'+parseFloat(tt).toFixed(2));
	getticketholders();
}

function getticketholders(){
	var tholder='';
	jQuery('#tickeTHoldersDiv').empty();
	
	jQuery('.tqty').each(function( index ) {
		
		var qty = jQuery(this).val();
		if(qty>0){
			var tname = jQuery(this).parent().parent().find('.tname').val();
			var tid = jQuery(this).parent().parent().find('.tid').val();
			tholder +='<div class="ticket_type_div">Ticket Type: <span>'+tname+'</span></div>'+
						   '<table style="width:100%" class="table_ordering_ticket_list">'+
							 '<tr><th></th><th>First Name</th><th>Last Name</th><th>Email</th></tr>';
			for(var i=1; i<=qty; i++){
				tholder +='<tr>'+
							 '<td id="order_tab">'+i+'</td>'+
							 '<td><input type="text" name="tktholder['+tid+']['+i+'][firstname]" placeholder="FIRST" class="frm_ordering_page"></td>'+
							 '<td><input type="text" name="tktholder['+tid+']['+i+'][lastname]" placeholder="LAST" class="frm_ordering_page"></td>'+
							 '<td><input type="text" name="tktholder['+tid+']['+i+'][customeremail]" placeholder="EMAIL" class="frm_ordering_page"></td>'+
						  '</tr>';
			}
			tholder +='</table>';
		}
	});
	jQuery('#tickeTHoldersDiv').html(tholder);
}