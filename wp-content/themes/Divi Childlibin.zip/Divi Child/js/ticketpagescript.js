  $.validator.addMethod('validUrl', function(value, element) {
    var url = $.validator.methods.url.bind(this);
    return url(value, element) || url('http://' + value, element);
  }, 'Please enter a valid URL');

  $("#tkt_form").validate({
    rules: {
      "turl": {
        validUrl: true // <-- change this
      }
    }
  });
jQuery.validator.addMethod("notset", function(e, t) {
    return "NOT SET" != e
}, "Please select date");

$(function() {
    $("#tkt_form").validate({
           rules: {
            "tkt_start_date[]": {
                required: !0,
                notset: !0
            },
            "tkt_end_date[]": {
                required: !0,
                notset: !0
            }
        }
    });
	var stdte = new Date($('#EVENTSTRATDATE').val());
	var enddte = new Date($('#EVENTENDDATE').val());
	console.log(stdte.dateFormat('Y/m/d'));
	console.log(enddte.dateFormat('Y/m/d'));
	$(".tkt_start_date").datetimepicker({
        // startDate: stdte.dateFormat('M d, Y'),
		minDate: stdte.dateFormat('Y/m/d'),
		maxDate: enddte.dateFormat('Y/m/d'),
		
		minTime: stdte.dateFormat('h:i a'),
		maxTime: enddte.dateFormat('h:i a'),
		step: 15,
        format: "M d, Y h:i a",
		formatTime:	'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
		validateOnBlur: false,
        onClose: function(e) {
			
            var t = $("#start").val();
            $("#tkt_start_date_" + t + "-error").hide(), $("#tkt_start_date_" + t).removeClass("error"),
                function(e) {
                    var e = e,
                        t = $("#tkt_start_date_" + e).val().replace("pm", "").replace("am", ""),
                        a = new Date(t),
                        r = a.getFullYear() + "/" + (a.getMonth() + 1) + "/" + a.getDate();
					
					var stdteenddt = new Date($("#tkt_start_date_" + e).val());

                    $("#tkt_end_date_" + e).datetimepicker({
                        minDate: "" + r,
						maxDate: enddte.dateFormat('Y/m/d'),
						minTime: stdteenddt.dateFormat('h:i a'),
						maxTime: enddte.dateFormat('h:i a'),
                        step: 15,
                        format: "M d, Y h:i a",
						formatTime:	'h:i a',
                        closeOnDateSelect: !1,
                        closeOnTimeSelect: !0,
						validateOnBlur: false,
                        onClose: function(t) {
                            $("#tkt_end_date_" + e + "-error").hide(), $("#tkt_end_date_" + e).removeClass("error")
                        }
                    })
                }(t)
        }
    });
	
	$(".tkt_end_date").datetimepicker({
        step: 15,
        format: "M d, Y h:i a",
		formatTime:	'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
		maxDate: enddte.dateFormat('Y/m/d'),
		maxTime: enddte.dateFormat('h:i a'),
		validateOnBlur: false,
        /* onClose: function(e) {
            var t = $("#start").val();
            $("#tkt_end_date_" + t + "-error").hide(), $("#tkt_end_date_" + t).removeClass("error"),
                function(e) {
                    var e = e,
                        t = $("#tkt_end_date_" + e).val().replace("pm", "").replace("am", ""),
                        a = new Date(t),
                        r = a.getFullYear() + "/" + (a.getMonth() + 1) + "/" + a.getDate();
                    $("#tkt_start_date_" + e).datetimepicker({
                        maxDate: "" + r,
                        step: 15,
                        format: "M d, Y h:i a",
                        closeOnDateSelect: !1,
                        closeOnTimeSelect: !0,
                        onClose: function(t) {
                            $("#tkt_start_date_" + e + "-error").hide(), $("#tkt_start_date_" + e).removeClass("error")
                        }
                    })
                }(t)
        } */
    });
	
	$(".release_start_date").datetimepicker({
        step: 15,
        format: "M d, Y h:i a",
		formatTime:	'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
		validateOnBlur: false,
		minTime: 0,
		minDate: 0,
		maxDate: enddte.dateFormat('Y/m/d'),
        onClose: function(e) {
            var t = $("#start").val();
            $("#release_start_date_" + t + "-error").hide(), $("#release_start_date_" + t).removeClass("error"), setReleaseEndMinDate(t)
        }
    });
	
	$(".release_end_date").datetimepicker({
        step: 15,
        format: "M d, Y h:i a",
		formatTime:	'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
		validateOnBlur: false,
		maxDate: enddte.dateFormat('Y/m/d'),
    });
});

function setReleaseEndMinDate(e) {
	var enddte = new Date($('#EVENTENDDATE').val());
    e = e;
    var a = $("#release_start_date_" + e).val().replace("pm", "").replace("am", ""),
        t = new Date(a),
        r = t.getFullYear() + "/" + (t.getMonth() + 1) + "/" + t.getDate();
		var stdteenddt = new Date($("#release_start_date_" + e).val());
    $("#release_end_date_" + e).datetimepicker({
        minDate: "" + r,
		step: 15,
        format: "M d, Y h:i a",
		formatTime:	'h:i a',
        closeOnDateSelect: !1,
        closeOnTimeSelect: !0,
		validateOnBlur: false,
		minTime: stdteenddt.dateFormat('h:i a'),
		maxDate: enddte.dateFormat('Y/m/d'),
        onClose: function(a) {
            $("#release_end_date_" + e + "-error").hide(), $("#release_end_date_" + e + "-error").hide()
        }
    })
}


$(document).on("change", ".tba", function() {
    var t = $(this).data("count"),
        a = $("#count").val(),
        e = $(this).val(),
        n = $("#tkb_" + t).val(),
        l = parseInt(n) * parseInt($(this).val()),
        r = $("#total_ticket_available").val();
    $("#tbtkt_" + t).val(l);
    var s = 0;
    if ("" != e) {
        for (var i = 1; parseInt(i) <= parseInt(a); i = parseInt(i) + parseInt(1)) s = parseInt(s) + parseInt($("#tbtkt_" + i).val()) + parseInt($("#nota_" + i).val());
        parseInt(s) > parseInt(r) ? (alert("Total exceeds maximum quantity set, please adjust accordingly."), $(this).val("0"), $("#tbtkt_" + t).val("0")) : ($("#current_ticket_allocation").text(s), $("#hidden_current_ticket_allocation").val(s), $("#total_tkt_available_" + t).text(l))
    }
});


$(document).on("change", ".tkb", function() {
    var t = $(this).data("count"),
        a = $("#count").val(),
        e = $(this).val(),
        i = $("#tba_" + t).val(),
        n = parseInt(i) * parseInt($(this).val()),
        _ = $("#total_ticket_available").val();
    $("#tbtkt_" + t).val(n);
    var o = 0;
    if ("" != e) {
        for (var d = 1; parseInt(d) <= parseInt(a); d = parseInt(d) + parseInt(1)) o = parseInt(o) + parseInt($("#tbtkt_" + d).val()) + parseInt($("#nota_" + d).val());
        parseInt(o) > parseInt(_) ? (alert("Total exceeds maximum quantity set, please adjust accordingly."), $(this).val("0"), $("#tbtkt_" + t).val("0")) : ($("#current_ticket_allocation").text(o), $("#hidden_current_ticket_allocation").val(o), $("#total_tkt_available_" + t).text(n))
    }
});

$(document).on("click", ".t-edit", function() {
	jQuery(this).parent().find('.t-name').attr('autofocus',true).val('Ticket Name').focus().select();
	
});
$(document).on("click", ".tkt_type", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    $("#nota_" + a).val("0"), $("#tkb_" + a).val("0"), $("#tba_" + a).val("0"), $("#tbtkt_" + a).val("0"), "Single Tickets" == t ? ($("#div_no_of_tkt_available_" + a).show(), $("#div_bundle_" + a).hide()) : ($("#div_no_of_tkt_available_" + a).hide(), $("#div_bundle_" + a).show())
});

$(document).on("click", ".ticket_setup", function() {
    1 == $("#no").prop("checked") && ($(".third-party").hide(), $(".ticket-setup-options").hide()), 1 == $("#tix").prop("checked") && ($("#no").prop("checked", !1), $(".ticket-setup-options").show(), $(".third-party").hide()), 1 == $("#3rd").prop("checked") && ($("#no").prop("checked", !1), $(".ticket-setup-options").hide(), $(".third-party").show())
});

$(document).on("click", ".price_radio", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    $("#price_per_tkt_" + a).val(""), "Free" == t ? $("#div_price_per_tkt_" + a).hide() : $("#div_price_per_tkt_" + a).show()
});

$(document).on("change", ".nota", function() {
    var t = $(this).val(),
        a = $("#count").val(),
        e = $(this).data("count");
    if ("" != t) {
        for (var i = $("#total_ticket_available").val(), n = 0, _ = 1; parseInt(_) <= parseInt(a); _ = parseInt(_) + parseInt(1)) n = parseInt(n) + parseInt($("#nota_" + _).val()) + parseInt($("#tbtkt_" + _).val());
        parseInt(n) > parseInt(i) ? (alert("Total exceeds maximum quantity set, please adjust accordingly."), $(this).val("0")) : ($("#current_ticket_allocation").text(n), $("#hidden_current_ticket_allocation").val(n), $("#total_tkt_available_" + e).text(t))
    }
});

$(document).on("click", ".radio_tkt_start_time", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    "New Start Time" == t ? $("#div_tkt_start_date_" + a).show() : $("#div_tkt_start_date_" + a).hide()
});

$(document).on("click", ".radio_tkt_end_time", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    "New End Time" == t ? $("#div_tkt_end_date_" + a).show() : $("#div_tkt_end_date_" + a).hide()
});

$(document).on("click", ".radio_release_time", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    "Scheduled" == t ? $("#div_release_start_date_" + a).show() : $("#div_release_start_date_" + a).hide()
});

$(document).on("click", ".radio_expiration_time", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    "Scheduled" == t ? $("#div_release_end_date_" + a).show() : $("#div_release_end_date_" + a).hide()
});

$(document).on("click", ".promo_code", function() {
    var t = $(this).val(),
        a = $(this).data("count");
    "disabled" == t ? $("#div_promo_code_" + a).hide() : $("#div_promo_code_" + a).show()
});

$(document).on("click", ".del-tkt", function() {
	$("#DeleteTicketModal").show();
	var dataId = $(this).attr("data-cnt");
	$('#yesDELETTICk').attr('onClick','deletetickbymodal('+dataId+')');
    
});
function deletetickbymodal(cnt){
	 $('.acc-head'+cnt).parent().parent().remove();
	 $("#DeleteTicketModal").hide();
        var t = $("#count").val();
        t = parseInt(t) - parseInt(1), $("#count").val(t);
        for (var a = 0; parseInt(a) < parseInt(t); a = parseInt(a) + parseInt(1))
			$("#div_ticket").find(".tkt-no:eq(" + a + ")").text(parseInt(a) + parseInt(1));
}
$(document).on("change", ".charge-tax", function() {
    "yes" == $(this).val() ? $(".tax-yes").show() : $(".tax-yes").hide(), $("#tax_id").val(""), $("#tax_name").val(""), $("#tax_rate").val("")
});

$(document).on("change", ".price_class", function() {
    var t = $(this).val();
    $(this).val(parseFloat(t).toFixed(2))
});

$(document).on("click", ".radio_tkt_limit", function() {
    var t = $(this).data("count");
    "yes" == $(this).val() ? $("#tkt_order_limit_" + t).show() : $("#tkt_order_limit_" + t).hide()
});

$(document).on("click", ".tkt_start_date", function(t) {
    var a = $(this).data("counter");
    $("#start").val(a)
});

$(document).on("click", ".tkt_end_date", function(t) {
    var a = $(this).data("counter");
    $("#start").val(a)
});

$(document).on("click", ".release_start_date", function(t) {
    var a = $(this).data("counter");
    $("#start").val(a)
});

$(document).on("change", ".charge-tax2", function() {
    "yes" == $(this).val() ? $(".one-full").show() : $(".one-full").hide()
});


var i, acc = document.getElementsByClassName("s_h-arrow");
for (i = 0; i < acc.length; i++) acc[i].addEventListener("click", function() {
   // this.classList.toggle("active");
   this.parentElement.classList.toggle("active");
    var e = this.parentElement.nextElementSibling;
    "block" === e.style.display ? e.style.display = "none" : e.style.display = "block"
});