<?php
/*
Template Name: Create Tickets
*/

global $wpdb;

if(isset($_POST['btnAddTicket'])) {
    
    $_SESSION['event_data'] = $_POST;
}

if(isset($_POST['btnTicketSubmit'])) {

    $_SESSION['ticket_data'] = $_POST;    
    header("Location: ".site_url().'/create-event');
}

if(isset($_GET['edit']) && $_GET['edit'] != '') {

    $event_id = $_GET['edit'];
   
    $ch      = curl_init(API_URL.'ticketTypes?eventId='.$event_id);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: ' . $token
    ));
    $tkt_response = curl_exec($ch);
    curl_close($ch);
    $tkt = json_decode($tkt_response);

    if($tkt->success && !empty($tkt->ticketType)) {

        $tickets = $tkt->ticketType;         
           
    }  
}

//echo '<pre>';print_r($_SESSION['ticket_data']);die;

$countries = $wpdb->get_results("Select * from wp_countries");

get_header(); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/1.1.1/jquery.datetimepicker.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/1.1.1/jquery.datetimepicker.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
<style>
    .error {
        color: red !important;
    }
</style>
<div id="main-content">   
    <div class="outer-wrapper">
        <div id="setup_div" class="container container-home">
            <input type="hidden" id="start" value="0">  
            <h3 class="h3-title">Configuring Your Tickets</h3>
            <button class="btn-return"><a href="<?php echo site_url(); ?>/create-event/"><i class="fa fa-toggle-left"></i> <span>Return to Event Setup</span></a></button>
            <ul class="progressbar">
                <li class="active">Setup</li>
                <li>Review and Submit</li>
            </ul>
            <p style="float:left;width:100%;text-align:center;margin-bottom:10px;font-size: 15px;">Complete each required section; section NEXT to proceed.</p>
            <hr/>
            <div class="ticket-setup">
                <h3>Setup Tickets Using Snapd TIX
                    <label class="switch">
                        <input type="checkbox" checked class="setup_switch">
                        <span class="slider1 round"></span>
                    </label>
                </h3>
                <p>Please setup your ticket types for different ticket requirements such as Gerneral Admission, Early Birds or VIP.</p>
                <p>Ticket type further help distinguish seating arrangements for different sections in a venue or different price points on different types of tickets.</p>
                <p>Use tickets types to help organize your ticket batches and provide clarity for your customer.</p>
                <p>Add details ton instruct your customer to understand what is included with their ticket , any special bonuses or specifics on what may be limited per entry.</p>
            </div>
            <div class="paid-event">
                <h5>About Paid Events</h5>
                <p>   Event organizers may absorb (pay) a percentage of the convenience fee applied to tickets.</p>
                <p>     If you select to absorb part, or the full amount of convenience fee, the percentage will be removed from your payout after the event is over.</p>
                <p>  If you wish tickets purchasers to absorb all fee, keep the % Convenience Fee Paid by you at 0%</p>
            </div>

            <?php if(isset($tickets)) { ?>

                <form id="tkt_form" method="post" action="">
                    <input type="hidden" value="<?php echo count($tickets)?>" id="count" name="count">
                    <div class="tkt_avail">
                        <div class="h-left">
                            <h3> Enter total tickets available for all ticket types </h3>
                            <input min="0" type="number" value="<?php echo $tickets[0]->max;?>" id="total_ticket_available" name="total_ticket_available">
                        </div>
                        <p class="help-text">Why do we ask this? <br/> To prevent over selling of required tickets via multiple ticket types.</p>
                    </div>
                    <div class="tkt_avail">
                        <div class="h-left">
                            <h3> Current ticket allocation </h3>
                            <span id="current_ticket_allocation">0</span>
                            <input type="hidden" name="current_ticket_allocation" id="hidden_current_ticket_allocation" value="0">
                        </div>
                        <p class="help-text">Why do we display this?<br/>To monitor your total ticket distribution against your total tickets availabe as shown above
                            <span class="current-tkt"><i class="fa fa-search"></i> Current Ticket Report</span>
                        </p>
                    </div>                  
                    <div class="tkt_avail">
                        <h3 style="width:44%;text-align: right;">Do you need to charge tax for this event?</h3>
                        <div class="tax-outer">
                            <select class="charge-tax" name="tkt_tax">
                                <option value="no" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile != '') ? '' : 'selected';?>>No</option>
                                <option value="yes" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile != '') ? 'selected' : '';?>>Yes</option>
                            </select>
                            <div class="tooltip2"><i class="fa fa-info"></i>
                                <span class="tooltiptext2"><b>Tax Information</b><br>
                                    The application of taxes on this event is subject to the nature of your event, your tax status, location of event and other factors that may determine the inclusion of a tax rate. Please consult with a tax specialist regarding your taxation requirements for collection and remittance
                                    purposes.
                                    <br>
                                    Any information provided will be displayed on all ticket invoices and reports.
                                </span>
                            </div>
                        </div>
                        <div class="tax-yes" style="display: <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile != '') ? '' : 'none';?>;">
                            <label>Country</label>
                            <select name="country">
                                <?php foreach($countries as $row) { ?>
                                    <option value="<?php echo $row->id?>" <?php echo (isset($tickets[0]->tax_profile) && $tickets[0]->tax_profile->country_id == $row->id) ? 'selected' : '';?>><?php echo $row->name;?></option>
                                <?php }?>
                            </select>
                            <label> Tax ID <input type="text" placeholder="Id" name="tax_id" id="tax_id" required title="Please enter Tax ID" value="<?php echo isset($tickets[0]->tax_profile) ? $tickets[0]->tax_profile->tax_id : '';?>"> </label>
                            <label> Tax Name <input type="text" placeholder="Name" name="tax_name" id="tax_name" required title="Please enter Tax Name" value="<?php echo isset($tickets[0]->tax_profile) ? $tickets[0]->tax_profile->name : '';?>"> </label>
                            <label> Tax Rate <input type="number" placeholder="Rate" min="0" name="tax_rate" id="tax_rate" required title="Please enter Tax Rate" value="<?php echo isset($tickets[0]->tax_profile) ? $tickets[0]->tax_profile->tax_rate_aggregate : '';?>"> % </label><span class="tax-rate">Select taxation option for each ticket type setup below.</span>
                        </div>
                    </div>
                    <hr/>
                    <p><b>All required fields marked with (*).</b></p><br/>

                    <div id="div_ticket">
                        <?php if(isset($tickets)){ 
                            
                        $j=1;
                        foreach($tickets as $key=>$val) { ?>

                            <div class="tkt-details">
                                <div class="tickets-total-sidebar" style="margin-left: -110px;">
                                    <div class="tkt-no"><?php echo $j;?></div>
                                    <div class="tkt-total-sold">0</div>
                                    <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_<?php echo $j;?>"><?php echo $val->order_limit;?></span></div>
                                </div>
                                <!-- ticket detail start -->
                                <div class="form-left">
                                    <label>Ticket Name*</label>
                                    <p  class="tkt_name_div"><input type="text" name="ticket_name[]" value="<?php echo $val->name;?>" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                                    <label>Details (optional)</label>
                                    <p><input type="text" name="ticket_details[]" value="<?php echo $val->note;?>" placeholder=" Ticket details"> </p>
                                    <div class="row-out">
                                        <div class="row-1">
                                            <label>Ticket type</label>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Single Tickets" <?php echo ($val->bundled_yn) ? '' : 'checked' ;?>> <span class="checkmark1"> </span> Single Tickets
                                            </span>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Bundled Tickets" <?php echo ($val->bundled_yn) ? 'checked' : '';?>> <span class="checkmark1"> </span>Bundled Tickets
                                            </span>
                                            <p class="tkt-type">Use Bundled tickets when you want to sell group tickets package<br/>
                                                (i.e. table of 10, golf foursome, family package)
                                            </p>
                                        </div>
                                        <div class="row-2">
                                            <label>Price type</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Paid" <?php echo ($val->paid_yn) ? 'checked' : '';?>>  <span class="checkmark1"> </span> Paid</span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Free" <?php echo ($val->paid_yn) ? '' : 'checked';?>>  <span class="checkmark1"> </span> Free</span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="row" id="div_price_per_tkt_<?php echo $j;?>" style="display: <?php echo ($val->paid_yn) ? '' : 'none';?>">
                                            <label>Price Per Ticket ($CAD)*</label>
                                            <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_<?php echo $j;?>" placeholder="100.00" required class="price_class" title="Please enter Price per ticket" value="<?php echo $val->price;?>"> </p>
                                        </div>
                                        <div class="row" id="div_no_of_tkt_available_<?php echo $j;?>" style="display: <?php echo ($val->bundled_yn) ? 'none' : ''?>">
                                            <label>Number of Tickets Available</label>
                                            <p> <input min="0" type="number" class="nota" data-count="<?php echo $j;?>" name="no_of_tkt_available[]" id="nota_<?php echo $j;?>" placeholder="100" required value="<?php echo ($val->bundled_yn) ? 0 : $val->order_limit;?>" title=""> </p>
                                        </div>
                                    </div>
                                    <div class="row-out" style="display: <?php echo ($val->bundled_yn) ? '' : 'none';?>;" id="div_bundle_<?php echo $j;?>">
                                        <div class="row">
                                            <label>Tickets Per Bundle</label>
                                            <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="<?php echo $j;?>" id="tkb_<?php echo $j;?>" value="<?php echo ($val->bundled_yn) ?  $val->order_limit/$val->bundle_size : 0;?>" placeholder="0" required> x
                                        </div>
                                        <div class="row">
                                            <label>Bundles Available</label>
                                            <input min="0" type="number" class="tba" name="bundles_available[]" value="<?php echo ($val->bundled_yn) ? $val->bundle_size : 0;?>" data-count="<?php echo $j;?>" id="tba_<?php echo $j;?>" placeholder="100" required> =
                                        </div>
                                        <div class="row">
                                            <label>Total Tickets</label>
                                            <input min="0" type="number" class="tbtkt" id="tbtkt_<?php echo $j;?>" name="total_tickets[]" value="<?php echo ($val->bundled_yn) ? $val->order_limit : 0;?>" placeholder="200" required>
                                        </div>
                                        <div style="float: right;position: relative;left: -10px;" class="row">
                                            <label>Tax Inclusion</label>
                                            <select style="width: 90%;" name="tax_inclusion[]">
                                                <option value="No">No</option>
                                                <option value="Yes, tax ADDED to ticket price">Yes, tax ADDED to ticket price</option>
                                                <option value="Yes, tax INCLUDED in ticket price">Yes, tax INCLUDED in ticket price</option>
                                            </select>
                                            <div class="tooltip2"><i class="fa fa-info"></i>
                                                <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                                    ADDED will display ticket price as stated.<br>
                                                    INCLUDED will display ticket price before taxes.
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width:38%;" class="row">
                                            <label>Ticket Start Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="Match Event" <?php echo ($val->start) ? '' : 'checked';?>> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="New Start Time" <?php echo ($val->start) ? 'checked' : '';?>> <span class="checkmark1"> </span>New Start Time </span>
                                            <div style="width: 50%; display: <?php echo ($val->start) ? '' : 'none';?>;" class="row" id="div_tkt_start_date_<?php echo $j;?>">
                                                <label class="start-date" for="tkt_start_date">Start 
                                                    <input type="text" id="tkt_start_date_<?php echo $j;?>" data-counter="<?php echo $j;?>" class="start_datepicker tkt_start_date" name="tkt_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($value->start) ? date('M d, Y H:i a', strtotime($val->start)) :  'NOT SET';?>">
                                                    <small style="font-size: 12px;">Select to change</small>
                                                </label>
                                            </div>
                                        </div>
                                        <div style="width:38%;" class="row">
                                            <label>Ticket End Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="Match Event" <?php echo ($val->end) ? '' : 'checked';?>> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="New End Time" <?php echo ($val->end) ? 'checked' : '';?>> <span class="checkmark1"> </span>New End Time </span>
                                            <div style="width: 50%; display: <?php echo ($val->end) ? '' : 'none';?>;" class="row" id="div_tkt_end_date_<?php echo $j;?>">
                                                <label class="start-date" for="tkt_end_date">End 
                                                    <input type="text" id="tkt_end_date_<?php echo $j;?>" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($val->end) ? date('M d, Y H:i a', strtotime($val->end)) :  'NOT SET';?>">
                                                    <small style="font-size: 12px;">Select to change</small>
                                                </label>
                                            </div>
                                        </div>
                                        <div style="width:24%;" class="row">
                                            <label>Ticket Limit per Order</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="no" checked><span class="checkmark1"> </span>No</span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="yes"> <span class="checkmark1"> </span>Yes</span>
                                            <p><input type="number" min="0" name="tkt_order_limit[]" value="" id="tkt_order_limit_<?php echo $j;?>" style="display: none;"></p>
                                        </div>
                                    </div>
                            
                                    <div class="row-out">
                                        <div style="width: 38%;" class="row">
                                            <label> Release Start Date & Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Immediately" <?php echo ($val->release) ? '' : 'checked';?>> <span class="checkmark1"> </span>Immediately</span>
                                            <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Scheduled" <?php echo ($val->release) ? 'checked' : '';?>> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                        <div style="width: 38%;" class="row">
                                            <label>Expiration Start Date & Time </label>
                                            <span class="radio-chk none"> <input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="None" checked> <span class="checkmark1"> </span>None</span>
                                            <span class="radio-chk"> <span> <input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width: 38%; display: <?php echo ($val->release) ? '' : 'none';?>;" class="row" id="div_release_start_date_<?php echo $j;?>">
                                            <label class="start-date" for="release_start_date_<?php echo $j;?>">Start <input type="text" id="release_start_date_<?php echo $j;?>" class="start_datepicker release_start_date" data-counter="<?php echo $j;?>" name="release_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($val->release) ? date('M d, Y H:i a', strtotime($val->release)) : 'NOT SET';?>"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                        <div style="width: 38%; display: none;?>;" class="row" id="div_release_end_date_<?php echo $j;?>">
                                            <label class="start-date" for="release_end_date_<?php echo $j;?>">End <input type="text" id="release_end_date_<?php echo $j;?>" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="promo_div">
                                            <label> Promo Code</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                            <span style="margin-left: 24px; margin-right: 17px;" class="radio-chk"><input class="promo_code" data-count="<?php echo $j;?>" type="radio" name="radio_promo_code_<?php echo $j;?>" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                                        </div>
                                    </div>
                                    <div class="row-out" id="div_promo_code_1" style="display: none;">
                                        <div class="row">
                                            <label>Code Name (min. 6 characters)</label>
                                            <p><input type="text" name="code_name[]" placeholder="SAVE10">
                                        </div>
                                        <div class="row">
                                            <label>Code value</label>
                                            <p><input type="text" name="code_value[]" placeholder="10.00"> </p>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="date-tkt-typ">
                                            <label> Select Date(s) for this Ticket Type</label>                               
                                      
                                        </div>
                                    </div>
                                </div>
                                <div class="form-right">
                                    <label>% Convernience Fee Paid By You.</label>
                                    <select name="select_per">
                                        <option value="0">0%</option>
                                        <option value="25">25%</option>
                                        <option value="50">50%</option>
                                        <option value="75">75%</option>
                                        <option value="100">100%</option>
                                    </select>
                                    <label> Ticket Breakdown</label>
                                    <table>
                                        <tr>
                                            <th></th>
                                            <th>Customer<br/> Pays</th>
                                            <th>You <br/>  Receive</th>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket</td>
                                            <td>$100.00</td>
                                            <td>$100.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket tax </td>
                                            <td>$0.00</td>
                                            <td>$0.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee</td>
                                            <td>$0.00</td>
                                            <td>-$6.88</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee tax</td>
                                            <td>$0.00</td>
                                            <td>-$0.89</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Total</td>
                                            <td class="bold1" >$100.00</td>
                                            <td class="bold1">$92.23</td>
                                        </tr>
                                    </table>
                                </div>
                                <?php if($j > 1){ ?>
                                    
                                    <p style="cursor:pointer;" class="del-tkt"><span>-</span> Remove Ticket Type</p>
                                <?php }?>                               
                            </div>
                        <?php $j++;}
                        } else { ?>

                            <div class="tkt-details">
                                <div class="tickets-total-sidebar" style="margin-left: -110px;">
                                    <div class="tkt-no">1</div>
                                    <div class="tkt-total-sold">0</div>
                                    <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_1">0</span></div>
                                </div>
                                <!-- ticket detail start -->
                                <div class="form-left">
                                    <label>Ticket Name*</label>
                                    <p  class="tkt_name_div"><input type="text" name="ticket_name[]" value="" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                                    <label>Details (optional)</label>
                                    <p><input type="text" name="ticket_details[]" value="" placeholder=" Ticket details"> </p>
                                    <div class="row-out">
                                        <div class="row-1">
                                            <label>Ticket type</label>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Single Tickets" checked="checked"> 
                                                <span class="checkmark1"> </span> Single Tickets
                                            </span>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Bundled Tickets"> 
                                                <span class="checkmark1"> </span>Bundled Tickets
                                            </span>
                                            <p class="tkt-type">Use Bundled tickets when you want to sell group tickets package<br/>
                                                (i.e. table of 10, golf foursome, family package)
                                            </p>
                                        </div>
                                        <div class="row-2">
                                            <label>Price type</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Paid" checked="checked">  <span class="checkmark1"> </span> Paid</span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Free" >  <span class="checkmark1"> </span> Free</span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="row" id="div_price_per_tkt_1">
                                            <label>Price Per Ticket ($CAD)*</label>
                                            <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_1" placeholder="100.00" required class="price_class" title="Please enter Price per ticket"> </p>
                                        </div>
                                        <div class="row" id="div_no_of_tkt_available_1">
                                            <label>Number of Tickets Available</label>
                                            <p> <input min="0" type="number" class="nota" data-count="1" name="no_of_tkt_available[]" id="nota_1" placeholder="100" required value="0" title=""> </p>
                                        </div>
                                    </div>
                                    <div class="row-out" style="display: none;" id="div_bundle_1">
                                        <div class="row">
                                            <label>Tickets Per Bundle</label>
                                            <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="1" id="tkb_1" value="0" placeholder="0" required> x
                                        </div>
                                        <div class="row">
                                            <label>Bundles Available</label>
                                            <input min="0" type="number" class="tba" name="bundles_available[]" value="0" data-count="1" id="tba_1" placeholder="100" required> =
                                        </div>
                                        <div class="row">
                                            <label>Total Tickets</label>
                                            <input min="0" type="number" class="tbtkt" id="tbtkt_1" name="total_tickets[]" value="0" placeholder="200" required>
                                        </div>
                                        <div style="float: right;position: relative;left: -10px;" class="row">
                                            <label>Tax Inclusion</label>
                                            <select style="width: 90%;" name="tax_inclusion[]">
                                                <option value="No">No</option>
                                                <option value="Yes, tax ADDED to ticket price">Yes, tax ADDED to ticket price</option>
                                                <option value="Yes, tax INCLUDED in ticket price">Yes, tax INCLUDED in ticket price</option>
                                            </select>
                                            <div class="tooltip2"><i class="fa fa-info"></i>
                                                <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                                    ADDED will display ticket price as stated.<br>
                                                    INCLUDED will display ticket price before taxes.
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width:38%;" class="row">
                                            <label>Ticket Start Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>
                                            <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_1">
                                                <label class="start-date" for="tkt_start_date">Start <input type="text" id="tkt_start_date_1" data-counter="1" class="start_datepicker tkt_start_date" name="tkt_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                            </div>
                                        </div>
                                        <div style="width:38%;" class="row">
                                            <label>Ticket End Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"> <input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>
                                            <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_1">
                                                <label class="start-date" for="tkt_end_date">End <input type="text" id="tkt_end_date_1" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                            </div>
                                        </div>
                                        <div style="width:24%;" class="row">
                                            <label>Ticket Limit per Order</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="no" checked> <span class="checkmark1"> </span>No</span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="yes"> <span class="checkmark1"> </span>Yes</span>
                                            <p><input type="number" min="0" name="tkt_order_limit[]" id="tkt_order_limit_1" style="display: none;"></p>
                                        </div>
                                    </div>
                            
                                    <div class="row-out">
                                        <div style="width: 38%;" class="row">
                                            <label> Release Start Date & Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>
                                            <span class="radio-chk"> <input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                        <div style="width: 50%;" class="row">
                                            <label>Expiration Start Date & Time </label>
                                            <span class="radio-chk none"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="None" checked> <span class="checkmark1"> </span>None</span>
                                            <span class="radio-chk"> <span> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width: 50%; display: none;" class="row" id="div_release_start_date_1">
                                            <label class="start-date" for="release_start_date">Start <input type="text" id="release_start_date_1" class="start_datepicker release_start_date" data-counter="1" name="release_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                        <div style="width: 50%; display: none;" class="row" id="div_release_end_date_1">
                                            <label class="start-date" for="release_end_date">End <input type="text" id="release_end_date_1" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="promo_div">
                                            <label> Promo Code</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                            <span style="margin-left: 24px; margin-right: 17px;" class="radio-chk"><input class="promo_code" data-count="1" type="radio" name="radio_promo_code_1" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                                        </div>
                                    </div>
                                    <div class="row-out" id="div_promo_code_1" style="display: none;">
                                        <div class="row">
                                            <label>Code Name (min. 6 characters)</label>
                                            <p><input type="text" name="code_name[]" placeholder="SAVE10">
                                        </div>
                                        <div class="row">
                                            <label>Code value</label>
                                            <p><input type="text" name="code_value[]" placeholder="10.00"> </p>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="date-tkt-typ">
                                            <label> Select Date(s) for this Ticket Type</label>                                        
                                        
                                        </div>
                                    </div>
                                </div>
                                <div class="form-right">
                                    <label>% Convernience Fee Paid By You.</label>
                                    <select name="select_per">
                                        <option value="0">0%</option>
                                        <option value="25">25%</option>
                                        <option value="50">50%</option>
                                        <option value="75">75%</option>
                                        <option value="100">100%</option>
                                    </select>
                                    <label> Ticket Breakdown</label>
                                    <table>
                                        <tr>
                                            <th></th>
                                            <th>Customer<br/> Pays</th>
                                            <th>You <br/>  Receive</th>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket</td>
                                            <td>$100.00</td>
                                            <td>$100.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket tax </td>
                                            <td>$0.00</td>
                                            <td>$0.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee</td>
                                            <td>$0.00</td>
                                            <td>-$6.88</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee tax</td>
                                            <td>$0.00</td>
                                            <td>-$0.89</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Total</td>
                                            <td class="bold1" >$100.00</td>
                                            <td class="bold1">$92.23</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        <?php }?>                 
                        <!-- Right form End -->
                
                        <!-- ticket detail end -->
                        <p class="add-new" style="cursor:pointer;" id="add_more_tkt"><span>+</span> Add New Ticket Type</p>
                    </div>
                    <div class="help-btn"><i class="fa fa-question"></i> Need Help! <a href="#">Visit our support site for answers</a></div>
                    <button class="next-btn" type="submit" name="btnTicketSubmit">NEXT</button>
                </form>
            <?php } else { ?>

                <form id="tkt_form" method="post" action="">
                    <input type="hidden" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['count'] : 1;?>" id="count" name="count">
                    <div class="tkt_avail">
                        <div class="h-left">
                            <h3> Enter total tickets available for all ticket types </h3>
                            <input min="0" type="number" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['total_ticket_available'] : 0;?>" id="total_ticket_available" name="total_ticket_available">
                        </div>
                        <p class="help-text">Why do we ask this? <br/> To prevent over selling of required tickets via multiple ticket types.</p>
                    </div>
                    <div class="tkt_avail">
                        <div class="h-left">
                            <h3> Current ticket allocation </h3>
                            <span id="current_ticket_allocation"><?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['current_ticket_allocation'] : 0;?></span>
                            <input type="hidden" name="current_ticket_allocation" id="hidden_current_ticket_allocation" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['current_ticket_allocation'] : 0;?>">
                        </div>
                        <p class="help-text">Why do we display this?<br/>To monitor your total ticket distribution against your total tickets availabe as shown above
                            <span class="current-tkt"><i class="fa fa-search"></i> Current Ticket Report</span>
                        </p>
                    </div>
                    <div class="tkt_avail">
                        <h3 style="width:44%;text-align: right;">Do you need to charge tax for this event?</h3>
                        <div class="tax-outer">
                            <select class="charge-tax" name="tkt_tax">
                                <option value="no" <?php echo isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['tkt_tax'] == "no") ? 'selected' : '';?>>No</option>
                                <option value="yes" <?php echo isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['tkt_tax'] == "yes") ? 'selected' : '';?>>Yes</option>
                            </select>
                            <div class="tooltip2"><i class="fa fa-info"></i>
                                <span class="tooltiptext2"><b>Tax Information</b><br>
                                    The application of taxes on this event is subject to the nature of your event, your tax status, location of event and other factors that may determine the inclusion of a tax rate. Please consult with a tax specialist regarding your taxation requirements for collection and remittance
                                    purposes.
                                    <br>
                                    Any information provided will be displayed on all ticket invoices and reports.
                                </span>
                            </div>
                        </div>
                        <div class="tax-yes" style="display: <?php echo isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['tkt_tax'] == "yes") ? '' : 'none';?>;">
                            <label>Country</label>
                            <select name="country">
                                <?php foreach($countries as $row) { ?>
                                    <option value="<?php echo $row->id?>" <?php echo  isset($_SESSION['ticket_data']) && ($_SESSION['ticket_data']['country'] == $row->id) ? 'selected' : '';?>><?php echo $row->name;?></option>
                                <?php }?>
                            </select>
                            <label> Tax ID <input type="text" placeholder="Id" name="tax_id" id="tax_id" required title="Please enter Tax ID" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['tax_id'] : '';?>"> </label>
                            <label> Tax Name <input type="text" placeholder="Name" name="tax_name" id="tax_name" required title="Please enter Tax Name" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['tax_name'] : '';?>"> </label>
                            <label> Tax Rate <input type="number" placeholder="Rate" min="0" name="tax_rate" id="tax_rate" required title="Please enter Tax Rate" value="<?php echo isset($_SESSION['ticket_data']) ? $_SESSION['ticket_data']['tax_rate'] : '';?>"> % </label><span class="tax-rate">Select taxation option for each ticket type setup below.</span>
                        </div>
                    </div>
                    <hr/>
                    <p><b>All required fields marked with (*).</b></p><br/>

                    <div id="div_ticket">
                        <?php if(isset($_SESSION['ticket_data'])){
                            
                        $j=1;
                        foreach($_SESSION['ticket_data']['ticket_name'] as $key=>$val) { ?>

                            <div class="tkt-details">
                                <div class="tickets-total-sidebar" style="margin-left: -110px;">
                                    <div class="tkt-no"><?php echo $j;?></div>
                                    <div class="tkt-total-sold">0</div>
                                    <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_<?php echo $j;?>"><?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? $_SESSION['ticket_data']['no_of_tkt_available'][$key] : $_SESSION['ticket_data']['total_tickets'][$key];?></span></div>
                                </div>
                                <!-- ticket detail start -->
                                <div class="form-left">
                                    <label>Ticket Name*</label>
                                    <p  class="tkt_name_div"><input type="text" name="ticket_name[]" value="<?php echo $_SESSION['ticket_data']['ticket_name'][$key]?>" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                                    <label>Details (optional)</label>
                                    <p><input type="text" name="ticket_details[]" value="<?php echo $_SESSION['ticket_data']['ticket_details'][$key]?>" placeholder=" Ticket details"> </p>
                                    <div class="row-out">
                                        <div class="row-1">
                                            <label>Ticket type</label>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Single Tickets" <?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 'checked' : '';?>> <span class="checkmark1"> </span> Single Tickets
                                            </span>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="<?php echo $j;?>" name="radio_tkt_type_<?php echo $j;?>" value="Bundled Tickets" <?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? '' : 'checked';?>> <span class="checkmark1"> </span>Bundled Tickets
                                            </span>
                                            <p class="tkt-type">Use Bundled tickets when you want to sell group tickets package<br/>
                                                (i.e. table of 10, golf foursome, family package)
                                            </p>
                                        </div>
                                        <div class="row-2">
                                            <label>Price type</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Paid" <?php echo ($_SESSION['ticket_data']['price_radio_'.$j] == 'Paid') ? 'checked' : '';?>>  <span class="checkmark1"> </span> Paid</span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="price_radio" name="price_radio_<?php echo $j;?>" value="Free" <?php echo ($_SESSION['ticket_data']['price_radio_'.$j] == 'Paid') ? '' : 'checked';?>>  <span class="checkmark1"> </span> Free</span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="row" id="div_price_per_tkt_<?php echo $j;?>">
                                            <label>Price Per Ticket ($CAD)*</label>
                                            <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_<?php echo $j;?>" placeholder="100.00" required class="price_class" title="Please enter Price per ticket" value="<?php echo ($_SESSION['ticket_data']['price_radio_'.$j] == 'Paid') ?  $_SESSION['ticket_data']['price_per_tkt'][$key] : '';?>"> </p>
                                        </div>
                                        <div class="row" id="div_no_of_tkt_available_<?php echo $j;?>">
                                            <label>Number of Tickets Available</label>
                                            <p> <input min="0" type="number" class="nota" data-count="<?php echo $j;?>" name="no_of_tkt_available[]" id="nota_<?php echo $j;?>" placeholder="100" required value="<?php echo $_SESSION['ticket_data']['no_of_tkt_available'][$key];?>" title=""> </p>
                                        </div>
                                    </div>
                                    <div class="row-out" style="display: <?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 'none' : '';?>;" id="div_bundle_<?php echo $j;?>">
                                        <div class="row">
                                            <label>Tickets Per Bundle</label>
                                            <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="<?php echo $j;?>" id="tkb_<?php echo $j;?>" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 0 : $_SESSION['ticket_data']['ticket_per_bundle'][$key];?>" placeholder="0" required> x
                                        </div>
                                        <div class="row">
                                            <label>Bundles Available</label>
                                            <input min="0" type="number" class="tba" name="bundles_available[]" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 0 : $_SESSION['ticket_data']['bundles_available'][$key];?>" data-count="<?php echo $j;?>" id="tba_<?php echo $j;?>" placeholder="100" required> =
                                        </div>
                                        <div class="row">
                                            <label>Total Tickets</label>
                                            <input min="0" type="number" class="tbtkt" id="tbtkt_<?php echo $j;?>" name="total_tickets[]" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_type_'.$j] == 'Single Tickets') ? 0 : $_SESSION['ticket_data']['total_tickets'][$key];?>" placeholder="200" required>
                                        </div>
                                        <div style="float: right;position: relative;left: -10px;" class="row">
                                            <label>Tax Inclusion</label>
                                            <select style="width: 90%;" name="tax_inclusion[]">
                                                <option value="No" <?php echo ($_SESSION['ticket_data']['tax_inclusion'][$key] == 'No') ? 'selected' : '';?>>No</option>
                                                <option value="Yes, tax ADDED to ticket price" <?php echo ($_SESSION['ticket_data']['tax_inclusion'][$key] == 'Yes, tax ADDED to ticket price') ? 'selected' : '';?>>Yes, tax ADDED to ticket price</option>
                                                <option value="Yes, tax INCLUDED in ticket price" <?php echo ($_SESSION['ticket_data']['tax_inclusion'][$key] == 'Yes, tax INCLUDED in ticket price') ? 'selected' : '';?>>Yes, tax INCLUDED in ticket price</option>
                                            </select>
                                            <div class="tooltip2"><i class="fa fa-info"></i>
                                                <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                                    ADDED will display ticket price as stated.<br>
                                                    INCLUDED will display ticket price before taxes.
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width:38%;" class="row">
                                            <label>Ticket Start Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="Match Event" <?php echo ($_SESSION['ticket_data']['radio_tkt_start_time_'.$j] == 'Match Event') ? 'checked' : '';?>> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_start_time" name="radio_tkt_start_time_<?php echo $j;?>" value="New Start Time" <?php echo ($_SESSION['ticket_data']['radio_tkt_start_time_'.$j] == 'New Start Time') ? 'checked' : '';?>> <span class="checkmark1"> </span>New Start Time </span>
                                            <div style="width: 50%; display: <?php echo ($_SESSION['ticket_data']['radio_tkt_start_time_'.$j] == 'New Start Time') ? '' : 'none';?>;" class="row" id="div_tkt_start_date_<?php echo $j;?>">
                                                <label class="start-date" for="tkt_start_date">Start 
                                                    <input type="text" id="tkt_start_date_<?php echo $j;?>" class="start_datepicker tkt_start_date" data-counter="<?php echo $j;?>" name="tkt_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['tkt_start_date'][$key] == 'NOT SET') ? 'NOT SET' :  $_SESSION['ticket_data']['tkt_start_date'][$key];?>">
                                                    <small style="font-size: 12px;">Select to change</small>
                                                </label>
                                            </div>
                                        </div>
                                        <div style="width:38%;" class="row">
                                            <label>Ticket End Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="Match Event" <?php echo ($_SESSION['ticket_data']['radio_tkt_end_time_'.$j] == 'Match Event') ? 'checked' : '';?>> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_end_time" name="radio_tkt_end_time_<?php echo $j;?>" value="New End Time" <?php echo ($_SESSION['ticket_data']['radio_tkt_end_time_'.$j] == 'New End Time') ? 'checked' : '';?>> <span class="checkmark1"> </span>New End Time </span>
                                            <div style="width: 50%; display: <?php echo ($_SESSION['ticket_data']['radio_tkt_end_time_'.$j] == 'New End Time') ? '' : 'none';?>;" class="row" id="div_tkt_end_date_<?php echo $j;?>">
                                                <label class="start-date" for="tkt_end_date">End 
                                                    <input type="text" id="tkt_end_date_<?php echo $j;?>" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['tkt_end_date'][$key] == 'NOT SET') ? 'NOT SET' :  $_SESSION['ticket_data']['tkt_end_date'][$key];?>">
                                                    <small style="font-size: 12px;">Select to change</small>
                                                </label>
                                            </div>
                                        </div>
                                        <div style="width:24%;" class="row">
                                            <label>Ticket Limit per Order</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="no" <?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'no') ? 'checked' : '';?>> <span class="checkmark1"> </span>No</span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_tkt_limit" name="radio_tkt_limit_<?php echo $j;?>" value="yes" <?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'yes') ? 'checked' : '';?>> <span class="checkmark1"> </span>Yes</span>
                                            <p><input type="number" min="0" name="tkt_order_limit[]" value="<?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'yes') ? $_SESSION['ticket_data']['tkt_order_limit'][$key] : '';?>" id="tkt_order_limit_<?php echo $j;?>" style="display: <?php echo ($_SESSION['ticket_data']['radio_tkt_limit_'.$j] == 'yes') ? '' : 'none';?>;"></p>
                                        </div>
                                    </div>
                            
                                    <div class="row-out">
                                        <div style="width: 38%;" class="row">
                                            <label> Release Start Date & Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Immediately" <?php echo ($_SESSION['ticket_data']['radio_release_time_'.$j] == 'Immediately') ? 'checked' : '';?>> <span class="checkmark1"> </span>Immediately</span>
                                            <span class="radio-chk"> <input type="radio" data-count="<?php echo $j;?>" class="radio_release_time" name="radio_release_time_<?php echo $j;?>" value="Scheduled" <?php echo ($_SESSION['ticket_data']['radio_release_time_'.$j] == 'Scheduled') ? 'checked' : '';?>> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                        <div style="width: 38%;" class="row">
                                            <label>Expiration Start Date & Time </label>
                                            <span class="radio-chk none"> <input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="None" <?php echo ($_SESSION['ticket_data']['radio_expiration_time_'.$j] == 'None') ? 'checked' : '';?>> <span class="checkmark1"> </span>None</span>
                                            <span class="radio-chk"> <span> <input type="radio" data-count="<?php echo $j;?>" class="radio_expiration_time" name="radio_expiration_time_<?php echo $j;?>" value="Scheduled" <?php echo ($_SESSION['ticket_data']['radio_expiration_time_'.$j] == 'Scheduled') ? 'checked' : '';?>> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width: 38%; display: <?php echo ($_SESSION['ticket_data']['radio_release_time_'.$j] == 'Scheduled') ? '' : 'none';?>;" class="row" id="div_release_start_date_<?php echo $j;?>">
                                            <label class="start-date" for="release_start_date_<?php echo $j;?>">Start <input type="text" id="release_start_date_<?php echo $j;?>" data-counter="<?php echo $j;?>" class="start_datepicker release_start_date" name="release_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['release_start_date'][$key] == 'NOT SET') ? 'NOT SET' : $_SESSION['ticket_data']['release_start_date'][$key];?>"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                        <div style="width: 38%; display: <?php echo ($_SESSION['ticket_data']['radio_expiration_time_'.$j] == 'Scheduled') ? '' : 'none';?>;" class="row" id="div_release_end_date_1">
                                            <label class="start-date" for="release_end_date_<?php echo $j;?>">End <input type="text" id="release_end_date_<?php echo $j;?>" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="<?php echo ($_SESSION['ticket_data']['release_end_date'][$key] == 'NOT SET') ? 'NOT SET' : $_SESSION['ticket_data']['release_end_date'][$key];?>"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="promo_div">
                                            <label> Promo Code</label>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                            <span style="margin-left: 24px; margin-right: 17px;" class="radio-chk"><input class="promo_code" data-count="<?php echo $j;?>" type="radio" name="radio_promo_code_<?php echo $j;?>" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                            <span class="radio-chk"><input type="radio" data-count="<?php echo $j;?>" class="promo_code" name="radio_promo_code_<?php echo $j;?>" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                                        </div>
                                    </div>
                                    <div class="row-out" id="div_promo_code_1" style="display: none;">
                                        <div class="row">
                                            <label>Code Name (min. 6 characters)</label>
                                            <p><input type="text" name="code_name[]" placeholder="SAVE10">
                                        </div>
                                        <div class="row">
                                            <label>Code value</label>
                                            <p><input type="text" name="code_value[]" placeholder="10.00"> </p>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="date-tkt-typ">
                                            <label> Select Date(s) for this Ticket Type</label>
                                            
                                            <?php $i=1; foreach($_SESSION['event_data']['event_start_date'] as $key=>$val) { ?>

                                                <span class="chkbox">
                                                    <input type="checkbox" checked name="">
                                                    <span class="checkmark"></span> 
                                                    <?php 

                                                        $start_date = str_replace(array('am', 'pm'), '', $_SESSION['event_data']['event_start_date'][$key]);                                          
                                                        $end_date = str_replace(array('am', 'pm'), '', $_SESSION['event_data']['event_end_date'][$key]);

                                                        if(date('Y-m-d', strtotime($start_date)) == date('Y-m-d', strtotime($end_date))) {

                                                            echo $start_date.' '.'to'.' '.date('H:i:a', strtotime($end_date));
                                                        } else {

                                                            echo $start_date.' '.'to'.' '.$end_date;
                                                        }
                                                    ?>
                                                </span>

                                            <?php $i++;}?>                                
                                        
                                        </div>
                                    </div>
                                </div>
                                <div class="form-right">
                                    <label>% Convernience Fee Paid By You.</label>
                                    <select name="select_per">
                                        <option value="0">0%</option>
                                        <option value="25">25%</option>
                                        <option value="50">50%</option>
                                        <option value="75">75%</option>
                                        <option value="100">100%</option>
                                    </select>
                                    <label> Ticket Breakdown</label>
                                    <table>
                                        <tr>
                                            <th></th>
                                            <th>Customer<br/> Pays</th>
                                            <th>You <br/>  Receive</th>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket</td>
                                            <td>$100.00</td>
                                            <td>$100.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket tax </td>
                                            <td>$0.00</td>
                                            <td>$0.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee</td>
                                            <td>$0.00</td>
                                            <td>-$6.88</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee tax</td>
                                            <td>$0.00</td>
                                            <td>-$0.89</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Total</td>
                                            <td class="bold1" >$100.00</td>
                                            <td class="bold1">$92.23</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        <?php $j++;}
                        } else { ?>

                            <div class="tkt-details">
                                <div class="tickets-total-sidebar" style="margin-left: -110px;">
                                    <div class="tkt-no">1</div>
                                    <div class="tkt-total-sold">0</div>
                                    <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_1">0</span></div>
                                </div>
                                <!-- ticket detail start -->
                                <div class="form-left">
                                    <label>Ticket Name*</label>
                                    <p  class="tkt_name_div"><input type="text" name="ticket_name[]" value="" placeholder="Ticket Name" required title="Please enter Ticket Name"> </p>
                                    <label>Details (optional)</label>
                                    <p><input type="text" name="ticket_details[]" value="" placeholder=" Ticket details"> </p>
                                    <div class="row-out">
                                        <div class="row-1">
                                            <label>Ticket type</label>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Single Tickets" checked="checked"> 
                                                <span class="checkmark1"> </span> Single Tickets
                                            </span>
                                            <span class="radio-chk">
                                                <input type="radio" class="tkt_type" data-count="1" name="radio_tkt_type_1" value="Bundled Tickets"> 
                                                <span class="checkmark1"> </span>Bundled Tickets
                                            </span>
                                            <p class="tkt-type">Use Bundled tickets when you want to sell group tickets package<br/>
                                                (i.e. table of 10, golf foursome, family package)
                                            </p>
                                        </div>
                                        <div class="row-2">
                                            <label>Price type</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Paid" checked="checked">  <span class="checkmark1"> </span> Paid</span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="price_radio" name="price_radio_1" value="Free" >  <span class="checkmark1"> </span> Free</span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="row" id="div_price_per_tkt_1">
                                            <label>Price Per Ticket ($CAD)*</label>
                                            <p><input min="0" type="number" name="price_per_tkt[]" id="price_per_tkt_1" placeholder="100.00" required class="price_class" title="Please enter Price per ticket"> </p>
                                        </div>
                                        <div class="row" id="div_no_of_tkt_available_1">
                                            <label>Number of Tickets Available</label>
                                            <p> <input min="0" type="number" class="nota" data-count="1" name="no_of_tkt_available[]" id="nota_1" placeholder="100" required value="0" title=""> </p>
                                        </div>
                                    </div>
                                    <div class="row-out" style="display: none;" id="div_bundle_1">
                                        <div class="row">
                                            <label>Tickets Per Bundle</label>
                                            <input min="0" type="number" class="tkb" name="ticket_per_bundle[]" data-count="1" id="tkb_1" value="0" placeholder="0" required> x
                                        </div>
                                        <div class="row">
                                            <label>Bundles Available</label>
                                            <input min="0" type="number" class="tba" name="bundles_available[]" value="0" data-count="1" id="tba_1" placeholder="100" required> =
                                        </div>
                                        <div class="row">
                                            <label>Total Tickets</label>
                                            <input min="0" type="number" class="tbtkt" id="tbtkt_1" name="total_tickets[]" value="0" placeholder="200" required>
                                        </div>
                                        <div style="float: right;position: relative;left: -10px;" class="row">
                                            <label>Tax Inclusion</label>
                                            <select style="width: 90%;" name="tax_inclusion[]">
                                                <option value="No">No</option>
                                                <option value="Yes, tax ADDED to ticket price">Yes, tax ADDED to ticket price</option>
                                                <option value="Yes, tax INCLUDED in ticket price">Yes, tax INCLUDED in ticket price</option>
                                            </select>
                                            <div class="tooltip2"><i class="fa fa-info"></i>
                                                <span class="tooltiptext2"><b>Tax Inclusion</b><br>
                                                    ADDED will display ticket price as stated.<br>
                                                    INCLUDED will display ticket price before taxes.
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width:38%;" class="row">
                                            <label>Ticket Start Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_start_time" name="radio_tkt_start_time_1" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>
                                            <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_1">
                                                <label class="start-date" for="tkt_start_date">Start <input type="text" id="tkt_start_date_1" class="start_datepicker tkt_start_date" name="tkt_start_date[]" data-counter="1"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                            </div>
                                        </div>
                                        <div style="width:38%;" class="row">
                                            <label>Ticket End Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>
                                            <span class="radio-chk"> <input type="radio" data-count="1" class="radio_tkt_end_time" name="radio_tkt_end_time_1" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>
                                            <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_1">
                                                <label class="start-date" for="tkt_end_date">End <input type="text" id="tkt_end_date_1" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                            </div>
                                        </div>
                                        <div style="width:24%;" class="row">
                                            <label>Ticket Limit per Order</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="no" checked> <span class="checkmark1"> </span>No</span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_tkt_limit" name="radio_tkt_limit_1" value="yes"> <span class="checkmark1"> </span>Yes</span>
                                            <p><input type="number" min="0" name="tkt_order_limit[]" id="tkt_order_limit_1" style="display: none;"></p>
                                        </div>
                                    </div>
                            
                                    <div class="row-out">
                                        <div style="width: 38%;" class="row">
                                            <label> Release Start Date & Time</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>
                                            <span class="radio-chk"> <input type="radio" data-count="1" class="radio_release_time" name="radio_release_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                        <div style="width: 50%;" class="row">
                                            <label>Expiration Start Date & Time </label>
                                            <span class="radio-chk none"> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="None" checked> <span class="checkmark1"> </span>None</span>
                                            <span class="radio-chk"> <span> <input type="radio" data-count="1" class="radio_expiration_time" name="radio_expiration_time_1" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div style="width: 50%; display: none;" class="row" id="div_release_start_date_1">
                                            <label class="start-date" for="release_start_date">Start <input type="text" id="release_start_date_1" data-counter="1" class="start_datepicker release_start_date" name="release_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                        <div style="width: 50%; display: none;" class="row" id="div_release_end_date_1">
                                            <label class="start-date" for="release_end_date">End <input type="text" id="release_end_date_1" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="promo_div">
                                            <label> Promo Code</label>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>
                                            <span style="margin-left: 24px; margin-right: 17px;" class="radio-chk"><input class="promo_code" data-count="1" type="radio" name="radio_promo_code_1" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>
                                            <span class="radio-chk"><input type="radio" data-count="1" class="promo_code" name="radio_promo_code_1" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>
                                        </div>
                                    </div>
                                    <div class="row-out" id="div_promo_code_1" style="display: none;">
                                        <div class="row">
                                            <label>Code Name (min. 6 characters)</label>
                                            <p><input type="text" name="code_name[]" placeholder="SAVE10">
                                        </div>
                                        <div class="row">
                                            <label>Code value</label>
                                            <p><input type="text" name="code_value[]" placeholder="10.00"> </p>
                                        </div>
                                    </div>
                                    <div class="row-out">
                                        <div class="date-tkt-typ">
                                            <label> Select Date(s) for this Ticket Type</label>
                                            
                                            <?php $i=1; foreach($_SESSION['event_data']['event_start_date'] as $key=>$val) { ?>

                                                <span class="chkbox">
                                                    <input type="checkbox" checked name="">
                                                    <span class="checkmark"></span> 
                                                    <?php 

                                                        $start_date = str_replace(array('am', 'pm'), '', $_SESSION['event_data']['event_start_date'][$key]);                                          
                                                        $end_date = str_replace(array('am', 'pm'), '', $_SESSION['event_data']['event_end_date'][$key]);

                                                        if(date('Y-m-d', strtotime($start_date)) == date('Y-m-d', strtotime($end_date))) {

                                                            echo $start_date.' '.'to'.' '.date('H:i:a', strtotime($end_date));
                                                        } else {

                                                            echo $start_date.' '.'to'.' '.$end_date;
                                                        }
                                                    ?>
                                                </span>

                                            <?php $i++;}?>                                
                                        
                                        </div>
                                    </div>
                                </div>
                                <div class="form-right">
                                    <label>% Convernience Fee Paid By You.</label>
                                    <select name="select_per">
                                        <option value="0">0%</option>
                                        <option value="25">25%</option>
                                        <option value="50">50%</option>
                                        <option value="75">75%</option>
                                        <option value="100">100%</option>
                                    </select>
                                    <label> Ticket Breakdown</label>
                                    <table>
                                        <tr>
                                            <th></th>
                                            <th>Customer<br/> Pays</th>
                                            <th>You <br/>  Receive</th>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket</td>
                                            <td>$100.00</td>
                                            <td>$100.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Ticket tax </td>
                                            <td>$0.00</td>
                                            <td>$0.00</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee</td>
                                            <td>$0.00</td>
                                            <td>-$6.88</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Fee tax</td>
                                            <td>$0.00</td>
                                            <td>-$0.89</td>
                                        </tr>
                                        <tr>
                                            <td class="bold">Total</td>
                                            <td class="bold1" >$100.00</td>
                                            <td class="bold1">$92.23</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        <?php }?>                 
                        <!-- Right form End -->
                
                        <!-- ticket detail end -->
                        <p class="add-new" style="cursor:pointer;" id="add_more_tkt"><span>+</span> Add New Ticket Type</p>
                    </div>
                    <div class="help-btn"><i class="fa fa-question"></i> Need Help! <a href="#">Visit our support site for answers</a></div>
                    <button class="next-btn" type="submit" name="btnTicketSubmit">NEXT</button>
                </form>
            <?php }?>
          
        </div>
        <!-- #container -->
        <div class="third-party" style="display: none;">
            <div class="container container-home">
                <h3 class="h3-title">Configuring Your Tickets</h3>
                <button class="btn-return"><a href="<?php echo site_url(); ?>?page_id=304"> <i class="fa fa-toggle-left"></i> <span>Return to Event Setup</span></a></button>
                <ul class="progressbar">
                    <li class="active">Setup</li>
                    <li class="active">Review and Submit</li>
                </ul>
                <p style="float:left;width:100%;text-align:center;margin-bottom:10px;font-size: 15px;">Complete each required section; section NEXT to proceed.</p>
                <hr/>
                <div class="form-left">
                    <div class="ticket-setup">
                        <h3><?php echo get_post_meta(364, 'tix_left_title', TRUE);?>
                            <label class="switch">
                                <input type="checkbox" class="setup_switch">
                                <span class="slider1 round"></span>
                            </label>
                        </h3>
                        <p><?php echo get_post_meta(364, 'tix_left_content', TRUE);?>
                        </p>
                    </div>
                    <div class="web-url">
                        <h3><?php echo get_post_meta(364, 'tix_third_party_title', TRUE);?></h3>
                        <select>
                            <option value="http://">http://</option>
                            <option value="https://">https://</option>
                        </select>
                        <input style="width:85%;" type="text" name="" placeholder="URL">
                    </div>
                </div>
                <div class="form-right get-tix">
                    <!-- <p><img width="100px" src="<?php //echo site_url(); ?>/wp-content/uploads/2019/09/tix.png"></p> -->
                    <p><img width="100px" src="<?php echo wp_get_attachment_url(get_post_meta(364, 'tix_image', TRUE)) ;?>"></p>
                    <p><?php echo get_post_meta(364, 'tix_right_content1', TRUE) ;?></p>
                    <p><?php echo get_post_meta(364, 'tix_right_content2', TRUE) ;?></p>
                    <b><a href="tel:555-555-5555"><?php echo get_post_meta(364, 'tix_phone_no', TRUE) ;?></a></b>
                </div>
                <div class="help-btn"><i class="fa fa-question-circle"></i> Need Help! <a href="#">Visit our support site for answers</a></div>
                <div class="next-btn"><a href="#">Submit</a></div>
            </div>
        </div>
        <!--#third-party -->
    </div>
    <!-- # outer-wrapper-->
</div>
<!-- #main content -->
<?php get_footer(); ?>
<script>

    jQuery.validator.addMethod("notset", function(value, element) {

        return value != 'NOT SET';
    }, "Please select date");

    $( function() {

        $('#tkt_form').validate({

            rules: {

                "tkt_start_date[]": {
                    required: true,
                    notset: true
                },
                "tkt_end_date[]": {
                    required: true,
                    notset: true
                }
            }
        });

        $(".tkt_start_date").datetimepicker({

            /*minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true,
            onClose:function (e) {               

                var start_number = $('#start').val();  
                $("#tkt_start_date_"+start_number+"-error").hide(); 
                $("#tkt_start_date_"+start_number).removeClass('error');
                setTktEndMinDate(start_number);                        
             
            }

        });

        function setTktEndMinDate(start_number) {

            var start_number = start_number;
            var start_date = $("#tkt_start_date_"+start_number).val();
            var start_date1 = start_date.replace('pm', '');
            var start_date2 = start_date1.replace('am', '');
            var start_date3 = new Date(start_date2);
            var start_date4 = start_date3.getFullYear()+'/'+(start_date3.getMonth()+1)+'/'+start_date3.getDate();

            $("#tkt_end_date_"+start_number).datetimepicker({minDate: ""+start_date4+"", step: 15, format:'M d, Y H:i a', closeOnDateSelect:false, closeOnTimeSelect:true, onClose:function (e) {

                    $("#tkt_end_date_"+start_number+"-error").hide();               
                    $("#tkt_end_date_"+start_number+"-error").hide();               
                }});
        }

        $(".tkt_end_date").datetimepicker({

           /* minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true

        });

        $(".release_start_date").datetimepicker({

            /*minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true,

            onClose:function (e) {               

                var start_number = $('#start').val();  
                $("#release_start_date_"+start_number+"-error").hide(); 
                $("#release_start_date_"+start_number).removeClass('error');
                setReleaseEndMinDate(start_number);                        

            }

        });



        $(".release_end_date").datetimepicker({

           /* minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true

        });
    });

    function setReleaseEndMinDate(start_number) {

        var start_number = start_number;
        var start_date = $("#release_start_date_"+start_number).val();
        var start_date1 = start_date.replace('pm', '');
        var start_date2 = start_date1.replace('am', '');
        var start_date3 = new Date(start_date2);
        var start_date4 = start_date3.getFullYear()+'/'+(start_date3.getMonth()+1)+'/'+start_date3.getDate();

        $("#release_end_date_"+start_number).datetimepicker({minDate: ""+start_date4+"", step: 15, format:'M d, Y H:i a', closeOnDateSelect:false, closeOnTimeSelect:true, onClose:function (e) {

                $("#release_end_date_"+start_number+"-error").hide();               
                $("#release_end_date_"+start_number+"-error").hide();               
            }});
    }

    $(document).on('change', '.tba', function () {

        var count = $(this).data('count');
        var tkt_count = $('#count').val();
        var tba = $(this).val();
        var tkb = $('#tkb_'+count).val();
        var tbtkt = parseInt(tkb) * parseInt($(this).val());
        var total_ticket_available = $('#total_ticket_available').val();
        $('#tbtkt_'+count).val(tbtkt);
        var sum = 0;

        if(tba != '') {

            for(var i = 1; parseInt(i)<=parseInt(tkt_count); i= parseInt(i)+parseInt(1)) {

                sum = parseInt(sum) + parseInt($('#tbtkt_'+i).val()) + parseInt($('#nota_'+i).val());
            }

            if(parseInt(sum) > parseInt(total_ticket_available)) {

                alert('Total exceeds maximum quantity set, please adjust accordingly.');
                $(this).val('0');
                $('#tbtkt_'+count).val('0');
            } else {

                $('#current_ticket_allocation').text(sum);
                $('#hidden_current_ticket_allocation').val(sum);
                $('#total_tkt_available_'+count).text(tbtkt);
                //$('.tkt-total-sold').text(sum);
            }
        }

    });

    $(document).on('change', '.tkb', function () {

        var count = $(this).data('count');
        var tkt_count = $('#count').val();
        var tkb = $(this).val();
        var tba = $('#tba_'+count).val();
        var tbtkt = parseInt(tba) * parseInt($(this).val());
        var total_ticket_available = $('#total_ticket_available').val();
        $('#tbtkt_'+count).val(tbtkt);
        var sum = 0;

        if(tkb != '') {

            for(var i = 1; parseInt(i)<=parseInt(tkt_count); i= parseInt(i)+parseInt(1)) {

                sum = parseInt(sum) + parseInt($('#tbtkt_'+i).val()) + parseInt($('#nota_'+i).val());
            }

            if(parseInt(sum) > parseInt(total_ticket_available)) {

                alert('Total exceeds maximum quantity set, please adjust accordingly.');
                $(this).val('0');
                $('#tbtkt_'+count).val('0');
            } else {

                $('#current_ticket_allocation').text(sum);
                $('#hidden_current_ticket_allocation').val(sum);
                $('#total_tkt_available_'+count).text(tbtkt);
                /*$('.tkt-total-sold').text(sum);*/
            }
        }

    });

    $(document).on('click', '.tkt_type', function(){

        var tkt_type = $(this).val();
        var count = $(this).data('count');

        $('#nota_'+count).val('0');
        $('#tkb_'+count).val('0');
        $('#tba_'+count).val('0');
        $('#tbtkt_'+count).val('0');

        if(tkt_type == 'Single Tickets') {

            $('#div_no_of_tkt_available_'+count).show();
            $('#div_bundle_'+count).hide();
        } else {

            $('#div_no_of_tkt_available_'+count).hide();
            $('#div_bundle_'+count).show();
        }
    });
    $(document).on('click', '.setup_switch', function () {

        if($(this).prop('checked') == true){

            $('.third-party').hide();
            $('#setup_div').show();
            $(this).prop('checked', false);

        } else {

            $('.third-party').show();
            $('#setup_div').hide();
            $(this).prop('checked', true);
        }

    })

    $(document).on('click', '.price_radio', function () {

        var price_radio = $(this).val();
        var count = $(this).data('count');
        $('#price_per_tkt_'+count).val('');

        if(price_radio == 'Free') {

            $('#div_price_per_tkt_'+count).hide();
        } else {

            $('#div_price_per_tkt_'+count).show();
        }
    });

    $(document).on('change', '.nota', function(){

        var nota = $(this).val();
        var count = $('#count').val();
        var number = $(this).data('count');

        if(nota != '') {

            var total_ticket_available = $('#total_ticket_available').val();
            var sum = 0;

            for(var i = 1; parseInt(i)<=parseInt(count); i= parseInt(i)+parseInt(1)) {

                sum = parseInt(sum) + parseInt($('#nota_'+i).val())+parseInt($('#tbtkt_'+i).val());
            }

            if(parseInt(sum) > parseInt(total_ticket_available)) {

                alert('Total exceeds maximum quantity set, please adjust accordingly.');
                $(this).val('0');
            } else {

                $('#current_ticket_allocation').text(sum);
                $('#hidden_current_ticket_allocation').val(sum);
                $('#total_tkt_available_'+number).text(nota);
               // $('.tkt-total-sold').text(sum);
            }

        }

    });

    $(document).on('click', '.radio_tkt_start_time', function () {

        var radio_tkt_start_time = $(this).val();
        var count = $(this).data('count');

        if(radio_tkt_start_time == 'New Start Time') {

            $('#div_tkt_start_date_'+count).show();
        } else {

            $('#div_tkt_start_date_'+count).hide();
        }
    });

    $(document).on('click', '.radio_tkt_end_time', function () {

        var radio_tkt_end_time = $(this).val();
        var count = $(this).data('count');

        if(radio_tkt_end_time == 'New End Time') {

            $('#div_tkt_end_date_'+count).show();
        } else {

            $('#div_tkt_end_date_'+count).hide();
        }
    });

    $(document).on('click', '.radio_release_time', function () {

        var radio_release_time = $(this).val();
        var count = $(this).data('count');

        if(radio_release_time == 'Scheduled') {

            $('#div_release_start_date_'+count).show();
        } else {

            $('#div_release_start_date_'+count).hide();
        }
    });

    $(document).on('click', '.radio_expiration_time', function () {

        var radio_expiration_time = $(this).val();
        var count = $(this).data('count');

        if(radio_expiration_time == 'Scheduled') {

            $('#div_release_end_date_'+count).show();
        } else {

            $('#div_release_end_date_'+count).hide();
        }
    });

    $(document).on('click', '.promo_code', function () {

        var promo_code = $(this).val();
        var count = $(this).data('count');

        if(promo_code == 'disabled') {

            $('#div_promo_code_'+count).hide();
        } else {

            $('#div_promo_code_'+count).show();
        }
    });

    $(document).on('click', '#add_more_tkt', function () {

        var count = $('#count').val();
        count = parseInt(count)+parseInt(1);
        $('#count').val(count);
       /* var total_ticket_available = $('#total_ticket_available').val();*/
        var current_ticket_allocation = $('#current_ticket_allocation').text();

            var html = '<div class="tkt-details">\n'+
                '<div class="tickets-total-sidebar" style="margin-left: -110px;">\n' +
                '                    <div class="tkt-no">'+count+'</div>\n' +
                '                    <div class="tkt-total-sold">0</div>\n' +
                '                    <div class="tkt-outof">SOLD OUT OF<span class="total_tkt_available" id="total_tkt_available_'+count+'">0</span></div>\n' +
                '                </div>\n' +
            '               <div class="form-left">\n'+
            '                  <label>Ticket Name</label>\n'+
            '                  <p><input type="text" name="ticket_name[]" value="" placeholder="Ticket Name" required> </p>\n'+
            '                  <label>Details (optional)</label>\n'+
            '                  <p><input type="text" name="ticket_details[]" value="" placeholder=" Ticket details"> </p>\n'+
            '                  <div class="row-out">\n'+
            '                     <div class="row-1">\n'+
            '                        <label>Ticket type</label>\n'+
            '                        <span class="radio-chk">\n'+
            '                            <input type="radio" class="tkt_type" data-count="'+count+'" name="radio_tkt_type_'+count+'" value="Single Tickets" checked="checked"> <span class="checkmark1"> </span> Single Tickets\n'+
            '                        </span>\n'+
            '                        <span class="radio-chk">\n'+
            '                            <input type="radio" class="tkt_type" data-count="'+count+'" name="radio_tkt_type_'+count+'" value="Bundled Tickets"> <span class="checkmark1"> </span>Bundled Tickets\n'+
            '                        </span>\n'+
            '                        <p class="tkt-type">Use Bundled tickets when you want to sell group tickets package<br/>\n'+
            '                           (i.e. table of 10, golf foursome, family package)\n'+
            '                        </p>\n'+
            '                     </div>\n'+
            '                     <div class="row-2">\n'+
            '                        <label>Price type</label>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="price_radio" name="price_radio_'+count+'" value="Paid" checked="checked">  <span class="checkmark1"> </span> Paid</span>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="price_radio" name="price_radio_'+count+'" value="Free" >  <span class="checkmark1"> </span> Free</span>\n'+
            '                     </div>\n'+
            '                  </div>\n'+
            '                  <div class="row-out">\n'+
            '                     <div class="row" id="div_price_per_tkt_'+count+'">\n'+
            '                        <label>Price Per Ticket ($CAD)</label>\n'+
            '                        <p><input type="number" min="0" class="price_class" name="price_per_tkt[]" id="price_per_tkt_'+count+'" placeholder="100.00" required> </p>\n'+
            '                     </div>\n'+
            '                     <div class="row" id="div_no_of_tkt_available_'+count+'">\n'+
            '                        <label>Number of Tickets Available</label>\n'+
            '                        <p> <input type="number" min="0" data-count="'+count+'" class="nota" name="no_of_tkt_available[]" id="nota_'+count+'" placeholder="100" required value="0"> </p>\n'+
            '                     </div>\n'+
            '                  </div>\n'+
            '                  <div class="row-out" style="display: none;" id="div_bundle_'+count+'">\n'+
            '                     <div class="row">\n'+
            '                        <label>Tickets Per Bundle</label>\n'+
            '                        <input type="number" min="0" class="tkb" name="ticket_per_bundle[]"data-count="'+count+'" id="tkb_'+count+'" value="0" placeholder="0" required> x\n'+
            '                     </div>\n'+
            '                     <div class="row">\n'+
            '                        <label>Bundles Available</label>\n'+
            '                        <input type="number" min="0" class="tba" name="bundles_available[]" value="0" data-count="'+count+'" id="tba_'+count+'" placeholder="100" required> =\n'+
            '                     </div>\n'+
            '                     <div class="row">\n'+
            '                        <label>Total Tickets</label>\n'+
            '                        <input type="number" min="0" class="tbtkt" id="tbtkt_'+count+'" name="total_tickets[]" value="0" placeholder="200" required>\n'+
            '                     </div>\n'+
            '                     <div class="row" style="float: right;position: relative;left: -10px;">\n'+
            '                           <label>Tax Inclusion</label>\n'+
            '                           <select style="width: 90%;" name="tax_inclusion[]">\n'+
            '                               <option value="No">No</option>\n'+
            '                               <option value="Yes, tax ADDED to ticket price">Yes, tax ADDED to ticket price</option>\n'+
            '                               <option value="Yes, tax INCLUDED in ticket price">Yes, tax INCLUDED in ticket price</option>\n'+
            '                           </select>\n'+
            '                           <div class="tooltip2"><i class="fa fa-info"></i>\n'+  
            '                               <span class="tooltiptext2"><b>Tax Inclusion</b><br>\n'+ 
            '                                    ADDED will display ticket price as stated.<br>\n'+
            '                                     INCLUDED will display ticket price before taxes.\n'+
            '                               </span>\n'+
            '                           </div>\n'+        
            '                     </div>\n'+                                  
            '                  </div>\n'+
            '                  <div class="row-out">\n'+
            '                     <div class="row">\n'+
            '                        <label>Ticket Start Time</label>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_start_time" name="radio_tkt_start_time_'+count+'" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_start_time" name="radio_tkt_start_time_'+count+'" value="New Start Time"> <span class="checkmark1"> </span>New Start Time </span>\n'+
            '                       <div style="width: 50%; display: none;" class="row" id="div_tkt_start_date_'+count+'">\n'+
            '                           <label class="start-date" for="tkt_start_date_'+count+'">Start <input type="text" id="tkt_start_date_'+count+'" class="start_datepicker tkt_start_date" data-counter="'+count+'" name="tkt_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important;  padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
            '                       </div>\n'+
            '                     </div>\n'+
            '                     <div class="row">\n'+
            '                        <label>Ticket End Time</label>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_end_time" name="radio_tkt_end_time_'+count+'" value="Match Event" checked> <span class="checkmark1"> </span>Match Event</span>\n'+
            '                        <span class="radio-chk"> <input type="radio" data-count="'+count+'" class="radio_tkt_end_time" name="radio_tkt_end_time_'+count+'" value="New End Time"> <span class="checkmark1"> </span>New End Time </span>\n'+
            '                       <div style="width: 50%; display: none;" class="row" id="div_tkt_end_date_'+count+'">\n'+
            '                           <label class="start-date" for="tkt_end_date_'+count+'">End <input type="text" id="tkt_end_date_'+count+'" class="start_datepicker tkt_end_date" name="tkt_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
            '                       </div>\n'+
            '                     </div>\n '+
            '                     <div class="row">\n'+
            '                        <label>Ticket Limit per Order</label>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_limit" name="radio_tkt_limit_'+count+'" value="no" checked> <span class="checkmark1"> </span>No</span>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_tkt_limit" name="radio_tkt_limit_'+count+'" value="yes"> <span class="checkmark1"> </span>Yes</span>\n'+
            '                        <p><input type="number" min="0" name="tkt_order_limit[]" style="display: none;" id="tkt_order_limit_'+count+'"></p>\n'+
            '                     </div>\n '+
            '                  </div>\n'+
            '                  <div class="row-out">\n'+
            '                     <div style="width: 50%;" class="row">\n'+
            '                        <label> Release Start Date & Time</label>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="radio_release_time" name="radio_release_time_'+count+'" value="Immediately" checked> <span class="checkmark1"> </span>Immediately</span>\n'+
            '                        <span class="radio-chk"> <input type="radio" data-count="'+count+'" class="radio_release_time" name="radio_release_time_'+count+'" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>\n'+
            '                     </div>\n'+
            '                     <div style="width: 50%;" class="row">\n'+
            '                        <label>Expiration Start Date & Time </label>\n'+
            '                       <span class="radio-chk none"> <input type="radio" data-count="'+count+'" class="radio_expiration_time" name="radio_expiration_time_'+count+'" value="None" checked> <span class="checkmark1"> </span>None</span>\n'+
            '                       <span class="radio-chk"> <span> <input type="radio" data-count="'+count+'" class="radio_expiration_time" name="radio_expiration_time_'+count+'" value="Scheduled"> <span class="checkmark1"> </span>Scheduled </span>\n'+
            '                     </div>\n'+
            '                  </div>\n'+
            '                   <div class="row-out">\n'+
            '                       <div style="width: 50%; display: none;" class="row" id="div_release_start_date_'+count+'">\n'+
            '                           <label class="start-date" for="release_start_date_'+count+'">Start <input type="text" id="release_start_date_'+count+'" data-counter="'+count+'" class="start_datepicker release_start_date" name="release_start_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
            '                       </div>\n'+
            '                       <div style="width: 50%; display: none;" class="row" id="div_release_end_date_'+count+'">\n'+
            '                           <label class="start-date" for="release_end_date_'+count+'">End <input type="text" id="release_end_date_'+count+'" class="start_datepicker release_end_date" name="release_end_date[]"  style="cursor:pointer; background: #529cfb !important; width: 100% !important; padding: 0px; !important;" value="NOT SET"><small style="font-size: 12px;">Select to change</small></label>\n'+
            '                       </div>\n'+
            '                   </div>\n'+
            '                  <div class="row-out">\n'+
            '                     <div class="">\n'+
            '                        <label> Promo Code</label>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="promo_code" name="radio_promo_code_'+count+'" value="disabled" checked> <span class="checkmark1"> </span>Disabled</span>\n'+
            '                        <span style="margin-left: 24px; margin-right: 17px;" class="radio-chk"><input class="promo_code" data-count="'+count+'" type="radio" name="radio_promo_code_'+count+'" value="dollar"> <span class="checkmark1"> </span>Dollar Amount ($CAD) </span>\n'+
            '                        <span class="radio-chk"><input type="radio" data-count="'+count+'" class="promo_code" name="radio_promo_code_'+count+'" value="percentage"> <span class="checkmark1"> </span>Percentage Amount (%) </span>\n'+
            '                     </div>\n'+
            '                  </div>\n'+
            '                  <div class="row-out" id="div_promo_code_'+count+'" style="display: none;">\n'+
            '                     <div class="row">\n'+
            '                        <label>Code Name (min. 6 characters)</label>\n'+
            '                        <p><input type="text" name="code_name[]" placeholder="SAVE10">\n'+
            '                     </div>\n'+
            '                     <div class="row">\n'+
            '                        <label>Code value</label>\n'+
            '                        <p><input type="text" name="code_value[]" placeholder="10.00"> </p>\n'+
            '                     </div>\n'+
            '                  </div>\n'+
            '                  <div class="row-out">\n' +                  
            '                       <div class="date-tkt-typ">\n'+                       
            '                       <label> Select Date(s) for this Ticket Type</label>\n'+                            
            '                       <?php $i=1; foreach($_SESSION['event_data']['event_start_date'] as $key=>$val) { ?>\n'+                          
            '                       <span class="chkbox">\n'+                           
            '                       <input type="checkbox" checked name="">\n'+
            '                       <span class="checkmark"></span>\n'+
            '                       <?php            
                                        $start_date = str_replace(array('am', 'pm'), '', $_SESSION['event_data']['event_start_date'][$key]);                                          
                                                    $end_date = str_replace(array('am', 'pm'), '', $_SESSION['event_data']['event_end_date'][$key]);

                                                    if(date('Y-m-d', strtotime($start_date)) == date('Y-m-d', strtotime($end_date))) {

                                                        echo $start_date.' '.'to'.' '.date('H:i:a', strtotime($end_date));
                                                    } else {

                                                        echo $start_date.' '.'to'.' '.$end_date;
                                                    }
                                                ?>
                                            </span>\n'+

                                        '<?php $i++;}?>\n'+                          
                                    
                                    '</div>\n'+
                                '</div>\n'+
                           '</div>\n'+
            '               <div class="form-right">\n'+
            '                  <label>% Convernience Fee Paid By You.</label>\n'+
            '                  <select name="select_per">\n'+
            '                     <option value="0">0%</option>\n'+
            '                     <option value="25">25%</option>\n'+
            '                     <option value="50">50%</option>\n'+
            '                     <option value="75">75%</option>\n'+
            '                     <option value="100">100%</option>\n'+
            '                  </select>\n'+
            '                  <label> Ticket Breakdown</label>\n'+
            '                  <table>\n'+
            '                     <tr>\n'+
            '                        <th></th>\n'+
            '                        <th>Customer<br/> Pays</th>\n'+
            '                        <th>You <br/>  Receive</th>\n'+
            '                     </tr>\n'+
            '                     <tr>\n'+
            '                        <td class="bold">Ticket</td>\n'+
            '                        <td>$100.00</td>\n'+
            '                        <td>$100.00</td>\n'+
            '                     </tr>\n'+
            '                     <tr>\n'+
            '                        <td class="bold">Ticket tax </td>\n'+
            '                        <td>$0.00</td>\n'+
            '                        <td>$0.00</td>\n'+
            '                     </tr>\n'+
            '                     <tr>\n'+
            '                        <td class="bold">Fee</td>\n'+
            '                        <td>$0.00</td>\n'+
            '                        <td>-$6.88</td>\n'+
            '                     </tr>\n'+
            '                     <tr>\n'+
            '                        <td class="bold">Fee tax</td>\n'+
            '                        <td>$0.00</td>\n'+
            '                        <td>-$0.89</td>\n'+
            '                     </tr>\n'+
            '                     <tr>\n'+
            '                        <td class="bold">Total</td>\n'+
            '                        <td class="bold1" >$100.00</td>\n'+
            '                        <td class="bold1">$92.23</td>\n'+
            '                     </tr>\n'+
            '                  </table>\n'+
            '               </div>\n'+
            '            <p style="cursor:pointer;" class="del-tkt"><span>-</span> Remove Ticket Type</p>\n'+
            '        </div>';

        $(this).before(html);

        $(".tkt_start_date").datetimepicker({

            /* minDate: 0,*/
                step: 15,
                format:'M d, Y H:i a',
                closeOnDateSelect:false,
                closeOnTimeSelect:true,

                onClose:function (e) {               

                var start_number = $('#start').val();  
                $("#tkt_start_date_"+start_number+"-error").hide(); 
                $("#tkt_start_date_"+start_number).removeClass('error');
                setTktEndMinDate(start_number);                        

            }

        });

        function setTktEndMinDate(start_number) {

            var start_number = start_number;
            var start_date = $("#tkt_start_date_"+start_number).val();
            var start_date1 = start_date.replace('pm', '');
            var start_date2 = start_date1.replace('am', '');
            var start_date3 = new Date(start_date2);
            var start_date4 = start_date3.getFullYear()+'/'+(start_date3.getMonth()+1)+'/'+start_date3.getDate();

            $("#tkt_end_date_"+start_number).datetimepicker({minDate: ""+start_date4+"", step: 15, format:'M d, Y H:i a', closeOnDateSelect:false, closeOnTimeSelect:true, onClose:function (e) {

                    $("#tkt_end_date_"+start_number+"-error").hide();               
                    $("#tkt_end_date_"+start_number+"-error").hide();               
                }});
        }

        $(".tkt_end_date").datetimepicker({

          /*  minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true

        });

        $(".release_start_date").datetimepicker({

         /*   minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true,

            onClose:function (e) {               

                var start_number = $('#start').val();  
                $("#release_start_date_"+start_number+"-error").hide(); 
                $("#release_start_date_"+start_number).removeClass('error');
                setReleaseEndMinDate(start_number);                        

            }

        });

        $(".release_end_date").datetimepicker({

           /* minDate: 0,*/
            step: 15,
            format:'M d, Y H:i a',
            closeOnDateSelect:false,
            closeOnTimeSelect:true

        });

    });

    $(document).on('click', '.del-tkt', function () {

        if(confirm('Are you sure you would like to remove this ticket type?')) {

            $(this).parent().remove();
            var count = $('#count').val();
            count = parseInt(count)-parseInt(1);
            $('#count').val(count);

            for(var i=0; parseInt(i) < parseInt(count); i = parseInt(i)+parseInt(1)) {

                $('#div_ticket').find('.tkt-no:eq(' + i + ')').text(parseInt(i)+parseInt(1));
            }
        }
    });

    $(document).on('change', '.charge-tax', function () {

        var charge_tax = $(this).val();

        if(charge_tax == 'yes') {

            $('.tax-yes').show();
        } else {

            $('.tax-yes').hide();
        }

        $('#tax_id').val('');
        $('#tax_name').val('');
        $('#tax_rate').val('');
    });

    $(document).on('change', '.price_class', function () {

        var price = $(this).val();
        $(this).val(parseFloat(price).toFixed(2));
    });

    $(document).on('click', '.radio_tkt_limit', function () {

        var count = $(this).data('count');
        var val = $(this).val();

        if(val == 'yes') {

            $('#tkt_order_limit_'+count).show();
        } else {

            $('#tkt_order_limit_'+count).hide();
        }
    });

    $(document).on('click', '.tkt_start_date', function(e){

        var start_number = $(this).data('counter');
        $('#start').val(start_number);
    });

    $(document).on('click', '.release_start_date', function(e){

        var start_number = $(this).data('counter');
        $('#start').val(start_number);
    });

    /*$(document).on('change', '#total_ticket_available', function(){

        var tkt_available = $(this).val();
        $('.total_tkt_available').text(tkt_available);
    });*/
</script>